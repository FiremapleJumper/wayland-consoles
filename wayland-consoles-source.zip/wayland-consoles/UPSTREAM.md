# Waylandcraft attribution and changes

This project is a derivative of [EVV1E/waylandcraft](https://github.com/EVV1E/waylandcraft),
revision `49a25db3f98d67ebe8660d12b519f3995d0f56c7`, retrieved October 31, 2026.
The original author is EVV1E. The upstream GPL-3.0-or-later license is preserved in `LICENSE`.
This derivative, including its new Java code, native changes, original pixel assets and tests,
is distributed under GPL-3.0-or-later. It is an independent, AI-assisted prototype and has not
been endorsed by or submitted upstream to Waylandcraft.

Changes made October 31, 2026:

- Ported the selected compositor integration to Minecraft 26.3 and SDL input.
- Retained the Smithay compositor, Java/native bridge, EGL helpers, protocol handling,
  Xwayland satellite integration, and associated dependency lock file.
- Added native Wayland client PID reporting for matching emulator processes to TVs.
- Replaced the old Minecraft GPU wrappers with owned pixel snapshots and dynamic textures.
  EGL DMA-BUF import uses a GPU readback path; this is slower than upstream's direct rendering.
- Replaced the floating-window/item system and desktop launcher UI with craftable consoles,
  local ROM discovery/import, a TV renderer, emulator launcher and control screen.
- Added experimental Minecraft movement demos and automated tests.
- Added local SM64/OoT avatar import, animated character rendering and optional integration tests.
- Added attack combos, ledge grabbing, Link equipment/magic, original imported HUD icons,
  ocarina controls and singleplayer server-side action handling.
- Removed the obsolete Waylandcraft resource models, mixins and Iris integration.

The Rust JNI package names remain `dev.evvie.waylandcraft` for compatibility with the native
bridge. The Fabric mod ID is `waylandconsoles`; do not install the original Waylandcraft
alongside this derivative. No Minecraft game binaries, emulator binaries, commercial ROMs,
console firmware, ROM-derived textures, animation caches, or Link models are included.
The Mario importer includes libsm64 and its decompilation-based Mario geometry; see
`tools/avatar/PROVENANCE.md` and `third-party-licenses/libsm64-CC0.txt`.
Avatar textures and animations are read from the local owner's ROMs at import time.
