# Characters and equipment in 0.3.0

Restart Minecraft after updating the JAR. Use the console's Movement demo screen, or
`/consoles movement sm64`, `oot`, or `oot_child`. Use `off` to restore your player and camera.
These characters run in singleplayer Minecraft worlds.

## Shared ledge controls

Face a reachable platform and hold forward while falling to catch its edge. Release forward
to remain hanging. Press jump or hold forward to climb, or crouch to drop. Both Mario and
both ages of Link use this mechanic and their original hanging/climbing poses. Low ceilings,
blocked landing spaces and edges above reach prevent a grab. It does not allow grabbing
an arbitrary point on a tall wall.

## Mario

- Attack: left click for first punch, second punch and kick. In the air, attack plays an air kick.
- Stationary crouch + jump: backflip.
- Moving forward + crouch + jump: long jump.
- Successive jumps: single, double and triple jump heights.
- Tap crouch after starting a jump: ground-pound. Landing can damage nearby creatures.
- Jump against a wall while airborne: wall kick.

## Link

- Run forward off a genuine drop to auto-jump. Walking down a small step or an ordinary
  manual jump does not trigger another jump. Hover boots substitute a short hover for this.
- Left click: sword combo; target + forward attacks thrust. Attacking in midair jump-attacks.
- Hold attack, then release: spin attack. It consumes magic when the unlocked kit is off.
- R: lock/unlock a nearby visible creature. Move back/sideways + jump while targeting,
  or while crouching, for a backflip or side hop.
- V held: shield. Biggoron's sword is two-handed and prevents shielding.
- Tap crouch while running forward: roll.
- I: equipment, item slots and settings. Z, X and C use their three assigned items.
- H: ready a nearby eligible loose block; H again throws it with a strength upgrade.
- In water: crouch to dive. Ladders/vines use Minecraft climbing with a character animation.

All these keys can be rebound in Minecraft's Controls screen. A controller input mod can
map the same bindings for Minecraft; the TV emulator has its own gamepad bindings.

The equipment screen's **Unlocked kit** switch is persistent. ON makes age-appropriate
gear available without consuming ammo or magic. OFF requires the Minecraft items named
in each item's tooltip, consumes corresponding ammo, and spends magic. Your normal
Minecraft inventory remains accessible. The toggle can be changed at any time.

## Equipment and active items

- Kokiri/Master/Biggoron swords, Deku/Hylian/Mirror shields, Kokiri/Goron/Zora tunics,
  regular/Iron/Hover boots, strength upgrades, and diving scales. Equipment respects age.
  The Goron tunic resists fire/lava; the Zora tunic supplies air; Iron boots sink and slow
  movement; Hover boots briefly support you after leaving a ledge. Scales extend diving time.
- Bow and fire/ice/light arrows, slingshot, returning boomerang, hookshot/longshot,
  Megaton hammer, Deku sticks/nuts, bombs, bombchus, Lens of Truth and Magic Beans.
  Ice slows/freezes, fire burns, light hits harder, nuts stun, and the boomerang retrieves
  dropped items. Hookshots pull toward a solid surface with an unobstructed landing space.
- Din's Fire damages/ignites nearby creatures. Farore's Wind sets a return point, then
  returns to it on the next use. Nayru's Love blocks ordinary damage for 30 seconds.
  Lens of Truth drains magic while revealing creatures with Minecraft's glow effect.
- Bottles, red/green/blue potions, fairy, milk, fish, bugs, blue fire and Poe. Potions restore
  Minecraft health and/or the character's magic; an assigned fairy can prevent a fatal hit.
  An empty bottle captures a fish or silverfish into Minecraft inventory items. Blue fire
  melts nearby ice. Milk heals and clears poison/wither.
- Eight original child masks can be worn. They are OoT masks, not Majora's transformations.
  The Mask of Truth exposes a creature's name/health; the other masks are cosmetic.

Bombs cause combat damage by default. **Bomb terrain damage** in Controls enables Minecraft
terrain explosions. Beans grow a small climbable vine platform on soil. Throwing uses
Minecraft falling-block entities and can move the selected soil/stone block.

The importer includes original held sword/shield, bow/slingshot, hookshot, hammer,
boomerang and ocarina geometry for the relevant actions, plus the child mask meshes.
Tunic colors change with the selected tunic. Some equipment variants share a rendered
model, and the Minecraft projectiles use simple block-shaped visuals.

## Ocarina and HUD

Equip the ocarina into an item slot, then use that slot. Select a song for automatic playback,
or play its original sequence with A and the arrow keys. The interface shows the original
button textures and all twelve songs. Notes use Minecraft's flute sound.

Lullaby opens nearby wooden doors; Epona's Song calls a nearby horse; Saria's Song reveals
creatures; Sun's Song changes day/night; Song of Time advances Minecraft time; Storms toggles
rain. Each of the six warp songs has a Set button for a per-world destination. Destinations
are checked for free landing space before teleporting. Quest-specific song interactions
with OoT characters/objects do not exist in Minecraft.

The HUD imports the ROM's hearts and item icons and shows Minecraft health, magic,
equipped actions/items, ammo, emeralds as rupees, target health, active magic, and a local
Minecraft minimap. Minecraft's hotbar/food/air indicators remain useful and visible.

This is an adaptation of the character abilities to Minecraft. It does not execute OoT's
original engine, import its quests/dungeons, or implement NPC/trading progression. Player
collision dimensions remain Minecraft's, and character visuals are local to the client.
