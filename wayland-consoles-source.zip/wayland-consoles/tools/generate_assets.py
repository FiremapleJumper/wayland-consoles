#!/usr/bin/env python3
"""Generate the original pixel textures, block models, recipes and loot tables."""
from pathlib import Path
import json, re
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / 'src/main/resources'
ASSETS = RES / 'assets/waylandconsoles'
DATA = RES / 'data/waylandconsoles'
SOURCE = ROOT / 'src/main/java/dev/evvie/waylandcraft/console/ConsoleType.java'
systems = re.findall(r'^    ([A-Z0-9_]+)\("([^"]+)", "[^"]*", "[^"]*", (0x[0-9a-f]+)\)', SOURCE.read_text(), re.M)

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')

def png(path, im):
    path.parent.mkdir(parents=True, exist_ok=True)
    im.save(path)

def color(number, change=0):
    return tuple(max(0, min(255, ((number >> shift) & 255) + change)) for shift in (16,8,0)) + (255,)

def texture(name, base, system):
    for face in ('front','side','top'):
        im = Image.new('RGBA', (16,16), color(base)); d = ImageDraw.Draw(im)
        d.line([(0,15),(15,15)], fill=color(base,-40)); d.line([(0,0),(15,0)], fill=color(base,28))
        if face == 'front':
            d.rectangle((1,6,14,10), fill=(26,31,39)); d.rectangle((3,8,5,9), fill=(7,9,12))
            d.rectangle((9,8,11,9), fill=(7,9,12)); d.point((13,7), fill=(114,234,145))
            if system in ('NES','SNES'): d.rectangle((2,4,13,5), fill=(57,59,66))
        elif face == 'side':
            for row in range(3,13,3): d.line((2,row,11,row), fill=color(base,-26))
        else:
            d.rectangle((2,2,13,13), outline=color(base,-25))
            if system in ('NES','SNES','N64','ATARI2600'):
                d.rectangle((4,5,11,7), fill=(25,29,36)); d.line((4,8,11,8), fill=color(base,35))
            elif system in ('GAMECUBE','PS1','SATURN','DREAMCAST'):
                d.ellipse((3,3,12,12), fill=color(base,-18), outline=color(base,24))
            elif system == 'XBOX':
                d.line((2,2,13,13),fill=(34,39,35),width=3); d.line((13,2,2,13),fill=(34,39,35),width=3)
                d.ellipse((6,6,9,9), fill=(111,193,61))
            else: d.rectangle((4,3,11,10), fill=color(base,-36)); d.rectangle((5,4,10,8), fill=(38,45,59))
            d.rectangle((2,11,3,12),fill=(202,63,65)); d.rectangle((12,11,13,12),fill=(40,46,58))
        png(ASSETS / f'textures/block/{name}_{face}.png', im)

def model(name, box):
    texture_map = {'front':f'waylandconsoles:block/{name}_front', 'side':f'waylandconsoles:block/{name}_side', 'top':f'waylandconsoles:block/{name}_top'}
    faces = {side:{'texture': '#' + ('top' if side=='up' else 'front' if side=='north' else 'side')} for side in ('north','south','east','west','up','down')}
    write(ASSETS / f'models/block/{name}.json', {'parent':'minecraft:block/block','textures':{'particle':texture_map['side'], **texture_map}, 'elements':[{'from':box[0], 'to':box[1], 'faces':faces}]})
    write(ASSETS / f'blockstates/{name}.json', {'variants':{f'facing={direction}':{'model':f'waylandconsoles:block/{name}', 'y':angle} for direction,angle in [('north',0),('east',90),('south',180),('west',270)]}})
    write(ASSETS / f'models/item/{name}.json', {'parent':f'waylandconsoles:block/{name}'})
    write(ASSETS / f'items/{name}.json', {'model':{'type':'minecraft:model','model':f'waylandconsoles:item/{name}'}})

def recipe(name, pattern, key):
    write(DATA / f'recipe/{name}.json', {'type':'minecraft:crafting_shaped','category':'redstone','pattern':pattern,'key':key,'result':{'id':f'waylandconsoles:{name}','count':1}})
    write(DATA / f'advancement/recipes/{name}.json', {'parent':'minecraft:recipes/root','criteria':{'has_redstone':{'trigger':'minecraft:inventory_changed','conditions':{'items':[{'items':'minecraft:redstone'}]}}}, 'requirements':[['has_redstone']], 'rewards':{'recipes':[f'waylandconsoles:{name}']}})

def loot(name):
    write(DATA / f'loot_table/blocks/{name}.json', {'type':'minecraft:block','pools':[{'rolls':1,'entries':[{'type':'minecraft:item','name':f'waylandconsoles:{name}'}],'conditions':[{'condition':'minecraft:survives_explosion'}]}]})

lang = {'itemGroup.waylandconsoles.consoles':'Wayland Consoles','block.waylandconsoles.tv':'Wayland TV','item.waylandconsoles.controller':'Game Controller'}
# Each console has a distinct dye+material recipe, including the extra handhelds.
dyes = ['white','light_gray','black','lime','purple','magenta','gray','blue','red','brown','cyan','light_blue','orange','yellow','pink','green']
for index,(enum,label,hexcolor) in enumerate(systems):
    name = enum.lower() + '_console'; base = int(hexcolor,16)
    texture(name,base,enum); model(name,([1,0,1],[15,7,15])); loot(name)
    dye = dyes[index % len(dyes)] + '_dye'
    chip = 'gold_ingot' if index < 16 else 'copper_ingot'
    recipe(name,['III','RCR','IDI'],{'I':'minecraft:iron_ingot','R':'minecraft:redstone','C':'minecraft:'+chip,'D':'minecraft:'+dye})
    lang['block.waylandconsoles.'+name] = label + ' Console'

for face in ('front','side','top'):
    im=Image.new('RGBA',(16,16),(41,47,59));d=ImageDraw.Draw(im)
    if face=='front':
        d.rectangle((0,0,15,15),outline=(77,86,103));d.rectangle((1,2,14,12),fill=(4,10,17))
        for row in range(3,13,2):d.line((2,row,13,row),fill=(9,22,29))
        d.rectangle((2,14,9,14),fill=(20,26,34));d.point((13,14),fill=(113,236,149))
    else:
        for i in range(3,14,2):d.line((2,i,13,i),fill=(24,31,42))
    png(ASSETS/f'textures/block/tv_{face}.png',im)
model('tv',([0,0,0],[16,16,16]));loot('tv')
recipe('tv',['IGI','GRG','III'],{'I':'minecraft:iron_ingot','G':'minecraft:glass','R':'minecraft:redstone_lamp'})
im=Image.new('RGBA',(16,16));d=ImageDraw.Draw(im)
d.rounded_rectangle((1,4,14,12),radius=3,fill=(62,70,85),outline=(139,152,174))
d.rectangle((3,7,7,8),fill=(17,22,31));d.rectangle((5,5,5,10),fill=(17,22,31))
d.ellipse((10,6,11,7),fill=(223,82,88));d.ellipse((12,8,13,9),fill=(92,151,230))
d.rectangle((8,9,9,9),fill=(192,202,218));png(ASSETS/'textures/item/controller.png',im)
write(ASSETS/'models/item/controller.json',{'parent':'minecraft:item/generated','textures':{'layer0':'waylandconsoles:item/controller'}})
write(ASSETS/'items/controller.json',{'model':{'type':'minecraft:model','model':'waylandconsoles:item/controller'}})
recipe('controller',['IRI',' B '],{'I':'minecraft:iron_nugget','R':'minecraft:redstone','B':'minecraft:stone_button'})
write(ASSETS/'lang/en_us.json',lang)
write(RES/'data/minecraft/tags/block/mineable/pickaxe.json',{'replace':False,'values':['waylandconsoles:tv']+['waylandconsoles:'+e.lower()+'_console' for e,_,_ in systems]})
png(ASSETS/'icon.png', im.resize((128,128),Image.Resampling.NEAREST))
print(f'Generated {len(systems)} console blocks, TV, controller, recipes and loot.')
