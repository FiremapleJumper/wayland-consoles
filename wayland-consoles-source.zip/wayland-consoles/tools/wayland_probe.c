#define _GNU_SOURCE
#include <wayland-client.h>
#include "xdg-shell-client-protocol.h"
#include <sys/mman.h>
#include <unistd.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

static struct wl_display *display;
static struct wl_compositor *compositor;
static struct wl_shm *shm;
static struct wl_surface *surface;
static struct wl_buffer *buffer;
static struct xdg_wm_base *shell;
static int configured;
static void shmformat(void*d,struct wl_shm*s,uint32_t format){}
static const struct wl_shm_listener shm_events={.format=shmformat};
static void buffer_release(void*d,struct wl_buffer*b){}
static const struct wl_buffer_listener buffer_events={.release=buffer_release};
static void topconfigure(void*d,struct xdg_toplevel*t,int32_t w,int32_t h,struct wl_array*states){}
static void topclose(void*d,struct xdg_toplevel*t){exit(0);}
static const struct xdg_toplevel_listener top_events={.configure=topconfigure,.close=topclose};
static void keymap(void *d,struct wl_keyboard*k,uint32_t f,int fd,uint32_t size){close(fd);}
static void kenter(void*d,struct wl_keyboard*k,uint32_t s,struct wl_surface*w,struct wl_array*a){}
static void kleave(void*d,struct wl_keyboard*k,uint32_t s,struct wl_surface*w){}
static void key(void*d,struct wl_keyboard*k,uint32_t s,uint32_t t,uint32_t code,uint32_t state){printf("key %u %u\n",code,state);fflush(stdout);}
static void modifiers(void*d,struct wl_keyboard*k,uint32_t s,uint32_t a,uint32_t b,uint32_t c,uint32_t g){}
static const struct wl_keyboard_listener keys={.keymap=keymap,.enter=kenter,.leave=kleave,.key=key,.modifiers=modifiers};
static void penter(void*d,struct wl_pointer*p,uint32_t s,struct wl_surface*w,wl_fixed_t x,wl_fixed_t y){}
static void pleave(void*d,struct wl_pointer*p,uint32_t s,struct wl_surface*w){}
static void motion(void*d,struct wl_pointer*p,uint32_t t,wl_fixed_t x,wl_fixed_t y){}
static void button(void*d,struct wl_pointer*p,uint32_t s,uint32_t t,uint32_t b,uint32_t state){printf("button %u %u\n",b,state);fflush(stdout);}
static void axis(void*d,struct wl_pointer*p,uint32_t t,uint32_t a,wl_fixed_t v){}
static const struct wl_pointer_listener pointer={.enter=penter,.leave=pleave,.motion=motion,.button=button,.axis=axis};
static void capabilities(void*d,struct wl_seat*s,uint32_t caps){
    if(caps&WL_SEAT_CAPABILITY_KEYBOARD)wl_keyboard_add_listener(wl_seat_get_keyboard(s),&keys,NULL);
    if(caps&WL_SEAT_CAPABILITY_POINTER)wl_pointer_add_listener(wl_seat_get_pointer(s),&pointer,NULL);
}
static const struct wl_seat_listener seat={.capabilities=capabilities};
static void ping(void*d,struct xdg_wm_base*s,uint32_t serial){xdg_wm_base_pong(s,serial);}
static const struct xdg_wm_base_listener wm={.ping=ping};
static void global(void*d,struct wl_registry*r,uint32_t name,const char*interface,uint32_t version){
    if(!strcmp(interface,"wl_compositor"))compositor=wl_registry_bind(r,name,&wl_compositor_interface,1);
    if(!strcmp(interface,"wl_shm")){shm=wl_registry_bind(r,name,&wl_shm_interface,1);wl_shm_add_listener(shm,&shm_events,NULL);}
    if(!strcmp(interface,"xdg_wm_base")){shell=wl_registry_bind(r,name,&xdg_wm_base_interface,1);xdg_wm_base_add_listener(shell,&wm,NULL);}
    if(!strcmp(interface,"wl_seat")){struct wl_seat*s=wl_registry_bind(r,name,&wl_seat_interface,1);wl_seat_add_listener(s,&seat,NULL);}
}
static void removed(void*d,struct wl_registry*r,uint32_t name){}
static const struct wl_registry_listener registry={.global=global,.global_remove=removed};
static void configure(void*d,struct xdg_surface*s,uint32_t serial){
    xdg_surface_ack_configure(s,serial);
    if(!configured){configured=1;wl_surface_attach(surface,buffer,0,0);wl_surface_damage(surface,0,0,320,240);wl_surface_commit(surface);printf("mapped\n");fflush(stdout);}
}
static const struct xdg_surface_listener xsurface={.configure=configure};
int main(void){
    display=wl_display_connect(NULL);if(!display)return 2;
    wl_registry_add_listener(wl_display_get_registry(display),&registry,NULL);wl_display_roundtrip(display);
    if(!compositor||!shm||!shell)return 3;
    int size=320*240*4,fd=memfd_create("wayland-console-probe",MFD_CLOEXEC);if(fd<0||ftruncate(fd,size))return 4;
    uint32_t*p=mmap(NULL,size,PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);
    for(int y=0;y<240;y++)for(int x=0;x<320;x++)p[y*320+x]=y<120?(x<160?0xffff4040:0xff40ff80):(x<160?0xff4080ff:0xffffd050);
    struct wl_shm_pool*pool=wl_shm_create_pool(shm,fd,size);buffer=wl_shm_pool_create_buffer(pool,0,320,240,320*4,WL_SHM_FORMAT_ARGB8888);wl_buffer_add_listener(buffer,&buffer_events,NULL);wl_shm_pool_destroy(pool);close(fd);
    surface=wl_compositor_create_surface(compositor);
    struct xdg_surface*xs=xdg_wm_base_get_xdg_surface(shell,surface);xdg_surface_add_listener(xs,&xsurface,NULL);
    struct xdg_toplevel*top=xdg_surface_get_toplevel(xs);xdg_toplevel_add_listener(top,&top_events,NULL);xdg_toplevel_set_title(top,"Wayland Consoles · compositor test");xdg_toplevel_set_app_id(top,"waylandconsoles.probe");
    wl_surface_commit(surface);while(wl_display_dispatch(display)>=0){}
    return 0;
}
