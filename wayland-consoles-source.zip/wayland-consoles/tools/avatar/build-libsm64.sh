#!/usr/bin/env bash
set -eu
project_dir=$(cd -- "$(dirname -- "$0")/../.." && pwd)
source_dir="$project_dir/build/libsm64-avatar-source"
if ! test -f "$source_dir/Makefile"; then
    mkdir -p "$source_dir"
    tar -xzf "$project_dir/tools/avatar/libsm64-source.tar.gz" -C "$source_dir"
fi
make -C "$source_dir" lib -j4
cp "$source_dir/dist/libsm64.so" "$project_dir/src/main/resources/avatar_import/libsm64-avatar.so"
