# Avatar importer sources

Mario import uses [libsm64](https://github.com/libsm64/libsm64), pinned to
`fd11813208272b4271d92bd92feb8f3fdbe61be5`. Upstream declares CC0 1.0 Universal;
the complete license is in `third-party-licenses/libsm64-CC0.txt`.
`libsm64-avatar.patch` adds a small pose-sampling export. The importer loads local ROM
textures/animation data, samples native geometry, and bakes a private cache.
The packaged native library is compiled from that revision plus the patch.
Upstream's geometry import script itself pins the n64decomp/sm64 Mario geometry sources
to `06ec56df7f951f88da05f468cdcacecba496145a`. This is not extraction of every Mario
vertex from a ROM. `libsm64-source.tar.gz` contains the corresponding modified source,
including generated geometry code, for an offline rebuild. The patch is also included
separately for review. Rebuild with `tools/avatar/build-libsm64.sh`.

Link import is a new Python reader for the user's ROM file table, Yaz0 compression,
21-limb skeleton, animation frames, N64 display lists and textures. Offset/format metadata
was transcribed from the [zeldaret/oot](https://github.com/zeldaret/oot) project:

- `baseroms/ntsc-1.2/config.yml` and `segments.csv`
- `assets/xml/objects/object_link_boy.xml` and `object_link_child.xml`
- `assets/xml/misc/link_animetion.xml` and `gameplay_keep.xml`
- `include/animation.h` (joint/frame layout)
- `assets/xml/textures/icon_item_static.xml` and `parameter_static.xml` (interface layouts)
- `src/audio/game/general.c` (ocarina button sequences)

Those files describe formats, file indices and offsets, not bundled character textures or
extracted meshes. Retrieved October 31, 2026. OoT USA Rev 2 is the only OoT revision mapped
in this release. Other releases need their own verified offset tables.

`src/main/resources/avatar_import/` contains the standalone importer, JSON metadata and
Mario native helper. The HUD atlas is generated locally as `oot-ui.zip`; it is not bundled.
No ROM or generated `.avz` cache belongs in a distributable JAR or
source archive. Imported caches remain in the user's Minecraft configuration directory.
The helper is currently built for Linux x86_64. Python uses only the standard library.
