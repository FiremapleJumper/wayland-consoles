#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build/probe
protocols="$(pkg-config --variable=pkgdatadir wayland-protocols)"
wayland-scanner client-header "$protocols/stable/xdg-shell/xdg-shell.xml" build/probe/xdg-shell-client-protocol.h
wayland-scanner private-code "$protocols/stable/xdg-shell/xdg-shell.xml" build/probe/xdg-shell-protocol.c
cc -O2 -Ibuild/probe tools/wayland_probe.c build/probe/xdg-shell-protocol.c $(pkg-config --cflags --libs wayland-client) -o build/probe/wayland-probe
