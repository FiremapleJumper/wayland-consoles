#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
cargo build --locked --release --manifest-path native/Cargo.toml
./gradlew build "$@"
