package dev.evvie.waylandcraft.gui;

import dev.evvie.waylandcraft.*;
import dev.evvie.waylandcraft.console.*;
import net.minecraft.client.gui.*;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

/** Explicit fallback for emulator launchers and Xwayland satellite process IDs. */
public final class AttachWindowScreen extends Screen {
    private final WaylandCraft wlc;
    private final Screen parent;
    private final BlockPos tv, console;
    private final ConsoleType type;
    public AttachWindowScreen(WaylandCraft wlc, Screen parent, BlockPos tv, BlockPos console, ConsoleType type) {
        super(Component.literal("Attach a Wayland window"));
        this.wlc = wlc; this.parent = parent; this.tv = tv; this.console = console; this.type = type;
    }
    @Override protected void init() {
        int y = 42;
        if (wlc.bridge != null) for (var window : wlc.bridge.getMappedToplevels()) {
            if (y > height - 50) break;
            String label = window.title == null ? "Untitled window" : window.title;
            addRenderableWidget(Button.builder(Component.literal(font.plainSubstrByWidth(label, 290)), b -> {
                if (!wlc.validPair(tv, console, type)) { WaylandCraft.message("TV or console is missing."); return; }
                var session = wlc.sessions.get(tv);
                if (session == null) { session = new EmulatorSession(tv, console, type); wlc.sessions.put(tv, session); }
                for (var other : wlc.sessions.values()) if (other.window == window) other.window = null;
                session.window = window; session.status = "Attached";
                minecraft.gui.setScreen(new TVControlScreen(wlc, session));
            }).bounds(width / 2 - 150, y, 300, 20).build());
            y += 24;
        }
        addRenderableWidget(Button.builder(Component.literal("Refresh"), b -> rebuildWidgets()).bounds(width / 2 - 150, height - 27, 145, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Back"), b -> onClose()).bounds(width / 2 + 5, height - 27, 145, 20).build());
    }
    @Override public void onClose() { minecraft.gui.setScreen(parent); }
    @Override public boolean isPauseScreen() { return false; }
    @Override public void extractRenderState(GuiGraphicsExtractor g, int x, int y, float dt) {
        g.fill(0, 0, width, height, 0xff101827); g.centeredText(font, title, width / 2, 15, -1);
        super.extractRenderState(g, x, y, dt);
    }
}
