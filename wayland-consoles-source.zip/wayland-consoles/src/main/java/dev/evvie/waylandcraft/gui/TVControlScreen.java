package dev.evvie.waylandcraft.gui;

import com.mojang.blaze3d.platform.InputConstants;
import dev.evvie.waylandcraft.WaylandCraft;
import dev.evvie.waylandcraft.console.*;
import dev.evvie.waylandcraft.bridge.*;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.*;
import net.minecraft.network.chat.Component;
import java.util.*;

public final class TVControlScreen extends Screen {
    private final WaylandCraft wlc;
    private final EmulatorSession session;
    private final Set<Integer> keys = new HashSet<>(), buttons = new HashSet<>();
    private boolean hardCapture;
    private WLCToplevel focused;
    private int x, y, w, h;
    public TVControlScreen(WaylandCraft wlc, EmulatorSession session) {
        super(Component.literal("TV · " + session.console.label)); this.wlc = wlc; this.session = session;
    }
    @Override public boolean isPauseScreen() { return false; }
    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public void tick() {
        if (!wlc.sessions.containsValue(session)) { onClose(); return; }
        if (wlc.bridge != null && session.window != focused) {
            release(); focused = session.window;
            if (focused != null) { wlc.bridge.focusSurface(focused); wlc.bridge.activateKeyboard(); }
        }
    }
    @Override public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float dt) {
        g.fill(0, 0, width, height, 0xff05070b);
        var fb = focused == null ? null : focused.getFramebuffer();
        if (fb != null && fb.isValid()) {
            double scale = Math.min((width - 12.0) / fb.getWidth(), (height - 38.0) / fb.getHeight());
            w = Math.max(1, (int) (fb.getWidth() * scale)); h = Math.max(1, (int) (fb.getHeight() * scale));
            x = (width - w) / 2; y = (height - 24 - h) / 2;
            g.blit(fb.getTextureLocation(), x, y, x + w, y + h, 0, 1, 0, 1);
        } else { g.centeredText(font, session.status, width / 2, height / 2, 0xffb3c8e4); }
        g.centeredText(font, hardCapture ? "Keyboard captured · Alt+Q releases (Esc goes to game)" : "Esc: release TV · Alt+Q: capture Esc · emulator controls apply",
                width / 2, height - 16, 0xffb3c8e4);
    }
    @Override public boolean keyPressed(KeyEvent event) {
        if (event.key() == InputConstants.KEY_Q && (event.modifiers() & InputConstants.MOD_ALT) != 0) {
            release(); hardCapture = !hardCapture;
            if (focused != null) { wlc.bridge.focusSurface(focused); wlc.bridge.activateKeyboard(); }
            return true;
        }
        if (event.key() == InputConstants.KEY_ESCAPE && !hardCapture) { onClose(); return true; }
        int key = LinuxKeymap.toXkb(event.key());
        if (key > 0 && focused != null && keys.add(key)) {
            wlc.bridge.internalKeyUpdate(key, true); wlc.bridge.pressKey(key);
        }
        return true;
    }
    @Override public boolean keyReleased(KeyEvent event) {
        int key = LinuxKeymap.toXkb(event.key());
        if (keys.remove(key) && wlc.bridge != null) {
            wlc.bridge.internalKeyUpdate(key, false); wlc.bridge.releaseKey(key);
        }
        return true;
    }
    private void motion(double mx, double my) {
        if (focused == null || w < 1 || h < 1) return;
        var fb = focused.getFramebuffer();
        if (fb == null) return;
        double sx = (mx - x) * fb.getWidth() / w - fb.getXOff();
        double sy = (my - y) * fb.getHeight() / h - fb.getYOff();
        WLCSurface target = null; double tx = 0, ty = 0;
        for (var surface : focused.getRootSurface().getInputTree()) {
            double px = sx - surface.xSubpos, py = sy - surface.ySubpos;
            if (px >= 0 && py >= 0 && px < surface.width() && py < surface.height() && surface.inputRegionContains(px, py)) {
                target = surface; tx = px; ty = py; break;
            }
        }
        wlc.bridge.sendMotionRefocus(target, tx, ty);
    }
    @Override public void mouseMoved(double mx, double my) { motion(mx, my); }
    @Override public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) { motion(event.x(), event.y()); return true; }
    @Override public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        motion(event.x(), event.y());
        int code = LinuxKeymap.mouseButton(event.button());
        if (code > 0 && focused != null && buttons.add(code)) wlc.bridge.sendButton(code, 1);
        return true;
    }
    @Override public boolean mouseReleased(MouseButtonEvent event) {
        int code = LinuxKeymap.mouseButton(event.button());
        if (buttons.remove(code) && wlc.bridge != null) wlc.bridge.sendButton(code, 0);
        return true;
    }
    @Override public boolean mouseScrolled(double mx, double my, double dx, double dy) {
        motion(mx, my);
        if (focused != null) { wlc.bridge.sendScroll(0, -dy); wlc.bridge.sendScroll(1, -dx); }
        return true;
    }
    private void release() {
        if (wlc.bridge != null) {
            keys.forEach(k -> { wlc.bridge.internalKeyUpdate(k, false); wlc.bridge.releaseKey(k); });
            buttons.forEach(b -> wlc.bridge.sendButton(b, 0));
            wlc.bridge.deactivateKeyboard(); wlc.bridge.sendMotionOutside();
        }
        keys.clear(); buttons.clear();
    }
    @Override public void removed() { release(); }
    @Override public void onClose() { minecraft.gui.setScreen(null); }
}
