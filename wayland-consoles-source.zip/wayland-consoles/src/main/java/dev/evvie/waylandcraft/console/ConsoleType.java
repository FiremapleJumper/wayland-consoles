package dev.evvie.waylandcraft.console;

import java.util.*;

public enum ConsoleType {
    NES("NES", "nes,fds,unf,unif,zip", "nestopia_libretro.so", 0xaaaeb6),
    SNES("SNES", "sfc,smc,zip", "snes9x_libretro.so", 0x9687b5),
    N64("Nintendo 64", "z64,n64,v64", "mupen64plus_next_libretro.so", 0x44464d),
    GAMEBOY("Game Boy", "gb,zip", "gambatte_libretro.so", 0xb1bb8a),
    GBC("Game Boy Color", "gbc,zip", "gambatte_libretro.so", 0x7956a0),
    GBA("Game Boy Advance", "gba,zip", "mgba_libretro.so", 0x7163ae),
    NDS("Nintendo DS", "nds", "melonds_libretro.so", 0xc7cbd1),
    THREEDS("Nintendo 3DS", "3ds,cci,cxi", "", 0x456590),
    MASTER_SYSTEM("Master System", "sms,zip", "genesis_plus_gx_libretro.so", 0x9b4045),
    GENESIS("Mega Drive / Genesis", "md,gen,smd,bin,zip", "genesis_plus_gx_libretro.so", 0x414554),
    GAME_GEAR("Game Gear", "gg,zip", "genesis_plus_gx_libretro.so", 0x494955),
    SEGA_CD("Sega CD", "cue,chd,m3u", "genesis_plus_gx_libretro.so", 0x535968),
    SATURN("Sega Saturn", "cue,chd,m3u", "mednafen_saturn_libretro.so", 0x737887),
    DREAMCAST("Dreamcast", "gdi,chd,cdi,m3u", "flycast_libretro.so", 0xe1ded5),
    PS1("PlayStation", "cue,chd,pbp,m3u,iso", "swanstation_libretro.so", 0xb7b9bd),
    PS2("PlayStation 2", "iso,chd,elf", "", 0x343952),
    PSP("PSP", "iso,cso,pbp", "ppsspp_libretro.so", 0x4b5065),
    GAMECUBE("GameCube", "iso,gcm,rvz,ciso,dol,elf", "", 0x66528b),
    WII("Wii", "iso,wbfs,rvz,ciso,dol,elf", "", 0xd4d8df),
    XBOX("Xbox", "iso,xiso,xbe", "", 0x405a3a),
    ATARI2600("Atari 2600", "a26,bin,zip", "stella_libretro.so", 0x9c6d47),
    SM64COOPDX("SM64 CoopDX", "", "", 0xc34842);

    public final String label, core;
    public final Set<String> extensions;
    public final int color;
    ConsoleType(String label, String extensions, String core, int color) {
        this.label = label; this.core = core; this.color = color;
        this.extensions = extensions.isEmpty() ? Set.of() : Set.of(extensions.split(","));
    }
    public String id() { return name().toLowerCase(Locale.ROOT); }
    public boolean accepts(String filename) {
        int dot = filename.lastIndexOf('.');
        return dot >= 0 && extensions.contains(filename.substring(dot + 1).toLowerCase(Locale.ROOT));
    }
    public List<String> defaultCommand() {
        return switch (this) {
            case GAMECUBE, WII -> List.of("dolphin-emu", "--exec", "{rom}");
            case XBOX -> List.of("xemu", "-dvd_path", "{rom}");
            case PS2 -> List.of("pcsx2-qt", "{rom}");
            case THREEDS -> List.of("azahar", "{rom}");
            case SM64COOPDX -> List.of("sm64coopdx");
            default -> List.of("retroarch", "-L", "{coreDir}/" + core, "{rom}");
        };
    }
}
