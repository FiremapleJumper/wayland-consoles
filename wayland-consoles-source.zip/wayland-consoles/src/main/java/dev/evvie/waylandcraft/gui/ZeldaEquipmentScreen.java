package dev.evvie.waylandcraft.gui;

import dev.evvie.waylandcraft.adventure.*;
import dev.evvie.waylandcraft.WaylandCraft;
import net.minecraft.client.gui.*;
import net.minecraft.client.gui.components.*;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.util.*;

public final class ZeldaEquipmentScreen extends Screen {
    private int tab,page;
    private ZeldaGear selected;
    private List<ZeldaGear> items=List.of();
    private static final String[] tabs={"Items","Equipment","Bottles","Masks","Controls"};
    public ZeldaEquipmentScreen(){super(Component.literal("Ocarina equipment"));}
    @Override protected void init(){
        int left=width/2-185;
        for(int i=0;i<tabs.length;i++){int index=i;addRenderableWidget(Button.builder(Component.literal(tabs[i]),b->{tab=index;page=0;rebuildWidgets();}).bounds(left+i*75,23,72,19).build());}
        if(tab<4){
            items=Arrays.stream(ZeldaGear.values()).filter(g->g.allowed(AdventureState.child())).filter(g->switch(tab){case 0->g.group.equals("items");case 1->g.equipment()&&!g.group.equals("masks");case 2->g.group.equals("bottles");default->g.group.equals("masks");}).toList();
            int start=page*18;
            for(int n=0;n<18&&start+n<items.size();n++){
                var item=items.get(start+n);int index=n;
                var button=Button.builder(Component.literal(" "),b->{selected=item;if(item.equipment())AdventureState.equip(item);})
                    .bounds(left+(n%6)*35,57+(n/6)*35,33,33).tooltip(Tooltip.create(Component.literal(item.label+"\n"+item.description+"\nRequires: "+item.requirement.getDefaultInstance().getItemName().getString()))).build();
                addRenderableWidget(button);
            }
            addRenderableWidget(Button.builder(Component.literal("<"),b->{page=Math.max(0,page-1);rebuildWidgets();}).bounds(left,45,20,11).build());
            addRenderableWidget(Button.builder(Component.literal(">"),b->{page=Math.min((items.size()-1)/18,page+1);rebuildWidgets();}).bounds(left+188,45,20,11).build());
            for(int i=0;i<3;i++){int slot=i;addRenderableWidget(Button.builder(Component.literal("Assign "+AdventureControls.slots[i].getTranslatedKeyMessage().getString()),b->{if(selected!=null)AdventureState.assign(slot,selected);}).bounds(left+i*72,height-49,69,20).build());}
        }else{
            addRenderableWidget(Button.builder(Component.literal("Bomb terrain damage: "+(WaylandCraft.instance.config.adventureTerrainDamage?"ON":"OFF")),b->{WaylandCraft.instance.config.adventureTerrainDamage=!WaylandCraft.instance.config.adventureTerrainDamage;AdventureState.save();rebuildWidgets();}).bounds(left+8,150,355,20).build());
        }
        addRenderableWidget(Button.builder(Component.literal("Unlocked kit: "+(AdventureState.sandbox()?"ON":"OFF")),b->{AdventureState.toggleSandbox();rebuildWidgets();}).bounds(left,height-25,255,20).build());
        addRenderableWidget(Button.builder(Component.literal("Back"),b->onClose()).bounds(left+260,height-25,110,20).build());
    }
    @Override public void extractRenderState(GuiGraphicsExtractor g,int mx,int my,float dt){
        g.fill(0,0,width,height,0xf0192434);g.centeredText(font,title,width/2,8,0xfff0e5a6);
        int left=width/2-185;
        super.extractRenderState(g,mx,my,dt);
        if(tab<4){
            g.text(font,(page+1)+" / "+Math.max(1,(items.size()+17)/18),left+86,46,0xffb6c9de,false);
            for(int n=0;n<18&&page*18+n<items.size();n++){
                var item=items.get(page*18+n);int x=left+n%6*35,y=57+n/6*35;
                ZeldaInterface.icon(g,item,x+4,y+4,25);
                if(!AdventureState.available(item)){g.fill(x+1,y+1,x+32,y+32,0x9908111c);g.text(font,"×",x+23,y+22,0xffff8877,false);}
                if(item==selected){g.fill(x,y,x+33,y+2,0xffffdc62);g.fill(x,y+31,x+33,y+33,0xffffdc62);}
            }
            if(items.isEmpty())g.textWithWordWrap(font,Component.literal("Masks are worn by Young Link."),left,67,208,0xffc0d4ec);
            int dx=left+222;g.fill(dx-4,48,left+370,height-54,0xff0e1724);
            if(selected!=null){
                ZeldaInterface.icon(g,selected,dx+50,53,32);
                g.textWithWordWrap(font,Component.literal(selected.label),dx,90,140,0xfff5e2a4);
                g.textWithWordWrap(font,Component.literal(selected.description),dx,112,140,0xffc0d4ec);
                String cost=AdventureState.sandbox()?"Unlocked kit": "Requires: "+selected.requirement.getDefaultInstance().getItemName().getString();
                g.textWithWordWrap(font,Component.literal(cost),left,166,210,AdventureState.available(selected)?0xff99e5ad:0xffffa595);
            }else g.textWithWordWrap(font,Component.literal("Select equipment to wear it. Select an item, then assign it to a button below."),dx,62,140,0xffc0d4ec);
        }else {
            String[] lines={"Attack: left click. Hold and release for a spin attack.","Target: "+AdventureControls.target.getTranslatedKeyMessage().getString()+"   Shield: hold "+AdventureControls.guard.getTranslatedKeyMessage().getString(),"Jump + back/side while targeting: backflip / side hop.","Run off an edge to auto-jump. Forward while falling: grab ledge.","Hanging: jump / forward to climb; crouch to drop.","Context: "+AdventureControls.context.getTranslatedKeyMessage().getString()+" to ready / throw a loose block.","Kit OFF: equipment and ammo must be in Minecraft inventory.","Rebind every action in Minecraft Options > Controls."};
            for(int i=0;i<lines.length;i++)g.text(font,lines[i],left+5,52+i*12,0xffc8d9eb,false);
        }
    }
    @Override public void onClose(){minecraft.gui.setScreen(null);}
    @Override public boolean isPauseScreen(){return false;}
}
