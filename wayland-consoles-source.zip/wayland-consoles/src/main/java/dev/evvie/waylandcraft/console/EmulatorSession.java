package dev.evvie.waylandcraft.console;

import dev.evvie.waylandcraft.bridge.WLCToplevel;
import net.minecraft.core.BlockPos;
import java.util.*;

public final class EmulatorSession {
    public final BlockPos tv, consolePos;
    public final ConsoleType console;
    public Process process;
    public WLCToplevel window;
    public Set<Long> pids = Set.of();
    public String status = "Starting emulator…";
    public long started = System.nanoTime();
    public EmulatorSession(BlockPos tv, BlockPos consolePos, ConsoleType console) {
        this.tv = tv.immutable(); this.consolePos = consolePos.immutable(); this.console = console;
    }
    public void stop() {
        if (process != null) {
            // Stop children before their parent; these are only processes started by this session.
            process.descendants().forEach(ProcessHandle::destroy);
            process.destroy();
            var owned = process;
            Thread.ofVirtual().start(() -> {
                try { if (!owned.waitFor(2, java.util.concurrent.TimeUnit.SECONDS)) owned.destroyForcibly(); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            });
        }
        window = null; status = "Stopped";
    }
}
