package dev.evvie.waylandcraft.console;

import com.mojang.blaze3d.platform.InputConstants;
import static org.lwjgl.sdl.SDLScancode.*;
import java.util.*;

/** SDL uses USB HID scancodes; Wayland's keymap uses Linux evdev + 8. */
public final class LinuxKeymap {
    private static final Map<Integer, Integer> KEYS = new HashMap<>();
    static {
        int[] letters = {30,48,46,32,18,33,34,35,23,36,37,38,50,49,24,25,16,19,31,20,22,47,17,45,21,44};
        for (int i = 0; i < letters.length; i++) KEYS.put(SDL_SCANCODE_A + i, letters[i] + 8);
        for (int i = 0; i < 9; i++) KEYS.put(SDL_SCANCODE_1 + i, i + 2 + 8);
        for (int i = 0; i < 10; i++) KEYS.put(SDL_SCANCODE_F1 + i, 59 + i + 8);
        int[][] pairs = {
            {SDL_SCANCODE_0,11},{SDL_SCANCODE_RETURN,28},{SDL_SCANCODE_ESCAPE,1},{SDL_SCANCODE_BACKSPACE,14},
            {SDL_SCANCODE_TAB,15},{SDL_SCANCODE_SPACE,57},{SDL_SCANCODE_MINUS,12},{SDL_SCANCODE_EQUALS,13},
            {SDL_SCANCODE_LEFTBRACKET,26},{SDL_SCANCODE_RIGHTBRACKET,27},{SDL_SCANCODE_BACKSLASH,43},
            {SDL_SCANCODE_SEMICOLON,39},{SDL_SCANCODE_APOSTROPHE,40},{SDL_SCANCODE_GRAVE,41},
            {SDL_SCANCODE_COMMA,51},{SDL_SCANCODE_PERIOD,52},{SDL_SCANCODE_SLASH,53},{SDL_SCANCODE_CAPSLOCK,58},
            {SDL_SCANCODE_F11,87},{SDL_SCANCODE_F12,88},{SDL_SCANCODE_PRINTSCREEN,99},{SDL_SCANCODE_SCROLLLOCK,70},
            {SDL_SCANCODE_PAUSE,119},{SDL_SCANCODE_INSERT,110},{SDL_SCANCODE_HOME,102},{SDL_SCANCODE_PAGEUP,104},
            {SDL_SCANCODE_DELETE,111},{SDL_SCANCODE_END,107},{SDL_SCANCODE_PAGEDOWN,109},{SDL_SCANCODE_RIGHT,106},
            {SDL_SCANCODE_LEFT,105},{SDL_SCANCODE_DOWN,108},{SDL_SCANCODE_UP,103},{SDL_SCANCODE_NUMLOCKCLEAR,69},
            {SDL_SCANCODE_KP_DIVIDE,98},{SDL_SCANCODE_KP_MULTIPLY,55},{SDL_SCANCODE_KP_MINUS,74},{SDL_SCANCODE_KP_PLUS,78},
            {SDL_SCANCODE_KP_ENTER,96},{SDL_SCANCODE_KP_1,79},{SDL_SCANCODE_KP_2,80},{SDL_SCANCODE_KP_3,81},
            {SDL_SCANCODE_KP_4,75},{SDL_SCANCODE_KP_5,76},{SDL_SCANCODE_KP_6,77},{SDL_SCANCODE_KP_7,71},
            {SDL_SCANCODE_KP_8,72},{SDL_SCANCODE_KP_9,73},{SDL_SCANCODE_KP_0,82},{SDL_SCANCODE_KP_PERIOD,83},
            {SDL_SCANCODE_NONUSBACKSLASH,86},{SDL_SCANCODE_APPLICATION,127},{SDL_SCANCODE_LCTRL,29},
            {SDL_SCANCODE_LSHIFT,42},{SDL_SCANCODE_LALT,56},{SDL_SCANCODE_LGUI,125},{SDL_SCANCODE_RCTRL,97},
            {SDL_SCANCODE_RSHIFT,54},{SDL_SCANCODE_RALT,100},{SDL_SCANCODE_RGUI,126}
        };
        for (var pair : pairs) KEYS.put(pair[0], pair[1] + 8);
    }
    public static int toXkb(int sdlScancode) { return KEYS.getOrDefault(sdlScancode, -1); }
    public static int mouseButton(int button) {
        if (button == InputConstants.MOUSE_BUTTON_LEFT) return 0x110;
        if (button == InputConstants.MOUSE_BUTTON_RIGHT) return 0x111;
        if (button == InputConstants.MOUSE_BUTTON_MIDDLE) return 0x112;
        if (button == InputConstants.MOUSE_BUTTON_4) return 0x113;
        if (button == InputConstants.MOUSE_BUTTON_5) return 0x114;
        return -1;
    }
}
