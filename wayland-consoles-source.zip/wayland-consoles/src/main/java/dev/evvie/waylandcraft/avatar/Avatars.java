package dev.evvie.waylandcraft.avatar;

import com.mojang.blaze3d.platform.NativeImage;
import dev.evvie.waylandcraft.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;
import java.io.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

/** Imports only locally selected/found ROMs; no download or game-code execution. */
public final class Avatars {
    public record Loaded(AvatarModel model, Identifier texture) {}
    private static final Map<String, Loaded> loaded = new HashMap<>();
    private static long generation;
    private static String pending = "";
    public static Loaded get(String mode) { return loaded.get(mode); }
    public static String pending() { return pending; }
    public static void cancel() { generation++; pending = ""; }

    public static void prepare(String mode, Runnable ready) {
        if (loaded.containsKey(mode)) { cancel(); ready.run(); return; }
        long ticket = ++generation;
        pending = mode;
        WaylandCraft.message("Importing " + (mode.equals("sm64") ? "Mario" : "Link") + " from your local ROM. This may take a moment…");
        var wlc = WaylandCraft.instance;
        CompletableFuture.supplyAsync(() -> {
            try {
                Path cache = wlc.root.resolve("avatars").resolve(mode + ".avz");
                if (Files.isRegularFile(cache) && (mode.equals("sm64") || Files.isRegularFile(cache.getParent().resolve("oot-ui.zip")))) {
                    try { return AvatarModel.load(cache); }
                    catch (IOException ex) { WaylandCraftCommon.LOGGER.warn("Reimporting avatar cache", ex); }
                }
                String game = mode.equals("sm64") ? "sm64" : "oot";
                Path rom = findRom(game);
                Path tools = wlc.root.resolve("avatar-tools-v3");
                Files.createDirectories(tools); Files.createDirectories(cache.getParent());
                for (String file : List.of("import_avatars.py", "libsm64-avatar.so", "oot-layout.json", "oot-shared-layout.json", "oot-interface-layout.json")) {
                    try (var in = Avatars.class.getResourceAsStream("/avatar_import/" + file)) {
                        if (in == null) throw new IOException("Missing bundled importer: " + file);
                        Files.copy(in, tools.resolve(file), StandardCopyOption.REPLACE_EXISTING);
                    }
                }
                Path log = wlc.root.resolve("logs/avatar-import-" + game + ".log");
                var process = new ProcessBuilder(wlc.config.avatarPython, tools.resolve("import_avatars.py").toAbsolutePath().toString(),
                        "--game", game, "--rom", rom.toAbsolutePath().toString(), "--output", cache.getParent().toAbsolutePath().toString())
                        .redirectErrorStream(true).redirectOutput(log.toFile()).start();
                try {
                    if (!process.waitFor(120, TimeUnit.SECONDS)) throw new IOException("Avatar import timed out; see " + log);
                    if (process.exitValue() != 0) throw new IOException("Avatar import failed; see " + log);
                } finally { if (process.isAlive()) process.destroyForcibly(); }
                return AvatarModel.load(cache);
            } catch (Exception ex) { throw new CompletionException(ex); }
        }, wlc.io).whenComplete((model, ex) -> Minecraft.getInstance().execute(() -> {
            if (ticket != generation) return;
            pending = "";
            if (ex != null) {
                WaylandCraft.message("Model import: " + (ex.getCause() == null ? ex.getMessage() : ex.getCause().getMessage()));
                WaylandCraftCommon.LOGGER.error("Avatar import failed", ex); return;
            }
            try {
                var pixels = NativeImage.read(new ByteArrayInputStream(model.atlas()));
                if (pixels.getWidth() > 4096 || pixels.getHeight() > 4096) { pixels.close(); throw new IOException("Avatar atlas too large"); }
                var texture = new DynamicTexture(() -> "Imported " + model.name(), pixels);
                Identifier id = WaylandCraftCommon.id("avatar/" + mode);
                Minecraft.getInstance().getTextureManager().register(id, texture);
                if (!mode.equals("sm64")) dev.evvie.waylandcraft.adventure.ZeldaInterface.load(wlc.root.resolve("avatars/oot-ui.zip"));
                loaded.put(mode, new Loaded(model, id));
                ready.run();
            } catch (Exception failure) { WaylandCraft.message("Could not load model texture: " + failure.getMessage()); }
        }));
    }

    /** Scan a bounded tree, examining N64 headers rather than trusting filenames. */
    public static Path findRom(String game) throws IOException {
        var wlc = WaylandCraft.instance;
        String selected = wlc.config.avatarRoms.get(game);
        if (selected != null && !selected.isBlank()) {
            Path explicit = expand(selected);
            if (!matches(explicit, game)) throw new IOException("Unsupported " + game + " ROM: " + explicit);
            return explicit;
        }
        List<Path> roots = new ArrayList<>();
        roots.add(wlc.root.resolve("roms/n64"));
        for (String folder : wlc.config.romSearchPaths) if (folder != null && !folder.isBlank()) roots.add(expand(folder));
        for (Path root : roots) {
            if (!Files.isDirectory(root)) continue;
            try (var files = Files.walk(root, 6)) {
                var iterator = files.limit(12000).iterator();
                while (iterator.hasNext()) {
                    Path path = iterator.next();
                    String name = path.getFileName().toString().toLowerCase(Locale.ROOT);
                    if ((name.endsWith(".z64") || name.endsWith(".n64") || name.endsWith(".v64")) && matches(path, game)) return path;
                }
            } catch (UncheckedIOException ex) { WaylandCraftCommon.LOGGER.warn("Could not search ROM folder {}", root, ex); }
        }
        throw new IOException("No supported ROM found in Downloads. Needs " + (game.equals("sm64") ? "Super Mario 64 USA" : "Ocarina of Time USA Rev 2") + ". Set avatarRoms in config.json to choose a file.");
    }
    private static Path expand(String value) {
        return Path.of(value.startsWith("~/") ? System.getProperty("user.home") + value.substring(1) : value);
    }
    private static boolean matches(Path path, String game) {
        try {
            if (!Files.isRegularFile(path) || Files.size(path) < 8 * 1024 * 1024 || Files.size(path) > 128 * 1024 * 1024) return false;
            byte[] header;
            try (var in = Files.newInputStream(path)) { header = in.readNBytes(64); }
            if (header.length != 64) return false;
            if ((header[0] & 255) == 0x37) for (int i = 0; i < 64; i += 2) { byte a = header[i]; header[i] = header[i+1]; header[i+1] = a; }
            else if ((header[0] & 255) == 0x40) for (int i = 0; i < 64; i += 4) {
                byte a = header[i], b = header[i+1]; header[i] = header[i+3]; header[i+1] = header[i+2]; header[i+2] = b; header[i+3] = a;
            }
            if ((header[0] & 255) != 0x80 || header[1] != 0x37 || header[2] != 0x12 || header[3] != 0x40 || header[0x3e] != 'E') return false;
            String title = new String(header, 0x20, 20, StandardCharsets.US_ASCII);
            return game.equals("sm64") ? title.contains("SUPER MARIO 64") : title.contains("ZELDA") && header[0x3f] == 2;
        } catch (IOException | SecurityException ex) { return false; }
    }
}
