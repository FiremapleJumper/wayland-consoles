package dev.evvie.waylandcraft.render;

import com.mojang.blaze3d.platform.NativeImage;
import dev.evvie.waylandcraft.bridge.WLCSurface;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;

/** Composites wl_shm and EGL snapshots, including subsurfaces and viewports. */
public class WindowFramebuffer {
    private final WLCSurface root;
    private DynamicTexture texture;
    private Identifier location;
    private int width, height, xoff, yoff;
    private boolean dirty;
    public WindowFramebuffer(WLCSurface root) { this.root = root; }
    public static void endFrame() { }

    public void render() { dirty = true; }

    public void uploadIfDirty() {
        if (!dirty) return;
        dirty = false;
        int minX = 0, minY = 0, maxX = 0, maxY = 0;
        for (var s : root.getDrawTree()) {
            minX = Math.min(minX, s.xSubpos); minY = Math.min(minY, s.ySubpos);
            maxX = Math.max(maxX, s.xSubpos + s.width()); maxY = Math.max(maxY, s.ySubpos + s.height());
        }
        int w = maxX - minX, h = maxY - minY;
        if (w < 1 || h < 1 || w > 4096 || h > 4096) return;
        if (texture == null || width != w || height != h) {
            destroy(); width = w; height = h;
            texture = new DynamicTexture("Wayland TV", w, h, true);
            location = Identifier.fromNamespaceAndPath("waylandconsoles", "surface/" + Integer.toUnsignedString(System.identityHashCode(this)));
            Minecraft.getInstance().getTextureManager().register(location, texture);
        }
        xoff = -minX; yoff = -minY;
        NativeImage dst = texture.getPixels();
        dst.fillRect(0, 0, width, height, 0);
        for (var s : root.getDrawTree()) {
            var b = s.getBuffer();
            if (b == null || s.width() < 1 || s.height() < 1) continue;
            var crop = s.getViewportSource();
            double cx = crop == null ? 0 : crop.x(), cy = crop == null ? 0 : crop.y();
            double cw = crop == null ? b.width : crop.width(), ch = crop == null ? b.height : crop.height();
            for (int y = 0; y < s.height(); y++) for (int x = 0; x < s.width(); x++) {
                int dx = x + s.xSubpos + xoff, dy = y + s.ySubpos + yoff;
                if (dx < 0 || dy < 0 || dx >= width || dy >= height) continue;
                int bx = Math.clamp((int) (cx + x * cw / s.width()), 0, b.width - 1);
                int by = Math.clamp((int) (cy + y * ch / s.height()), 0, b.height - 1);
                int src = b.pixels.getPixel(bx, by), alpha = src >>> 24;
                if (alpha == 0) continue;
                int old = dst.getPixel(dx, dy), inv = 255 - alpha;
                int a = Math.min(255, alpha + (old >>> 24) * inv / 255);
                int r = Math.min(255, (src >>> 16 & 255) + (old >>> 16 & 255) * inv / 255);
                int g = Math.min(255, (src >>> 8 & 255) + (old >>> 8 & 255) * inv / 255);
                int bl = Math.min(255, (src & 255) + (old & 255) * inv / 255);
                dst.setPixel(dx, dy, a << 24 | r << 16 | g << 8 | bl);
            }
        }
        texture.upload();
    }

    public void destroy() {
        if (location != null) Minecraft.getInstance().getTextureManager().release(location);
        texture = null; location = null;
    }
    public Identifier getTextureLocation() { return location; }
    public boolean isValid() { return texture != null; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }
    public int getXOff() { return xoff; }
    public int getYOff() { return yoff; }
}
