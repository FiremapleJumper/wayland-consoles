package dev.evvie.waylandcraft.render;

import com.mojang.blaze3d.platform.NativeImage;
import dev.evvie.waylandcraft.bridge.dmabuf.Dmabuf;
import dev.evvie.waylandcraft.egl.EGL;
import dev.evvie.waylandcraft.egl.EGLHelper;
import org.lwjgl.opengl.GL33;
import org.lwjgl.sdl.SDLVideo;
import org.lwjgl.system.JNI;
import org.lwjgl.system.MemoryUtil;

/** Owned pixel snapshots: no wl_shm pointers survive a native commit. */
public class BufferTexture {
    public static final int FORMAT_ARGB8888 = 0, FORMAT_XRGB8888 = 1;
    public final int width, height, format;
    public final NativeImage pixels;
    private boolean released;

    protected BufferTexture(int w, int h, int format) {
        if (w < 1 || h < 1 || w > 4096 || h > 4096) throw new IllegalArgumentException("Surface exceeds 4096 pixels");
        this.width = w; this.height = h; this.format = format;
        pixels = new NativeImage(w, h, true);
    }

    public static BufferTexture createShmTexture(long ptr, int w, int h, int format, int stride) {
        if (stride < (long) w * 4) throw new IllegalArgumentException("Invalid SHM stride");
        var out = new BufferTexture(w, h, format);
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            int argb = MemoryUtil.memGetInt(ptr + (long) y * stride + x * 4L);
            if (format == FORMAT_XRGB8888) argb |= 0xff000000;
            out.pixels.setPixel(x, y, argb);
        }
        return out;
    }

    public static BufferTexture createSinglePixelTexture(byte r, byte g, byte b, byte a) {
        var out = new BufferTexture(1, 1, FORMAT_ARGB8888);
        out.pixels.setPixel(0, 0, (a & 255) << 24 | (r & 255) << 16 | (g & 255) << 8 | (b & 255));
        return out;
    }

    public void release() { if (!released) { pixels.close(); released = true; } }

    public static DmabufTexture createDmabufTexture(Dmabuf buffer) {
        if (EGL.getEGLDisplay() == 0) return null;
        long image = EGLHelper.importDmabufToImage(EGL.getEGLDisplay(), buffer);
        if (image == EGL.EGL_NO_IMAGE) return null;
        return new DmabufTexture(buffer, image);
    }

    /** Readback keeps the compositor independent of Minecraft's changed GPU wrappers. */
    public static class DmabufTexture extends BufferTexture {
        private long image;
        private int texture;

        private DmabufTexture(Dmabuf buffer, long image) {
            super(buffer.width(), buffer.height(), FORMAT_ARGB8888);
            this.image = image;
            int previous = GL33.glGetInteger(GL33.GL_TEXTURE_BINDING_2D);
            texture = GL33.glGenTextures();
            try {
                GL33.glBindTexture(GL33.GL_TEXTURE_2D, texture);
                GL33.glTexParameteri(GL33.GL_TEXTURE_2D, GL33.GL_TEXTURE_MIN_FILTER, GL33.GL_NEAREST);
                GL33.glTexParameteri(GL33.GL_TEXTURE_2D, GL33.GL_TEXTURE_MAG_FILTER, GL33.GL_NEAREST);
                long proc = SDLVideo.SDL_GL_GetProcAddress("glEGLImageTargetTexture2DOES");
                if (proc == 0) throw new IllegalStateException("EGL image import is unavailable");
                JNI.invokeJV(GL33.GL_TEXTURE_2D, image, proc);
            } finally { GL33.glBindTexture(GL33.GL_TEXTURE_2D, previous); }
        }

        public void copyData() {
            if (image == 0) return;
            int previous = GL33.glGetInteger(GL33.GL_TEXTURE_BINDING_2D);
            int pack = GL33.glGetInteger(GL33.GL_PIXEL_PACK_BUFFER_BINDING);
            int row = GL33.glGetInteger(GL33.GL_PACK_ROW_LENGTH);
            int sx = GL33.glGetInteger(GL33.GL_PACK_SKIP_PIXELS), sy = GL33.glGetInteger(GL33.GL_PACK_SKIP_ROWS);
            try {
                GL33.glBindBuffer(GL33.GL_PIXEL_PACK_BUFFER, 0);
                GL33.glPixelStorei(GL33.GL_PACK_ROW_LENGTH, 0);
                GL33.glPixelStorei(GL33.GL_PACK_SKIP_PIXELS, 0);
                GL33.glPixelStorei(GL33.GL_PACK_SKIP_ROWS, 0);
                GL33.glBindTexture(GL33.GL_TEXTURE_2D, texture);
                GL33.nglGetTexImage(GL33.GL_TEXTURE_2D, 0, GL33.GL_RGBA, GL33.GL_UNSIGNED_BYTE, pixels.getPointer());
            } finally {
                GL33.glBindTexture(GL33.GL_TEXTURE_2D, previous);
                GL33.glBindBuffer(GL33.GL_PIXEL_PACK_BUFFER, pack);
                GL33.glPixelStorei(GL33.GL_PACK_ROW_LENGTH, row);
                GL33.glPixelStorei(GL33.GL_PACK_SKIP_PIXELS, sx);
                GL33.glPixelStorei(GL33.GL_PACK_SKIP_ROWS, sy);
            }
        }

        public void freeInternal() {
            if (image != 0) {
                EGL.eglDestroyImage(EGL.getEGLDisplay(), image); image = 0;
                GL33.glDeleteTextures(texture);
            }
            checkRelease();
        }
        public boolean isGone() { return image == 0; }
        @Override public void release() { checkRelease(); }
        private void checkRelease() {
            if (!isGone()) return;
            var client = dev.evvie.waylandcraft.WaylandCraft.instance;
            if (client != null && client.bridge != null)
                for (var surface : client.bridge.getAllSurfaces()) if (surface.getBuffer() == this) return;
            super.release();
        }
    }
}
