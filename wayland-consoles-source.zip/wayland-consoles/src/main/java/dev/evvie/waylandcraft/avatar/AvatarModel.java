package dev.evvie.waylandcraft.avatar;

import com.google.gson.*;
import java.io.*;
import java.nio.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

/** Private cache format: triangles, normals, material colours, UVs, and an atlas. */
public record AvatarModel(String name, Map<String, Clip> clips, byte[] atlas, int[] headTriangle) {
    public record Clip(float[][] frames, float fps) {}
    private static byte[] read(ZipFile zip, String name, int limit) throws IOException {
        var entry = zip.getEntry(name);
        if (entry == null || entry.getSize() < 0 || entry.getSize() > limit) throw new IOException("Invalid avatar entry: " + name);
        try (var in = zip.getInputStream(entry)) {
            byte[] bytes = in.readNBytes(limit + 1);
            if (bytes.length > limit) throw new IOException("Avatar entry too large: " + name);
            return bytes;
        }
    }
    public static AvatarModel load(Path path) throws IOException {
        try (var zip = new ZipFile(path.toFile())) {
            var manifest = JsonParser.parseString(new String(read(zip, "manifest.json", 65536), java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject();
            if (manifest.get("version").getAsInt() != 3) throw new IOException("Avatar cache needs reimporting");
            var bytes = ByteBuffer.wrap(read(zip, "frames.bin", 128 * 1024 * 1024)).order(ByteOrder.LITTLE_ENDIAN);
            Map<String, Clip> clips = new LinkedHashMap<>();
            for (var element : manifest.getAsJsonArray("clips")) {
                var clip = element.getAsJsonObject();
                int count = clip.get("frames").getAsInt();
                float fps = clip.get("fps").getAsFloat();
                if (clips.size() >= 64 || count < 1 || count > 150 || !Float.isFinite(fps) || fps < 1 || fps > 60) throw new IOException("Invalid animation");
                float[][] frames = new float[count][];
                for (int f = 0; f < count; f++) {
                    int vertices = bytes.getInt();
                    if (vertices < 3 || vertices > 20000 || vertices % 3 != 0) throw new IOException("Invalid avatar triangles");
                    float[] frame = new float[vertices * 11];
                    for (int v = 0; v < frame.length; v++) {
                        frame[v] = bytes.getFloat();
                        if (!Float.isFinite(frame[v]) || Math.abs(frame[v]) > 100) throw new IOException("Invalid avatar vertex");
                    }
                    frames[f] = frame;
                }
                clips.put(clip.get("name").getAsString(), new Clip(frames, fps));
            }
            if (bytes.hasRemaining() || !clips.containsKey("idle")) throw new IOException("Invalid avatar animation data");
            int[] head=null;
            if(manifest.has("headTriangle")){var ids=manifest.getAsJsonArray("headTriangle");if(ids.size()!=3)throw new IOException("Invalid head attachment");head=new int[3];for(int i=0;i<3;i++){head[i]=ids.get(i).getAsInt();if(head[i]<0||head[i]>=20000)throw new IOException("Invalid head vertex");}}
            return new AvatarModel(manifest.get("name").getAsString(), Map.copyOf(clips), read(zip, "atlas.png", 16 * 1024 * 1024), head);
        } catch (RuntimeException ex) { throw new IOException("Cannot read avatar cache: " + ex.getMessage(), ex); }
    }
}
