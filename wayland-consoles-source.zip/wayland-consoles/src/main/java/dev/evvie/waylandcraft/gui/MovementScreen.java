package dev.evvie.waylandcraft.gui;

import dev.evvie.waylandcraft.console.Adventures;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class MovementScreen extends Screen {
    private final Screen parent;
    public MovementScreen(Screen parent) { super(Component.literal("Imported characters · movement demos")); this.parent = parent; }
    @Override protected void init() {
        int left = width / 2 - 145, y = Math.max(90, height / 2 - 22);
        addRenderableWidget(Button.builder(Component.literal("Mario · model + SM64 movement"), b -> {
            Adventures.select("sm64"); minecraft.gui.setScreen(null);
        }).bounds(left, y, 290, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Adult Link · model + OoT movement"), b -> {
            Adventures.select("oot"); minecraft.gui.setScreen(null);
        }).bounds(left, y + 24, 290, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Young Link · model + OoT movement"), b -> {
            Adventures.select("oot_child"); minecraft.gui.setScreen(null);
        }).bounds(left, y + 48, 290, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Restore your player and camera"), b -> {
            Adventures.select("off"); minecraft.gui.setScreen(null);
        }).bounds(left, y + 72, 290, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Back"), b -> onClose()).bounds(left, height - 26, 290, 20).build());
    }
    @Override public void extractRenderState(GuiGraphicsExtractor g, int x, int y, float dt) {
        g.fill(0, 0, width, height, 0xff101827);
        g.centeredText(font, title, width / 2, 14, -1);
        g.textWithWordWrap(font, Component.literal("Imports models, textures and animations from local ROMs in Downloads. Needs SM64 USA or OoT USA Rev 2 and Python 3. Singleplayer movement uses Minecraft collisions; game worlds and quests stay on the TV."),
                width / 2 - 145, 35, 290, 0xffb3c8e4);
        super.extractRenderState(g, x, y, dt);
    }
    @Override public void onClose() { minecraft.gui.setScreen(parent); }
    @Override public boolean isPauseScreen() { return false; }
}
