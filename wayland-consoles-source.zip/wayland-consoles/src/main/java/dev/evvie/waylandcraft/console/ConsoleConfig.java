package dev.evvie.waylandcraft.console;

import com.google.gson.*;
import java.nio.file.*;
import java.io.*;
import java.util.*;

/** Only the local user edits executable paths; ROMs and servers cannot supply commands. */
public final class ConsoleConfig {
    public String coreDir = "/usr/lib/libretro";
    public int maxSessions = 4;
    public Map<String, List<String>> commands = new LinkedHashMap<>();
    public Map<String, String> workingDirectories = new LinkedHashMap<>();
    public Map<String, String> avatarRoms = new LinkedHashMap<>();
    public List<String> romSearchPaths = new ArrayList<>(List.of(System.getProperty("user.home") + "/Downloads"));
    public String avatarPython = "python3";
    public boolean adventureSandbox = true;
    public boolean adventureTerrainDamage = false;
    public Map<String, String> adventureWarps = new LinkedHashMap<>();
    public Map<String, String> adventureEquipment = new LinkedHashMap<>();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static ConsoleConfig load(Path root) throws IOException {
        Files.createDirectories(root);
        Path file = root.resolve("config.json");
        ConsoleConfig config;
        if (Files.exists(file)) {
            try (var reader = Files.newBufferedReader(file)) {
                config = GSON.fromJson(reader, ConsoleConfig.class);
                if (config == null || config.commands == null || config.workingDirectories == null || config.coreDir == null)
                    throw new IOException("Invalid config.json; restore the example configuration");
            } catch (JsonParseException ex) { throw new IOException("Cannot read config.json: " + ex.getMessage(), ex); }
        } else { config = new ConsoleConfig(); }
        for (var type : ConsoleType.values()) {
            config.commands.putIfAbsent(type.id(), type.defaultCommand());
            Files.createDirectories(root.resolve("roms").resolve(type.id()));
        }
        config.maxSessions = Math.clamp(config.maxSessions, 1, 8);
        if (config.avatarRoms == null) config.avatarRoms = new LinkedHashMap<>();
        if (config.romSearchPaths == null) config.romSearchPaths = List.of(System.getProperty("user.home") + "/Downloads");
        if (config.avatarPython == null || config.avatarPython.isBlank()) config.avatarPython = "python3";
        if (config.adventureWarps == null) config.adventureWarps = new LinkedHashMap<>();
        if (config.adventureEquipment == null) config.adventureEquipment = new LinkedHashMap<>();
        if (!Files.exists(file)) Files.writeString(file, GSON.toJson(config));
        Files.createDirectories(root.resolve("logs"));
        return config;
    }
    public void save(Path root) throws IOException {
        Path next = root.resolve("config.json.new");
        Files.writeString(next, GSON.toJson(this));
        Files.move(next, root.resolve("config.json"), StandardCopyOption.REPLACE_EXISTING);
    }

    public List<String> command(ConsoleType type, Path rom) {
        var template = commands.get(type.id());
        if (template == null || template.isEmpty() || template.size() > 64)
            throw new IllegalArgumentException("No command configured for " + type.label);
        var args = new ArrayList<String>();
        for (String arg : template) {
            if (arg == null || arg.indexOf('\0') >= 0) throw new IllegalArgumentException("Invalid command argument");
            if (arg.contains("{rom}") && rom == null) throw new IllegalArgumentException("Choose a ROM first");
            args.add(arg.replace("{rom}", rom == null ? "" : rom.toAbsolutePath().toString()).replace("{coreDir}", coreDir));
        }
        if (args.getFirst().isBlank()) throw new IllegalArgumentException("Emulator executable is empty");
        return List.copyOf(args);
    }
}
