package dev.evvie.waylandcraft;

import dev.evvie.waylandcraft.console.*;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.creativetab.v1.FabricCreativeModeTab;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.*;
import net.minecraft.resources.*;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.*;
import org.slf4j.*;
import java.util.*;

public class WaylandCraftCommon implements ModInitializer {
    public static final String MOD_ID = "waylandconsoles";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static final Map<ConsoleType, ConsoleBlock> CONSOLES = new EnumMap<>(ConsoleType.class);
    public static ConsoleBlock TV;
    public static Item CONTROLLER;
    public static Identifier id(String path) { return Identifier.fromNamespaceAndPath(MOD_ID, path); }

    @Override public void onInitialize() {
        for (var type : ConsoleType.values()) CONSOLES.put(type, registerBlock(type.id() + "_console", type));
        TV = registerBlock("tv", null);
        CONTROLLER = Registry.register(BuiltInRegistries.ITEM, id("controller"), new Item(new Item.Properties()
                .setId(ResourceKey.create(Registries.ITEM, id("controller"))).stacksTo(1)));
        Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, id("consoles"), FabricCreativeModeTab.builder()
                .title(Component.literal("Wayland Consoles")).icon(() -> new ItemStack(TV))
                .displayItems((params, entries) -> {
                    entries.accept(TV); entries.accept(CONTROLLER);
                    CONSOLES.values().forEach(entries::accept);
                }).build());
    }
    private ConsoleBlock registerBlock(String name, ConsoleType console) {
        var identifier = id(name);
        var block = new ConsoleBlock(BlockBehaviour.Properties.of().setId(ResourceKey.create(Registries.BLOCK, identifier))
                .strength(2.0f).sound(SoundType.METAL).noOcclusion(), console);
        Registry.register(BuiltInRegistries.BLOCK, identifier, block);
        Registry.register(BuiltInRegistries.ITEM, identifier, new BlockItem(block,
                new Item.Properties().setId(ResourceKey.create(Registries.ITEM, identifier)).useBlockDescriptionPrefix()));
        return block;
    }
}
