package dev.evvie.waylandcraft.mixin;

import dev.evvie.waylandcraft.console.Adventures;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntity.class)
public class JumpMixin {
    @Inject(method = "jumpFromGround", at = @At("HEAD"), cancellable = true)
    private void consoles$jump(CallbackInfo ci) {
        if ((Object) this instanceof LocalPlayer player && Adventures.jump(player)) ci.cancel();
    }
}
