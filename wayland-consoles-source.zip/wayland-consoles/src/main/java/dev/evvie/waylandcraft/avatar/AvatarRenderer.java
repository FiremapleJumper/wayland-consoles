package dev.evvie.waylandcraft.avatar;

import com.mojang.math.Axis;
import dev.evvie.waylandcraft.console.Adventures;
import dev.evvie.waylandcraft.adventure.*;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.texture.OverlayTexture;

public final class AvatarRenderer {
    private static String lastClip="",lastMode="";
    private static double start;
    private static long lastAction=-1;
    public static int submittedVertices;
    public static String renderedClip="";
    public static boolean replacesPlayer(){var mc=Minecraft.getInstance();return mc.player!=null&&!mc.player.isSpectator()&&!Adventures.mode().equals("off")&&Avatars.get(Adventures.mode())!=null;}
    public static void render(LevelRenderContext context){
        var mc=Minecraft.getInstance();submittedVertices=0;
        if(!replacesPlayer()||mc.options.getCameraType().isFirstPerson()||mc.player.isInvisible())return;
        var p=mc.player;var avatar=Avatars.get(Adventures.mode());String name=Adventures.animation(p);
        var clip=avatar.model().clips().get(name);
        if(clip==null){name=name.equals("fall")?"jump":"idle";clip=avatar.model().clips().get(name);}
        float dt=mc.getDeltaTracker().getGameTimeDeltaPartialTick(false);double time=p.tickCount+dt;
        if(!name.equals(lastClip)||!Adventures.mode().equals(lastMode)||time<start||lastAction!=Adventures.actionSerial()){
            lastAction=Adventures.actionSerial();lastClip=name;lastMode=Adventures.mode();start=time;
        }
        float position=(float)((time-start)*clip.fps()/20);
        boolean loop=name.startsWith("idle")||name.startsWith("walk")||name.startsWith("run")||java.util.Set.of("crouch","hang","shield","shield_mirror","swim","climb").contains(name);
        int index=loop?(int)position%clip.frames().length:Math.min((int)position,clip.frames().length-1);
        int next=loop?(index+1)%clip.frames().length:Math.min(index+1,clip.frames().length-1);
        float[] a=clip.frames()[index],b=clip.frames()[next];
        float blend=a.length==b.length?position-(float)Math.floor(position):0;if(a.length!=b.length)b=a;
        var poses=context.poseStack();poses.pushPose();var origin=LedgeGrab.renderPosition(dt,p.getPosition(dt)).subtract(context.levelState().cameraRenderState.pos);
        poses.translate(origin.x,origin.y,origin.z);poses.rotateDegrees(Axis.YP,-LedgeGrab.renderYaw(p.getYRot()));
        var tunic=AdventureState.link()?AdventureState.gear("tunic"):null;
        submit(context,avatar,a,b,blend,tunic);submittedVertices=a.length/11;renderedClip=name;
        if(AdventureState.child()){
            var mask=AdventureState.gear("masks");
            if(mask!=null){var extra=avatar.model().clips().get("mask_"+mask.name().toLowerCase(java.util.Locale.ROOT));if(extra!=null){var attachment=HeadAttachment.follow(extra.frames()[0],avatar.model().headTriangle(),avatar.model().clips().get("idle").frames()[0],a,b,blend);submit(context,avatar,attachment,attachment,0,null);}}
        }
        poses.popPose();
    }
    private static void submit(LevelRenderContext context,Avatars.Loaded avatar,float[] a,float[] b,float blend,ZeldaGear tunic){
        context.submitNodeCollector().submitCustomGeometry(context.poseStack(),RenderTypes.entityCutout(avatar.texture()),(pose,vertices)->{
            for(int triangle=0;triangle<a.length;triangle+=33)for(int corner=0;corner<4;corner++){
                int i=triangle+Math.min(corner,2)*11;float x=a[i]+(b[i]-a[i])*blend,y=a[i+1]+(b[i+1]-a[i+1])*blend,z=a[i+2]+(b[i+2]-a[i+2])*blend;
                float r=a[i+6],g=a[i+7],blue=a[i+8];
                if(g>r*1.5&&g>blue*1.5){if(tunic==ZeldaGear.GORON_TUNIC){r=.8f;g=.16f;blue=.1f;}else if(tunic==ZeldaGear.ZORA_TUNIC){r=.12f;g=.25f;blue=.85f;}}
                vertices.addVertex(pose,x,y,z).setColor(r,g,blue,1).setUv(a[i+9],a[i+10]).setOverlay(OverlayTexture.NO_OVERLAY).setLight(0x00f000f0).setNormal(pose,a[i+3],a[i+4],a[i+5]);
            }
        });
    }
}
