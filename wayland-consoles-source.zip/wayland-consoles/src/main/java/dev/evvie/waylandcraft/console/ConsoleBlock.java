package dev.evvie.waylandcraft.console;

import net.minecraft.core.*;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.phys.shapes.*;

public class ConsoleBlock extends HorizontalDirectionalBlock {
    /** null denotes a TV. */
    public final ConsoleType console;
    public ConsoleBlock(Properties properties, ConsoleType console) {
        super(properties); this.console = console;
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH));
    }
    @Override protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) { builder.add(FACING); }
    @Override public BlockState getStateForPlacement(BlockPlaceContext ctx) { return defaultBlockState().setValue(FACING, ctx.getHorizontalDirection().getOpposite()); }
    @Override protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return console == null ? Block.box(0, 0, 0, 16, 16, 16) : Block.box(1, 0, 1, 15, 7, 15);
    }
}
