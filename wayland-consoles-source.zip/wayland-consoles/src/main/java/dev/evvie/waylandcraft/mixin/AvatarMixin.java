package dev.evvie.waylandcraft.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.evvie.waylandcraft.avatar.AvatarRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.state.*;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntityRenderer.class)
public class AvatarMixin {
    @Inject(method = "submit(Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/level/CameraRenderState;)V", at = @At("HEAD"), cancellable = true)
    private void consoles$replaceAvatar(LivingEntityRenderState state, PoseStack poses, SubmitNodeCollector submits, CameraRenderState camera, CallbackInfo ci) {
        var player = Minecraft.getInstance().player;
        if (player != null && state instanceof AvatarRenderState avatar && avatar.id == player.getId() && AvatarRenderer.replacesPlayer()) ci.cancel();
    }
}
