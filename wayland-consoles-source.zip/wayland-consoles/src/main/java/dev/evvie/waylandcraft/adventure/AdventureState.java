package dev.evvie.waylandcraft.adventure;

import dev.evvie.waylandcraft.WaylandCraft;
import dev.evvie.waylandcraft.console.Adventures;
import net.minecraft.client.Minecraft;
import java.util.*;

public final class AdventureState {
    public static volatile float magic=96;
    public static volatile boolean shield,lens;
    public static volatile int barrierTicks;
    public static boolean child() { return Adventures.mode().equals("oot_child"); }
    public static boolean link() { return Adventures.mode().equals("oot") || child(); }
    public static boolean sandbox() { return WaylandCraft.instance.config.adventureSandbox; }
    public static boolean available(ZeldaGear item) {
        var p=Minecraft.getInstance().player;return p!=null&&item.available(p,sandbox(),child());
    }
    public static ZeldaGear gear(String group) {
        String key=(child()?"child.":"adult.")+group;
        var fallback=switch(group) {
            case "sword" -> child()?ZeldaGear.KOKIRI:ZeldaGear.MASTER;
            case "shield" -> child()?ZeldaGear.DEKU_SHIELD:ZeldaGear.HYLIAN;
            case "tunic" -> ZeldaGear.KOKIRI_TUNIC;
            case "boots" -> ZeldaGear.NORMAL_BOOTS;
            case "strength" -> child()?ZeldaGear.BRACELET:ZeldaGear.GOLDEN_GAUNTLETS;
            case "scale" -> ZeldaGear.SILVER_SCALE;
            default -> null;
        };
        var result=ZeldaGear.parse(WaylandCraft.instance.config.adventureEquipment.get(key),fallback);
        return result!=null&&available(result)?result:null;
    }
    public static ZeldaGear slot(int slot) {
        String key=(child()?"child.":"adult.")+"slot"+slot;
        ZeldaGear fallback=switch(slot) {case 0 -> child()?ZeldaGear.SLINGSHOT:ZeldaGear.BOW;case 1 -> child()?ZeldaGear.BOOMERANG:ZeldaGear.HOOKSHOT;default -> ZeldaGear.OCARINA;};
        return ZeldaGear.parse(WaylandCraft.instance.config.adventureEquipment.get(key),fallback);
    }
    public static void equip(ZeldaGear gear) {
        if (!available(gear)) { WaylandCraft.message("Requires "+gear.requirement.getDefaultInstance().getItemName().getString()+" in your inventory.");return; }
        String key=(child()?"child.":"adult.")+gear.group;
        var map=WaylandCraft.instance.config.adventureEquipment;
        if(gear.group.equals("masks")&&gear==gear("masks")) map.remove(key); else map.put(key,gear.name());
        save();
    }
    public static void assign(int slot,ZeldaGear gear) {
        if(gear.equipment()) {equip(gear);return;}
        WaylandCraft.instance.config.adventureEquipment.put((child()?"child.":"adult.")+"slot"+slot,gear.name());save();
    }
    public static void toggleSandbox() {
        var c=WaylandCraft.instance.config;c.adventureSandbox=!c.adventureSandbox;
        if(c.adventureSandbox) magic=96;
        save();
    }
    public static void save() { try {WaylandCraft.instance.config.save(WaylandCraft.instance.root);} catch(Exception ex){WaylandCraft.message("Could not save adventure settings: "+ex.getMessage());} }
    public static boolean spend(int amount) { if(sandbox()) return true;if(magic<amount)return false;magic-=amount;return true; }
    public static void reset() { shield=lens=false;barrierTicks=0; }
}
