package dev.evvie.waylandcraft.adventure;

import dev.evvie.waylandcraft.WaylandCraft;
import dev.evvie.waylandcraft.WaylandCraftCommon;
import dev.evvie.waylandcraft.console.Adventures;
import dev.evvie.waylandcraft.gui.*;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.*;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.client.*;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import java.util.*;

public final class AdventureControls {
    public static KeyMapping equipment,target,guard,context;
    public static final KeyMapping[] slots=new KeyMapping[3];
    private static LivingEntity locked;
    private static Vec3 grapple;
    private static int attackHeld,useCooldown;
    private static boolean wasAttack;
    public static void register(){
        var category=KeyMapping.Category.register(WaylandCraftCommon.id("characters"));
        equipment=key("equipment",InputConstants.KEY_I,category);target=key("target",InputConstants.KEY_R,category);
        guard=key("guard",InputConstants.KEY_V,category);context=key("context",InputConstants.KEY_H,category);
        slots[0]=key("slot1",InputConstants.KEY_Z,category);slots[1]=key("slot2",InputConstants.KEY_X,category);slots[2]=key("slot3",InputConstants.KEY_C,category);
        ServerTickEvents.END_SERVER_TICK.register(AdventureActions::tick);
        ServerLivingEntityEvents.ALLOW_DAMAGE.register(AdventureActions::allowDamage);
        HudElementRegistry.replaceElement(VanillaHudElements.HEALTH_BAR,original->(g,dt)->{if(!AdventureState.link())original.extractRenderState(g,dt);});
        HudElementRegistry.addLast(WaylandCraftCommon.id("zelda_hud"),ZeldaInterface::render);
    }
    private static KeyMapping key(String name,int code,KeyMapping.Category category){return KeyMappingHelper.registerKeyMapping(new KeyMapping("key.waylandconsoles."+name,code,category));}
    public static LivingEntity lockedTarget(){return locked!=null&&locked.isAlive()?locked:null;}
    public static Vec3 grappleTarget(){return grapple;}
    public static void grapple(Vec3 target){grapple=target;}
    public static void reset(){locked=null;grapple=null;attackHeld=useCooldown=0;wasAttack=false;}
    public static void use(int slot){use(AdventureState.slot(slot));}
    public static void use(ZeldaGear gear){
        if(!AdventureState.link()||useCooldown>0)return;
        if(!AdventureState.available(gear)){WaylandCraft.message("Requires "+gear.requirement.getDefaultInstance().getItemName().getString()+" in your inventory, or the unlocked kit.");return;}
        if(gear.equipment()){AdventureState.equip(gear);return;}
        if(gear==ZeldaGear.OCARINA){Minecraft.getInstance().gui.setScreen(new OcarinaScreen());Adventures.play("ocarina",2000);return;}
        String pose=switch(gear){
            case BOW,FIRE_ARROW,ICE_ARROW,LIGHT_ARROW,SLINGSHOT -> "bow";
            case HOOKSHOT,LONGSHOT -> "hookshot";
            case HAMMER,STICK -> "hammer";
            case BOOMERANG -> "boomerang";
            case RED_POTION,GREEN_POTION,BLUE_POTION,FAIRY,MILK,POE -> "drink";
            default -> "attack";
        };
        Adventures.play(pose,gear==ZeldaGear.HAMMER?16:12);AdventureActions.use(gear);useCooldown=8;
    }
    public static void tick(Minecraft mc){
        if(equipment==null||mc.player==null)return;
        while(equipment.consumeClick())if(AdventureState.link()&&mc.gui.screen()==null)mc.gui.setScreen(new ZeldaEquipmentScreen());
        if(mc.gui.screen()!=null||!Adventures.active(mc.player)){AdventureState.shield=false;wasAttack=false;attackHeld=0;return;}
        var p=mc.player;if(useCooldown>0)useCooldown--;
        if(!AdventureState.link())return;
        while(target.consumeClick()){
            if(lockedTarget()!=null){locked=null;break;}
            var eye=p.getEyePosition();var look=p.getViewVector(1);
            locked=mc.level.getEntitiesOfClass(LivingEntity.class,p.getBoundingBox().inflate(16),e->e!=p&&e.isAlive()&&!e.isInvisible()&&p.hasLineOfSight(e))
                    .stream().filter(e->e.getBoundingBox().getCenter().subtract(eye).normalize().dot(look)>.35)
                    .min(Comparator.comparingDouble(e->e.distanceToSqr(p))).orElse(null);
        }
        if(locked!=null){
            if(!locked.isAlive()||locked.distanceToSqr(p)>24*24||!p.hasLineOfSight(locked))locked=null;
            else {var delta=locked.getBoundingBox().getCenter().subtract(p.getEyePosition());p.setYRot((float)Math.toDegrees(Math.atan2(-delta.x,delta.z)));p.setXRot((float)-Math.toDegrees(Math.atan2(delta.y,delta.horizontalDistance())));}
        }
        AdventureState.shield=guard.isDown()&&AdventureState.gear("shield")!=null&&AdventureState.gear("sword")!=ZeldaGear.BIGGORON;
        for(int i=0;i<3;i++)while(slots[i].consumeClick())use(i);
        while(context.consumeClick())AdventureActions.context();
        boolean attack=mc.options.keyAttack.isDown();
        if(attack)attackHeld++;
        else if(wasAttack&&attackHeld>=14&&AdventureState.gear("sword")!=null){Adventures.play("spin",20);AdventureActions.melee("spin");attackHeld=0;}
        else attackHeld=0;
        wasAttack=attack;
        if(grapple!=null){
            var delta=grapple.subtract(p.position());
            if(delta.length()<.75||delta.length()>30||p.horizontalCollision||mc.options.keyShift.isDown())grapple=null;
            else {var velocity=delta.normalize().scale(Math.min(.85,delta.length()*.3));if(mc.level.noCollision(p,p.getBoundingBox().move(velocity))){p.setDeltaMovement(velocity);p.fallDistance=0;Adventures.play("hookshot",3);}else grapple=null;}
        }
    }
}
