package dev.evvie.waylandcraft.gui;

import com.mojang.blaze3d.platform.InputConstants;
import dev.evvie.waylandcraft.adventure.*;
import dev.evvie.waylandcraft.console.Adventures;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.*;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import java.util.*;

public final class OcarinaScreen extends Screen {
    public record Song(String name,String notes,boolean warp,String effect) {}
    public static final List<Song> SONGS=List.of(
        new Song("Zelda's Lullaby","lurlur",false,"Open nearby wooden doors"),
        new Song("Epona's Song","ulrulr",false,"Call a nearby horse"),
        new Song("Saria's Song","drl drl".replace(" ",""),false,"Reveal nearby creatures"),
        new Song("Sun's Song","rdur du".replace(" ",""),false,"Switch day and night"),
        new Song("Song of Time","rad rad".replace(" ",""),false,"Advance Minecraft time"),
        new Song("Song of Storms","adu adu".replace(" ",""),false,"Toggle rain"),
        new Song("Minuet of Forest","aulrlr",true,"Warp to your registered destination"),
        new Song("Bolero of Fire","dadar drd".replace(" ",""),true,"Warp to your registered destination"),
        new Song("Serenade of Water","adrrl",true,"Warp to your registered destination"),
        new Song("Requiem of Spirit","adarda",true,"Warp to your registered destination"),
        new Song("Nocturne of Shadow","lrralrd",true,"Warp to your registered destination"),
        new Song("Prelude of Light","ururlu",true,"Warp to your registered destination")
    );
    private String notes="";
    private Song playing;
    private int index,ticks;
    public OcarinaScreen(){super(Component.literal("Ocarina of Time"));}
    @Override protected void init(){
        int left=width/2-185;
        for(int i=0;i<SONGS.size();i++){
            var song=SONGS.get(i);int col=i/6,row=i%6;
            addRenderableWidget(Button.builder(Component.literal(song.name()),b->{playing=song;index=ticks=0;notes="";})
                    .bounds(left+col*188,32+row*20, song.warp()?151:181,18).tooltip(Tooltip.create(Component.literal(song.effect()+"\n"+display(song.notes())))).build());
            if(song.warp())addRenderableWidget(Button.builder(Component.literal("Set"),b->AdventureActions.setWarp(song.name())).bounds(left+col*188+154,32+row*20,28,18).tooltip(Tooltip.create(Component.literal("Set this song's destination to where you are standing"))).build());
        }
        addRenderableWidget(Button.builder(Component.literal("Back"),b->onClose()).bounds(width/2-90,height-24,180,20).build());
    }
    public static String display(String pattern){return pattern.replace("a","A ").replace("u","↑ ").replace("d","↓ ").replace("l","← ").replace("r","→ ").trim();}
    private void note(char note){
        notes+=note;if(notes.length()>8)notes=notes.substring(notes.length()-8);
        float pitch=switch(note){case 'a'->.67f;case 'd'->.79f;case 'r'->1f;case 'l'->1.12f;default->1.33f;};
        minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.NOTE_BLOCK_FLUTE.value(),pitch));
    }
    @Override public void tick(){
        if(playing==null)return;
        if(ticks++%6==0){if(index<playing.notes().length())note(playing.notes().charAt(index++));else{AdventureActions.song(playing.name());onClose();}}
    }
    @Override public boolean keyPressed(KeyEvent event){
        char note=switch(event.key()){case InputConstants.KEY_A->'a';case InputConstants.KEY_UP->'u';case InputConstants.KEY_DOWN->'d';case InputConstants.KEY_LEFT->'l';case InputConstants.KEY_RIGHT->'r';default->0;};
        if(note!=0){playing=null;note(note);for(var song:SONGS)if(notes.endsWith(song.notes())){AdventureActions.song(song.name());onClose();break;}return true;}
        return super.keyPressed(event);
    }
    @Override public void extractRenderState(GuiGraphicsExtractor g,int x,int y,float dt){
        g.fill(0,0,width,height,0xf0112036);g.centeredText(font,title,width/2,12,0xffe8d9a0);
        super.extractRenderState(g,x,y,dt);
        g.centeredText(font,"Play with A and arrow keys, or select a song.",width/2,height-77,0xffbdcfe7);
        int start=width/2-notes.length()*10;
        for(int i=0;i<notes.length();i++){
            String icon=switch(notes.charAt(i)){case 'a'->"A";case 'u'->"CUp";case 'd'->"CDown";case 'l'->"CLeft";default->"CRight";};
            ZeldaInterface.sprite(g,"gOcarinaBtnIcon"+icon+"Tex",start+i*20,height-61,16,16,notes.charAt(i)=='a'?0xff5599ff:0xffffd941);
        }
    }
    @Override public void onClose(){Adventures.play("idle",1);minecraft.gui.setScreen(null);}
    @Override public boolean isPauseScreen(){return false;}
}
