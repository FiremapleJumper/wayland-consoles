package dev.evvie.waylandcraft.adventure;

import net.minecraft.world.item.*;
import net.minecraft.world.entity.player.Player;
import java.util.*;

/** Ocarina equipment with explicit Minecraft equivalents for the equipment-required mode. */
public enum ZeldaGear {
    KOKIRI("Kokiri Sword","SwordKokiri","sword",1,Items.STONE_SWORD,"A quick three-hit sword combo."),
    MASTER("Master Sword","SwordMaster","sword",2,Items.DIAMOND_SWORD,"Slash, thrust, jump attack and charged spin."),
    BIGGORON("Biggoron Sword","SwordBiggoron","sword",2,Items.NETHERITE_SWORD,"Longer reach and stronger hits; two-handed, so no shield."),
    DEKU_SHIELD("Deku Shield","ShieldDeku","shield",1,Items.SHIELD,"Hold shield to block attacks from the front."),
    HYLIAN("Hylian Shield","ShieldHylian","shield",0,Items.SHIELD,"Hold shield to guard. Young Link crouches underneath it."),
    MIRROR("Mirror Shield","ShieldMirror","shield",2,Items.SHIELD,"Guard and reflect nearby projectiles back toward their source."),
    KOKIRI_TUNIC("Kokiri Tunic","TunicKokiri","tunic",0,Items.LEATHER_CHESTPLATE,"Standard tunic."),
    GORON_TUNIC("Goron Tunic","TunicGoron","tunic",2,Items.NETHERITE_CHESTPLATE,"Protection from fire and lava damage while equipped."),
    ZORA_TUNIC("Zora Tunic","TunicZora","tunic",2,Items.TURTLE_HELMET,"Breathe underwater while equipped."),
    NORMAL_BOOTS("Kokiri Boots","BootsKokiri","boots",0,Items.LEATHER_BOOTS,"Standard walking and ledge jumps."),
    IRON_BOOTS("Iron Boots","BootsIron","boots",2,Items.IRON_BOOTS,"Sink in water and resist knockback; movement is slower."),
    HOVER_BOOTS("Hover Boots","BootsHover","boots",2,Items.GOLDEN_BOOTS,"Briefly hover after walking off an edge."),
    BRACELET("Goron's Bracelet","GoronsBracelet","strength",1,Items.IRON_INGOT,"Lift and throw small stone or soil blocks with the context key."),
    SILVER_GAUNTLETS("Silver Gauntlets","SilverGauntlets","strength",2,Items.IRON_BLOCK,"Lift heavier blocks."),
    GOLDEN_GAUNTLETS("Golden Gauntlets","GoldenGauntlets","strength",2,Items.GOLD_BLOCK,"Lift very heavy blocks, including obsidian."),
    SILVER_SCALE("Silver Scale","ScaleSilver","scale",0,Items.PRISMARINE_SHARD,"Longer underwater diving time."),
    GOLDEN_SCALE("Golden Scale","ScaleGolden","scale",0,Items.HEART_OF_THE_SEA,"Extended diving time."),
    STICK("Deku Stick","DekuStick","items",1,Items.STICK,"A stronger, breakable melee strike. Uses one stick."),
    NUT("Deku Nut","DekuNut","items",0,Items.SNOWBALL,"A flash stuns nearby enemies. Uses a snowball."),
    BOMB("Bomb","Bomb","items",0,Items.GUNPOWDER,"Throw a bomb with a visible fuse. Uses gunpowder."),
    BOMBCHU("Bombchu","Bombchu","items",0,Items.GUNPOWDER,"A bomb crawls along the ground toward your aim."),
    BOW("Fairy Bow","Bow","items",2,Items.BOW,"Fire arrows along your aim or at a locked target."),
    FIRE_ARROW("Fire Arrows","BowFire","items",2,Items.BOW,"Arrows ignite enemies; uses four magic."),
    ICE_ARROW("Ice Arrows","BowIce","items",2,Items.BOW,"Arrows freeze and slow enemies; uses four magic."),
    LIGHT_ARROW("Light Arrows","BowLight","items",2,Items.BOW,"Powerful glowing arrows; uses eight magic."),
    SLINGSHOT("Fairy Slingshot","Slingshot","items",1,Items.SLIME_BALL,"Fire a seed-like pellet. Uses a slimeball."),
    BOOMERANG("Boomerang","Boomerang","items",1,Items.COPPER_INGOT,"A returning projectile stuns enemies and retrieves dropped items."),
    HOOKSHOT("Hookshot","Hookshot","items",2,Items.CROSSBOW,"Grapple to a solid surface within 12 blocks."),
    LONGSHOT("Longshot","Longshot","items",2,Items.CROSSBOW,"Grapple to a solid surface within 24 blocks."),
    LENS("Lens of Truth","LensOfTruth","items",0,Items.SPYGLASS,"Toggle a magic-draining reveal of nearby hidden or ordinary enemies."),
    HAMMER("Megaton Hammer","Hammer","items",2,Items.MACE,"A heavy melee hit with a small shockwave."),
    DINS_FIRE("Din's Fire","DinsFire","items",0,Items.BLAZE_POWDER,"A fire burst strikes nearby enemies. Uses 12 magic."),
    FARORES_WIND("Farore's Wind","FaroresWind","items",0,Items.ENDER_PEARL,"Set a safe return point, then use again to return. Uses 12 magic."),
    NAYRUS_LOVE("Nayru's Love","NayrusLove","items",0,Items.AMETHYST_SHARD,"A protective barrier lasts 30 seconds. Uses 24 magic."),
    OCARINA("Ocarina of Time","OcarinaOfTime","items",0,Items.NOTE_BLOCK,"Play all twelve songs, or register destinations for the six warp songs."),
    BEAN("Magic Bean","MagicBean","items",1,Items.COCOA_BEANS,"Grow a climbable vine platform on soil. Uses cocoa beans."),
    BOTTLE("Empty Bottle","BottleEmpty","bottles",0,Items.GLASS_BOTTLE,"Capture a nearby fish or bug; interact again to release it."),
    RED_POTION("Red Potion","BottlePotionRed","bottles",0,Items.REDSTONE,"Restore health. Requires a bottle and redstone."),
    GREEN_POTION("Green Potion","BottlePotionGreen","bottles",0,Items.LAPIS_LAZULI,"Restore magic. Requires a bottle and lapis."),
    BLUE_POTION("Blue Potion","BottlePotionBlue","bottles",0,Items.DIAMOND,"Restore health and magic. Requires a bottle and diamond."),
    FAIRY("Bottled Fairy","BottleFairy","bottles",0,Items.GLOW_BERRIES,"Heal now, or keep assigned for one automatic rescue from a fatal hit."),
    MILK("Lon Lon Milk","BottleMilkFull","bottles",0,Items.MILK_BUCKET,"Restore health and clear harmful effects."),
    FISH("Bottled Fish","BottleFish","bottles",0,Items.COD_BUCKET,"Release a fish."),
    BUGS("Bottled Bugs","BottleBug","bottles",0,Items.SPIDER_EYE,"Release a small silverfish."),
    BLUE_FIRE("Blue Fire","BottleBlueFire","bottles",0,Items.BLUE_ICE,"Melt nearby ice. Requires a bottle and blue ice."),
    POE("Bottled Poe","BottlePoe","bottles",0,Items.GHAST_TEAR,"Restore a variable amount of health."),
    KEATON("Keaton Mask","MaskKeaton","masks",1,Items.CARROT,"Wear the original Keaton mask."),
    SKULL("Skull Mask","MaskSkull","masks",1,Items.BONE,"Wear the original Skull mask."),
    SPOOKY("Spooky Mask","MaskSpooky","masks",1,Items.CARVED_PUMPKIN,"Wear the original Spooky mask."),
    BUNNY("Bunny Hood","MaskBunnyHood","masks",1,Items.RABBIT_HIDE,"Wear the original hood. OoT's hood does not grant Majora's speed boost."),
    GORON_MASK("Goron Mask","MaskGoron","masks",1,Items.BRICK,"A cosmetic OoT mask, not a Goron transformation."),
    ZORA_MASK("Zora Mask","MaskZora","masks",1,Items.PRISMARINE_CRYSTALS,"A cosmetic OoT mask, not a Zora transformation."),
    GERUDO("Gerudo Mask","MaskGerudo","masks",1,Items.POPPY,"Wear the original Gerudo mask."),
    TRUTH("Mask of Truth","MaskTruth","masks",1,Items.ENDER_EYE,"Show the health and name of the creature under your crosshair.");

    public final String label, icon, group, description;
    public final int age;
    public final Item requirement;
    ZeldaGear(String label,String icon,String group,int age,Item requirement,String description) {
        this.label=label;this.icon="gItemIcon"+icon+"Tex";this.group=group;this.age=age;this.requirement=requirement;this.description=description;
    }
    public boolean allowed(boolean child) { return age==0 || age==(child?1:2); }
    public boolean equipment() { return !Set.of("items","bottles").contains(group); }
    public static ZeldaGear parse(String id, ZeldaGear fallback) { try { return valueOf(id); } catch (Exception ex) { return fallback; } }
    public static int count(Player p, Item item) {
        int count=0;
        for(int i=0;i<p.getInventory().getContainerSize();i++) { var stack=p.getInventory().getItem(i); if(stack.is(item)) count+=stack.getCount(); }
        return count;
    }
    public boolean available(Player player, boolean sandbox, boolean child) {
        return allowed(child) && (sandbox || this==KOKIRI_TUNIC || this==NORMAL_BOOTS || count(player,requirement)>0);
    }
    public Item ammo() { return switch(this) {
        case BOW,FIRE_ARROW,ICE_ARROW,LIGHT_ARROW -> Items.ARROW;
        case BOMB,BOMBCHU -> Items.GUNPOWDER;
        case NUT -> Items.SNOWBALL;
        case SLINGSHOT -> Items.SLIME_BALL;
        case STICK -> Items.STICK;
        case BEAN -> Items.COCOA_BEANS;
        case RED_POTION,GREEN_POTION,BLUE_POTION,FAIRY,MILK,FISH,BUGS,BLUE_FIRE,POE -> requirement;
        default -> null;
    }; }
    public int magicCost() { return switch(this) {
        case FIRE_ARROW,ICE_ARROW -> 4;
        case LIGHT_ARROW -> 8;
        case DINS_FIRE,FARORES_WIND -> 12;
        case NAYRUS_LOVE -> 24;
        default -> 0;
    }; }
}
