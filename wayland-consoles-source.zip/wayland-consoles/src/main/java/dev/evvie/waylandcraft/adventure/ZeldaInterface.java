package dev.evvie.waylandcraft.adventure;

import com.google.gson.*;
import com.mojang.blaze3d.platform.NativeImage;
import dev.evvie.waylandcraft.WaylandCraftCommon;
import net.minecraft.client.*;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.levelgen.Heightmap;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.ZipFile;

/** Uses interface textures imported from the owner's OoT ROM. */
public final class ZeldaInterface {
    private static final Identifier texture=WaylandCraftCommon.id("avatar/oot_interface");
    private static Map<String,int[]> sprites=Map.of();
    private static int mapTick=-100;
    private static final int[] map=new int[16*16];
    public static void load(Path path)throws IOException{
        try(var zip=new ZipFile(path.toFile())){
            var entry=zip.getEntry("manifest.json");var image=zip.getEntry("atlas.png");
            if(entry==null||image==null||entry.getSize()>262144||image.getSize()>16*1024*1024)throw new IOException("Invalid interface cache");
            JsonObject manifest;
            try(var in=zip.getInputStream(entry)){manifest=JsonParser.parseString(new String(in.readNBytes(262144),java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject();}
            Map<String,int[]> next=new HashMap<>();
            for(var e:manifest.getAsJsonObject("sprites").entrySet()){
                var a=e.getValue().getAsJsonArray();int[] bounds=new int[4];for(int i=0;i<4;i++)bounds[i]=a.get(i).getAsInt();
                if(bounds[0]<0||bounds[1]<0||bounds[2]<1||bounds[3]<1||bounds[0]+bounds[2]>1024||bounds[1]+bounds[3]>1024)throw new IOException("Invalid interface sprite");
                next.put(e.getKey(),bounds);
            }
            NativeImage pixels;try(var in=zip.getInputStream(image)){pixels=NativeImage.read(in);}
            if(pixels.getWidth()!=1024||pixels.getHeight()!=1024){pixels.close();throw new IOException("Invalid interface atlas");}
            Minecraft.getInstance().getTextureManager().register(texture,new DynamicTexture(()->"Imported OoT interface",pixels));sprites=Map.copyOf(next);
        }catch(RuntimeException ex){throw new IOException("Could not read OoT interface",ex);}
    }
    public static void sprite(GuiGraphicsExtractor g,String name,int x,int y,int width,int height,int color){
        var b=sprites.get(name);if(b==null){g.fill(x,y,x+width,y+height,0xff33445c);return;}
        g.blit(RenderPipelines.GUI_TEXTURED,texture,x,y,(float)b[0],(float)b[1],width,height,b[2],b[3],1024,1024,color);
    }
    public static void icon(GuiGraphicsExtractor g,ZeldaGear item,int x,int y,int size){if(item!=null)sprite(g,item.icon,x,y,size,size,0xffffffff);}
    public static void render(GuiGraphicsExtractor g,DeltaTracker dt){
        var mc=Minecraft.getInstance();if(!AdventureState.link()||mc.player==null||mc.gui.hud.isHidden()||mc.player.isSpectator())return;
        var p=mc.player;var font=mc.font;int w=g.guiWidth(),h=g.guiHeight();
        int hearts=Math.min(20,(int)Math.ceil(p.getMaxHealth()/2));
        for(int i=0;i<hearts;i++){
            float fraction=Math.max(0,Math.min(1,(p.getHealth()-i*2)/2));
            String name=fraction>=1?"Full":fraction>=.75?"ThreeQuarter":fraction>=.5?"Half":fraction>0?"Quarter":"Empty";
            sprite(g,"gHeart"+name+"Tex",8+i%10*11,8+i/10*11,12,12,0xffef324b);
        }
        int my=hearts>10?33:22;
        g.fill(9,my,108,my+9,0xff161d29);g.fill(10,my+1,106,my+8,0xff89a2a3);
        g.fill(11,my+2,11+(int)(94*AdventureState.magic/96),my+7,0xff16b856);
        g.text(font,"Magic",9,my+11,0xffe1eee9,false);
        int bx=w-133;
        circle(g,bx,9,25,0xff218d58);icon(g,AdventureState.gear("sword"),bx+3,12,19);g.text(font,"Attack",bx-2,36,-1,false);
        circle(g,bx+35,9,25,0xff3168d7);g.text(font,AdventureControls.context.getTranslatedKeyMessage().getString(),bx+44,18,-1,false);g.text(font,"Action",bx+33,36,-1,false);
        for(int i=0;i<3;i++){
            int x=w-98+i*30;int y=53;circle(g,x,y,25,0xffc5a32b);var item=AdventureState.slot(i);icon(g,item,x+3,y+3,19);
            String key=AdventureControls.slots[i].getTranslatedKeyMessage().getString();g.text(font,key,x+10,y+26,0xffffeb85,false);
            var ammo=item.ammo();if(ammo!=null)g.text(font,AdventureState.sandbox()?"∞":Integer.toString(ZeldaGear.count(p,ammo)),x+7,y+16,-1,false);
        }
        sprite(g,"gRupeeCounterIconTex",9,h-30,10,16,0xff2bea74);g.text(font,Integer.toString(ZeldaGear.count(p,Items.EMERALD)),22,h-25,0xffd7f1dd,false);
        g.text(font,AdventureControls.equipment.getTranslatedKeyMessage().getString()+": Gear",9,h-45,0xffd8dfef,false);
        g.text(font,AdventureControls.guard.getTranslatedKeyMessage().getString()+": Shield   "+AdventureControls.target.getTranslatedKeyMessage().getString()+": Target",9,h-56,0xffd8dfef,false);
        if(AdventureState.barrierTicks>0)g.text(font,"Nayru "+(AdventureState.barrierTicks/20)+"s",9,my+23,0xff82b6ff,false);
        if(AdventureState.lens)g.text(font,"Lens of Truth",9,my+35,0xffb9a3f5,false);
        var target=AdventureControls.lockedTarget();
        if(target!=null){String label="▼ "+target.getName().getString()+"  "+(int)Math.ceil(target.getHealth())+" HP";g.centeredText(font,label,w/2,8,0xffffff62);}
        else if(AdventureState.gear("masks")==ZeldaGear.TRUTH&&mc.crosshairPickEntity instanceof net.minecraft.world.entity.LivingEntity e)g.centeredText(font,e.getName().getString()+"  "+(int)e.getHealth()+" HP",w/2,8,0xffffff62);
        minimap(g,mc,w-58,h-67);
    }
    private static void circle(GuiGraphicsExtractor g,int x,int y,int size,int color){
        for(int row=0;row<size;row++){double ry=row-(size-1)/2.;int half=(int)Math.sqrt(Math.max(0,size*size/4.-ry*ry));int cx=x+size/2;g.fill(cx-half,y+row,cx+half+1,y+row+1,color);}
    }
    private static void minimap(GuiGraphicsExtractor g,Minecraft mc,int x,int y){
        if(mc.player.tickCount-mapTick>10||mc.player.tickCount<mapTick){
            mapTick=mc.player.tickCount;
            for(int z=0;z<16;z++)for(int a=0;a<16;a++){
                int wx=mc.player.blockPosition().getX()+a-8,wz=mc.player.blockPosition().getZ()+z-8;
                var pos=new BlockPos(wx,mc.level.getHeight(Heightmap.Types.WORLD_SURFACE,wx,wz)-1,wz);
                map[z*16+a]=0xff000000|mc.level.getBlockState(pos).getMapColor(mc.level,pos).col;
            }
        }
        g.fill(x-2,y-2,x+50,y+50,0xaa063340);
        for(int z=0;z<16;z++)for(int a=0;a<16;a++)g.fill(x+a*3,y+z*3,x+a*3+3,y+z*3+3,map[z*16+a]);
        g.fill(x+23,y+23,x+26,y+26,0xffffff3a);g.text(Minecraft.getInstance().font,"N",x+21,y-11,0xffadf5f0,false);
        var target=AdventureControls.lockedTarget();if(target!=null){int tx=(int)Math.max(0,Math.min(47,24+(target.getX()-mc.player.getX())*3)),tz=(int)Math.max(0,Math.min(47,24+(target.getZ()-mc.player.getZ())*3));g.fill(x+tx-1,y+tz-1,x+tx+2,y+tz+2,0xffff4444);}
    }
}
