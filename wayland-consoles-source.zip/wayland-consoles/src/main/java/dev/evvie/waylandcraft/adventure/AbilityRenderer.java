package dev.evvie.waylandcraft.adventure;

import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.world.phys.Vec3;

/** Block-shaped projectiles are the Minecraft representation of the original equipment. */
public final class AbilityRenderer {
    public static void render(LevelRenderContext context){
        var mc=Minecraft.getInstance();if(!AdventureState.link()||mc.player==null)return;
        for(var shot:AdventureActions.visuals){
            var pos=shot.pos();var direction=shot.direction().normalize();
            if(shot.kind().equals("BOOMERANG")){
                double angle=shot.age()*.6;Vec3 a=new Vec3(Math.sin(angle),0,Math.cos(angle)),b=new Vec3(Math.cos(angle),0,-Math.sin(angle));
                box(context,pos.add(a.scale(.12)),a,.4,.09,.08,0xffffc52f);box(context,pos.add(b.scale(.12)),b,.4,.09,.08,0xffffc52f);
            }else if(shot.kind().equals("BOMB")||shot.kind().equals("BOMBCHU")){
                box(context,pos,direction,.28,.28,.28,shot.kind().equals("BOMB")?0xff172a48:0xff395dba);box(context,pos.add(0,.2,0),new Vec3(0,0,1),.05,.05,.1,0xffff8a23);
            }else if(shot.kind().equals("SLINGSHOT"))box(context,pos,direction,.12,.12,.12,0xff9b6335);
            else{
                int color=switch(shot.kind()){case "FIRE_ARROW"->0xffff6c24;case "ICE_ARROW"->0xff6bcfff;case "LIGHT_ARROW"->0xffffff8a;default->0xffc4b29a;};
                box(context,pos,direction,.6,.035,.035,0xff936d41);box(context,pos.add(direction.scale(.3)),direction,.12,.10,.10,color);
            }
        }
        var point=AdventureControls.grappleTarget();if(point!=null){var start=mc.player.getEyePosition().add(0,-.3,0);var delta=point.subtract(start);box(context,start.add(delta.scale(.5)),delta.normalize(),delta.length(),.025,.025,0xffafbac4);}
    }
    private static void box(LevelRenderContext context,Vec3 center,Vec3 forward,double length,double width,double height,int color){
        if(forward.lengthSqr()<.01)forward=new Vec3(0,0,1);
        Vec3 right=forward.cross(new Vec3(0,1,0));if(right.lengthSqr()<.01)right=new Vec3(1,0,0);right=right.normalize();var up=right.cross(forward).normalize();
        Vec3[] points=new Vec3[8];for(int i=0;i<8;i++)points[i]=forward.scale((i&1)==0?-length/2:length/2).add(right.scale((i&2)==0?-width/2:width/2)).add(up.scale((i&4)==0?-height/2:height/2));
        int[][] faces={{0,1,3,2},{4,6,7,5},{0,4,5,1},{2,3,7,6},{0,2,6,4},{1,5,7,3}};
        var poses=context.poseStack();poses.pushPose();var origin=center.subtract(context.levelState().cameraRenderState.pos);poses.translate(origin.x,origin.y,origin.z);
        context.submitNodeCollector().submitCustomGeometry(poses,RenderTypes.debugFilledBox(),(pose,vertices)->{for(var face:faces)for(int i:face)vertices.addVertex(pose,points[i].toVector3f()).setColor(color);});poses.popPose();
    }
}
