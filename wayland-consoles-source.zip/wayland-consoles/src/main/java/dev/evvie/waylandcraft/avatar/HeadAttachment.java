package dev.evvie.waylandcraft.avatar;

import net.minecraft.world.phys.Vec3;

/** Recover the head's rigid pose from the same original triangle in each baked frame. */
final class HeadAttachment {
    private static Vec3 point(float[] frame,int id){int i=id*11;return new Vec3(frame[i],frame[i+1],frame[i+2]);}
    static float[] follow(float[] mesh,int[] ids,float[] idle,float[] a,float[] b,float blend){
        if(ids==null)return mesh;
        for(int id:ids)if((id+1)*11>idle.length||(id+1)*11>a.length||(id+1)*11>b.length)return mesh;
        Vec3 origin=point(idle,ids[0]),x=point(idle,ids[1]).subtract(origin).normalize(),other=point(idle,ids[2]).subtract(origin);
        Vec3 z=x.cross(other).normalize(),y=z.cross(x).normalize();
        Vec3 target=point(a,ids[0]).lerp(point(b,ids[0]),blend),tx=point(a,ids[1]).lerp(point(b,ids[1]),blend).subtract(target).normalize();
        Vec3 tz=tx.cross(point(a,ids[2]).lerp(point(b,ids[2]),blend).subtract(target)).normalize(),ty=tz.cross(tx).normalize();
        if(x.lengthSqr()<.5||z.lengthSqr()<.5||tx.lengthSqr()<.5||tz.lengthSqr()<.5)return mesh;
        float[] output=mesh.clone();
        for(int i=0;i<mesh.length;i+=11){
            Vec3 local=new Vec3(mesh[i],mesh[i+1],mesh[i+2]).subtract(origin);
            Vec3 transformed=target.add(tx.scale(local.dot(x))).add(ty.scale(local.dot(y))).add(tz.scale(local.dot(z)));
            Vec3 normal=new Vec3(mesh[i+3],mesh[i+4],mesh[i+5]);
            Vec3 rotated=tx.scale(normal.dot(x)).add(ty.scale(normal.dot(y))).add(tz.scale(normal.dot(z)));
            output[i]=(float)transformed.x;output[i+1]=(float)transformed.y;output[i+2]=(float)transformed.z;
            output[i+3]=(float)rotated.x;output[i+4]=(float)rotated.y;output[i+5]=(float)rotated.z;
        }
        return output;
    }
}
