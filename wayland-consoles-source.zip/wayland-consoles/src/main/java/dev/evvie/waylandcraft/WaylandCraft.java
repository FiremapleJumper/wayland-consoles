package dev.evvie.waylandcraft;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.evvie.waylandcraft.bridge.*;
import dev.evvie.waylandcraft.console.*;
import dev.evvie.waylandcraft.gui.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.level.*;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommands.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.*;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.*;
import net.minecraft.network.chat.Component;
import net.minecraft.world.*;
import net.minecraft.world.phys.Vec3;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;

public final class WaylandCraft implements ClientModInitializer {
    public static WaylandCraft instance;
    public WaylandCraftBridge bridge;
    public ConsoleConfig config;
    public RomLibrary library;
    public Path root;
    public String error = "";
    public final Map<BlockPos, EmulatorSession> sessions = new LinkedHashMap<>();
    public final ExecutorService io = Executors.newSingleThreadExecutor(Thread.ofVirtual().name("console-io", 0).factory());
    private boolean attempted;
    private long generation;
    private net.minecraft.client.multiplayer.ClientLevel activeLevel;

    @Override public void onInitializeClient() {
        instance = this;
        dev.evvie.waylandcraft.adventure.AdventureControls.register();
        root = FabricLoader.getInstance().getConfigDir().resolve("waylandconsoles");
        try { config = ConsoleConfig.load(root); library = new RomLibrary(root.resolve("roms")); }
        catch (Exception ex) { error = "Configuration error: " + ex.getMessage(); }
        LevelRenderEvents.COLLECT_SUBMITS.register(this::renderTVs);
        LevelRenderEvents.COLLECT_SUBMITS.register(dev.evvie.waylandcraft.avatar.AvatarRenderer::render);
        LevelRenderEvents.COLLECT_SUBMITS.register(dev.evvie.waylandcraft.adventure.AbilityRenderer::render);
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        ClientPlayConnectionEvents.DISCONNECT.register((handler, mc) -> stopAll());
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, access) -> {
            var command = literal("consoles");
            for (String mode : List.of("off", "sm64", "oot", "oot_child")) command.then(literal("movement").then(literal(mode).executes(ctx -> {
                Adventures.select(mode); return 1;
            })));
            command.then(literal("stop").executes(ctx -> { stopAll(); return 1; }));
            command.then(literal("reload").executes(ctx -> {
                try { config = ConsoleConfig.load(root); error = ""; message("Configuration reloaded."); }
                catch (Exception ex) { message(ex.getMessage()); }
                return 1;
            }));
            dispatcher.register(command);
        });
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            if (!level.isClientSide() || hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
            if (!(level.getBlockState(hit.getBlockPos()).getBlock() instanceof ConsoleBlock block)) return InteractionResult.PASS;
            if (player.isShiftKeyDown()) {
                if (block.console == null && player.getItemInHand(hand).is(WaylandCraftCommon.CONTROLLER)) {
                    stop(hit.getBlockPos()); message("TV stopped."); return InteractionResult.SUCCESS;
                }
                return InteractionResult.PASS;
            }
            Minecraft.getInstance().execute(() -> openBlock(hit.getBlockPos(), block));
            return InteractionResult.SUCCESS;
        });
        UseItemCallback.EVENT.register((player, level, hand) -> {
            if (!level.isClientSide() || !player.getItemInHand(hand).is(WaylandCraftCommon.CONTROLLER)) return InteractionResult.PASS;
            BlockPos tv = nearest(player.blockPosition(), true);
            if (tv == null) message("No TV within 8 blocks."); else openBlock(tv, WaylandCraftCommon.TV);
            return InteractionResult.SUCCESS;
        });
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            synchronized (sessions) { sessions.values().forEach(EmulatorSession::stop); }
            io.shutdownNow();
        }, "console-cleanup"));
    }

    /** Called on the render thread after the game's renderer has initialized. */
    public void frame() {
        if (!attempted) {
            attempted = true;
            if (WaylandCraftNativeLibLoader.fallbackMode) {
                if (error.isEmpty()) error = "Wayland TV requires Linux and a working native library. See the log.";
                return;
            }
            try {
                bridge = WaylandCraftBridge.start();
                bridge.resizeOutput(960, 720); bridge.setOutputBounds(1920, 1080);
                bridge.requestHandlers.maximizeHandler = t -> bridge.resizeToplevel(t, 960, 720);
                bridge.requestHandlers.fullscreenHandler = t -> bridge.resizeToplevel(t, 960, 720);
                bridge.requestHandlers.unfullscreenHandler = t -> bridge.resizeToplevel(t, 960, 720);
                WaylandCraftCommon.LOGGER.info("Nested Wayland display: {}", bridge.getSocket());
            } catch (Exception | LinkageError ex) {
                error = "Wayland could not start: " + ex.getMessage();
                WaylandCraftCommon.LOGGER.error(error, ex); bridge = null;
            }
        }
        if (bridge == null) return;
        bridge.update();
        for (var surface : bridge.getAllSurfaces()) {
            var fb = surface.getFramebuffer(); if (fb != null) fb.uploadIfDirty();
        }
    }

    public void openBlock(BlockPos pos, ConsoleBlock block) {
        var mc = Minecraft.getInstance();
        if (block.console == null) {
            var session = sessions.get(pos);
            if (session != null && session.window != null && session.window.isMapped()) {
                mc.gui.setScreen(new TVControlScreen(this, session)); return;
            }
            BlockPos consolePos = nearest(pos, false);
            if (consolePos == null) { message("Place a console within 8 blocks of the TV."); return; }
            var type = ((ConsoleBlock) mc.level.getBlockState(consolePos).getBlock()).console;
            mc.gui.setScreen(new RomLibraryScreen(this, pos, consolePos, type));
        } else {
            BlockPos tv = nearest(pos, true);
            if (tv == null) { message("Place a TV within 8 blocks of this console."); return; }
            mc.gui.setScreen(new RomLibraryScreen(this, tv, pos, block.console));
        }
    }

    private BlockPos nearest(BlockPos origin, boolean tv) {
        var level = Minecraft.getInstance().level;
        BlockPos best = null; double dist = Double.MAX_VALUE;
        for (var pos : BlockPos.betweenClosed(origin.offset(-8, -8, -8), origin.offset(8, 8, 8))) {
            if (origin.distSqr(pos) > 64) continue;
            if (level.getBlockState(pos).getBlock() instanceof ConsoleBlock b && (b.console == null) == tv) {
                double d = origin.distSqr(pos);
                if (d < dist) { best = pos.immutable(); dist = d; }
            }
        }
        return best;
    }

    public void launch(BlockPos tv, BlockPos consolePos, ConsoleType type, Path rom, Runnable done) {
        if (bridge == null || config == null || library == null) { message(error.isEmpty() ? "Compositor is starting." : error); return; }
        if (!validPair(tv, consolePos, type)) { message("TV or console is missing or too far away."); return; }
        if (!sessions.containsKey(tv) && sessions.size() >= config.maxSessions) { message("Stop another TV before starting a new session."); return; }
        stop(tv);
        var session = new EmulatorSession(tv, consolePos, type);
        synchronized (sessions) { sessions.put(tv.immutable(), session); }
        long ticket = generation;
        String socket = bridge.getSocket(), display = bridge.getX11Display();
        CompletableFuture.supplyAsync(() -> {
            try {
                Path validRom = type == ConsoleType.SM64COOPDX ? null : library.validate(type, rom);
                List<String> command = config.command(type, validRom);
                // Executable/core preflight gives actionable errors before a process is started.
                for (int i = 0; i + 1 < command.size(); i++) if (command.get(i).equals("-L") && !Files.isRegularFile(Path.of(command.get(i + 1))))
                    throw new java.io.IOException("Missing RetroArch core: " + command.get(i + 1));
                var builder = new ProcessBuilder(command);
                var env = builder.environment();
                env.put("WAYLAND_DISPLAY", socket); env.put("SDL_VIDEODRIVER", "wayland");
                env.put("GDK_BACKEND", "wayland"); env.put("QT_QPA_PLATFORM", "wayland");
                if (display == null) env.remove("DISPLAY"); else env.put("DISPLAY", display);
                String cwd = config.workingDirectories.get(type.id());
                if (cwd != null && !cwd.isBlank()) builder.directory(Path.of(cwd).toFile());
                builder.redirectErrorStream(true).redirectOutput(root.resolve("logs").resolve(type.id() + "-" + tv.asLong() + ".log").toFile());
                return builder.start();
            } catch (Exception ex) { throw new CompletionException(ex); }
        }, io).whenComplete((process, ex) -> Minecraft.getInstance().execute(() -> {
            if (ticket != generation || sessions.get(tv) != session) {
                if (process != null) { process.descendants().forEach(ProcessHandle::destroy); process.destroy(); } return;
            }
            if (ex != null) {
                session.status = "Launch failed: " + (ex.getCause() == null ? ex.getMessage() : ex.getCause().getMessage());
                message(session.status); return;
            }
            session.process = process; session.status = "Waiting for emulator window…";
            done.run();
        }));
    }

    public boolean validPair(BlockPos tv, BlockPos console, ConsoleType type) {
        var level = Minecraft.getInstance().level;
        return level != null && tv.distSqr(console) <= 64 && level.getBlockState(tv).is(WaylandCraftCommon.TV)
                && level.getBlockState(console).is(WaylandCraftCommon.CONSOLES.get(type));
    }

    private void tick(Minecraft mc) {
        if (mc.level == null) return;
        if (activeLevel != mc.level) { stopAll(); activeLevel = mc.level; }
        var remove = new ArrayList<BlockPos>();
        for (var session : sessions.values()) {
            if (!validPair(session.tv, session.consolePos, session.console)) { remove.add(session.tv); continue; }
            if (session.process == null) continue;
            if (!session.process.isAlive()) {
                if (session.window == null || !session.window.isAlive()) {
                    session.status = "Emulator exited (" + session.process.exitValue() + "). See config/waylandconsoles/logs.";
                    session.window = null;
                }
                continue;
            }
            var pids = new HashSet<Long>(); pids.add(session.process.pid());
            session.process.descendants().forEach(p -> pids.add(p.pid())); session.pids = pids;
            if (session.window != null && !session.window.isMapped()) session.window = null;
            if (session.window == null && bridge != null) {
                for (var window : bridge.getMappedToplevels()) if (pids.contains(window.clientPid)
                        && sessions.values().stream().noneMatch(s -> s.window == window)) {
                    session.window = window; session.status = "Playing"; break;
                }
                if (session.window == null && System.nanoTime() - session.started > 15_000_000_000L)
                    session.status = "No matching window. Use Attach window or check the emulator log.";
            }
        }
        remove.forEach(this::stop);
        Adventures.tick(mc);
    }

    public void stop(BlockPos pos) {
        EmulatorSession old;
        synchronized (sessions) { old = sessions.remove(pos); }
        if (old != null) old.stop();
    }
    public void stopAll() {
        generation++;
        synchronized (sessions) { sessions.values().forEach(EmulatorSession::stop); sessions.clear(); }
        Adventures.select("off");
    }
    public static void message(String text) {
        var mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.sendSystemMessage(Component.literal(text));
    }

    private void renderTVs(LevelRenderContext context) {
        var mc = Minecraft.getInstance();
        if (mc.level == null) return;
        for (var session : sessions.values()) {
            if (session.window == null || !session.window.isMapped()) continue;
            var fb = session.window.getFramebuffer();
            if (fb == null || !fb.isValid()) continue;
            var state = mc.level.getBlockState(session.tv);
            if (!state.is(WaylandCraftCommon.TV)) continue;
            Vec3 normal = state.getValue(ConsoleBlock.FACING).getUnitVec3();
            Vec3 right = normal.cross(new Vec3(0, -1, 0));
            Vec3 center = Vec3.atCenterOf(session.tv).add(normal.scale(0.505));
            double w = 0.82, h = 0.68;
            double aspect = (double) fb.getWidth() / fb.getHeight();
            if (w / h > aspect) w = h * aspect; else h = w / aspect;
            Vec3 topLeft = center.subtract(right.scale(w / 2)).add(0, h / 2, 0);
            Vec3 spanX = right.scale(w), spanY = new Vec3(0, -h, 0);
            PoseStack poses = context.poseStack(); poses.pushPose();
            Vec3 origin = topLeft.subtract(context.levelState().cameraRenderState.pos);
            poses.translate(origin.x, origin.y, origin.z);
            context.submitNodeCollector().submitCustomGeometry(poses, RenderTypes.entitySolid(fb.getTextureLocation()), (pose, vertices) -> {
                Vec3[] points = {Vec3.ZERO, spanY, spanX.add(spanY), spanX};
                float[][] uv = {{0,0}, {0,1}, {1,1}, {1,0}};
                for (int i = 0; i < 4; i++) vertices.addVertex(pose, points[i].toVector3f()).setColor(0xffffffff)
                        .setUv(uv[i][0], uv[i][1]).setOverlay(OverlayTexture.NO_OVERLAY).setLight(0x00f000f0).setNormal(pose, normal.toVector3f());
            });
            poses.popPose();
        }
    }
}
