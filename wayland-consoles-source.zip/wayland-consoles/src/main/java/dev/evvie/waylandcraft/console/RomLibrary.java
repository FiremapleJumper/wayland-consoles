package dev.evvie.waylandcraft.console;

import java.io.*;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;

/** Local discovery only. Folder names resolve ambiguous disc/ZIP formats. */
public final class RomLibrary {
    private final Path root;
    public record Entry(ConsoleType console, Path path, String title) { }
    public RomLibrary(Path root) { this.root = root.toAbsolutePath().normalize(); }
    public Path folder(ConsoleType console) { return root.resolve(console.id()); }

    public List<Entry> scan(ConsoleType type, String query) throws IOException {
        Path folder = folder(type);
        Files.createDirectories(folder);
        Path realFolder = folder.toRealPath();
        var out = new ArrayList<Entry>();
        String needle = query.toLowerCase(Locale.ROOT);
        int[] visited = {0};
        Files.walkFileTree(folder, EnumSet.noneOf(FileVisitOption.class), 6, new SimpleFileVisitor<>() {
            @Override public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                if (++visited[0] > 20000) return FileVisitResult.TERMINATE;
                if (attrs.isRegularFile() && !attrs.isSymbolicLink() && type.accepts(file.getFileName().toString())
                        && file.toRealPath().startsWith(realFolder) && file.getFileName().toString().toLowerCase(Locale.ROOT).contains(needle)) {
                    out.add(new Entry(type, file.toRealPath(), folder.relativize(file).toString()));
                }
                return FileVisitResult.CONTINUE;
            }
        });
        out.sort(Comparator.comparing(Entry::title, String.CASE_INSENSITIVE_ORDER));
        return List.copyOf(out);
    }

    public Path validate(ConsoleType type, Path file) throws IOException {
        Path real = file.toRealPath();
        if (!real.startsWith(folder(type).toRealPath()) || !Files.isRegularFile(real) || !type.accepts(real.getFileName().toString()))
            throw new IOException("Choose a compatible ROM inside roms/" + type.id());
        return real;
    }

    public Path importFile(ConsoleType type, Path source) throws IOException {
        String filename = source.getFileName().toString().toLowerCase(Locale.ROOT);
        boolean sidecar = (type.extensions.contains("cue") || type.extensions.contains("gdi") || type.extensions.contains("m3u"))
                && (filename.endsWith(".bin") || filename.endsWith(".raw") || filename.endsWith(".wav") || filename.endsWith(".sbi"));
        if (!type.accepts(filename) && !sidecar) throw new IOException("Unsupported file for " + type.label + ": " + source.getFileName());
        if (!Files.isRegularFile(source, LinkOption.NOFOLLOW_LINKS)) throw new IOException("Drop regular files only");
        Path destination = folder(type).resolve(source.getFileName().toString());
        if (Files.exists(destination) && Files.isSameFile(source, destination)) return destination;
        // Never replace a user's existing ROM or follow a destination symlink.
        Files.copy(source, destination);
        return destination;
    }
}
