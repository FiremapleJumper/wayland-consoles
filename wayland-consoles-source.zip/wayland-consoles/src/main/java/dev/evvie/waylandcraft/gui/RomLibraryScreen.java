package dev.evvie.waylandcraft.gui;

import dev.evvie.waylandcraft.WaylandCraft;
import dev.evvie.waylandcraft.console.*;
import net.minecraft.client.gui.*;
import net.minecraft.client.gui.components.*;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Util;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.CompletableFuture;

public final class RomLibraryScreen extends Screen {
    private final WaylandCraft wlc;
    private final BlockPos tv, console;
    private final ConsoleType type;
    private List<RomLibrary.Entry> entries = List.of();
    private final List<Button> rows = new ArrayList<>();
    private EditBox search;
    private String query = "", status = "Searching local ROM folder…";
    private int page, pageSize = 5, revision;
    private boolean busy;

    public RomLibraryScreen(WaylandCraft wlc, BlockPos tv, BlockPos console, ConsoleType type) {
        super(Component.literal(type.label + " · ROM library"));
        this.wlc = wlc; this.tv = tv.immutable(); this.console = console.immutable(); this.type = type;
    }
    @Override protected void init() {
        int left = Math.max(12, width / 2 - 160), wide = Math.min(320, width - 24);
        pageSize = Math.max(1, (height - 186) / 23);
        search = addRenderableWidget(new EditBox(font, left, 37, wide, 20, Component.literal("Search local ROMs")));
        search.setMaxLength(160); search.setValue(query);
        search.setResponder(value -> { query = value; page = 0; refreshRows(); });
        addRenderableWidget(Button.builder(Component.literal("Rescan"), b -> scan()).bounds(left, height - 91, wide / 3 - 3, 20).build());
        addRenderableWidget(Button.builder(Component.literal("ROM folder"), b -> {
            if (wlc.library != null) wlc.io.execute(() -> {
                try { new ProcessBuilder("xdg-open", wlc.library.folder(type).toAbsolutePath().toString()).start(); }
                catch (Exception ex) { minecraft.execute(() -> WaylandCraft.message(wlc.library.folder(type).toAbsolutePath().toString())); }
            });
        }).bounds(left + wide / 3, height - 91, wide / 3 - 3, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Movement demo"), b -> minecraft.gui.setScreen(new MovementScreen(this)))
                .bounds(left + wide * 2 / 3, height - 91, wide / 3, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Stop TV"), b -> { wlc.stop(tv); status = "TV stopped"; })
                .bounds(left, height - 67, wide / 2 - 2, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Attach window"), b -> minecraft.gui.setScreen(new AttachWindowScreen(wlc, this, tv, console, type)))
                .bounds(left + wide / 2 + 2, height - 67, wide / 2 - 2, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose()).bounds(left, height - 24, wide, 20).build());
        refreshRows(); scan();
    }
    private void scan() {
        if (wlc.library == null) { status = wlc.error; return; }
        int ticket = ++revision; status = "Searching local ROM folder…";
        CompletableFuture.supplyAsync(() -> {
            try { return wlc.library.scan(type, ""); } catch (Exception ex) { throw new java.util.concurrent.CompletionException(ex); }
        }, wlc.io).whenComplete((found, ex) -> minecraft.execute(() -> {
            if (ticket != revision || minecraft.gui.screen() != this) return;
            entries = found == null ? List.of() : found;
            status = ex == null ? entries.size() + " local games · drop ROM files here to import" : "Search failed: " + ex.getCause().getMessage();
            refreshRows();
        }));
    }
    private void refreshRows() {
        rows.forEach(this::removeWidget); rows.clear();
        int left = Math.max(12, width / 2 - 160), wide = Math.min(320, width - 24);
        if (type == ConsoleType.SM64COOPDX) {
            rows.add(addRenderableWidget(Button.builder(Component.literal("Launch installed SM64 CoopDX"), b -> launch(null))
                    .bounds(left, 64, wide, 20).build()));
            return;
        }
        var filtered = entries.stream().filter(e -> e.title().toLowerCase(Locale.ROOT).contains(query.toLowerCase(Locale.ROOT))).toList();
        int pages = Math.max(1, (filtered.size() + pageSize - 1) / pageSize);
        page = Math.clamp(page, 0, pages - 1);
        for (int i = page * pageSize; i < Math.min(filtered.size(), (page + 1) * pageSize); i++) {
            var entry = filtered.get(i);
            String label = font.plainSubstrByWidth(entry.title(), wide - 15);
            var button = Button.builder(Component.literal(label), b -> launch(entry.path()))
                    .bounds(left, 64 + (i % pageSize) * 23, wide, 20).build();
            button.active = !busy; rows.add(addRenderableWidget(button));
        }
        if (pages > 1) {
            var previous = Button.builder(Component.literal("<"), b -> { page--; refreshRows(); }).bounds(left, height - 116, 35, 20).build();
            var next = Button.builder(Component.literal(">"), b -> { page++; refreshRows(); }).bounds(left + wide - 35, height - 116, 35, 20).build();
            previous.active = page > 0; next.active = page < pages - 1;
            rows.add(addRenderableWidget(previous)); rows.add(addRenderableWidget(next));
        }
    }
    private void launch(Path rom) {
        if (busy) return;
        busy = true; status = "Starting " + type.label + "…"; refreshRows();
        wlc.launch(tv, console, type, rom, () -> {
            busy = false;
            var session = wlc.sessions.get(tv);
            if (session != null && minecraft.gui.screen() == this) minecraft.gui.setScreen(new TVControlScreen(wlc, session));
        });
        // Launch errors remain visible through the session status and can be retried.
        busy = false;
    }
    @Override public void onFilesDrop(List<Path> files) {
        if (wlc.library == null || type == ConsoleType.SM64COOPDX) { status = "Set the CoopDX executable in config.json."; return; }
        status = "Importing dropped files…";
        CompletableFuture.supplyAsync(() -> {
            int count = 0; String error = "";
            for (Path path : files) try { wlc.library.importFile(type, path); count++; }
            catch (Exception ex) { error = ex.getMessage(); }
            return count + " files imported" + (error.isEmpty() ? "" : "; " + error);
        }, wlc.io).thenAccept(result -> minecraft.execute(() -> {
            if (minecraft.gui.screen() == this) { scan(); status = result; }
        }));
    }
    @Override public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float dt) {
        g.fill(0, 0, width, height, 0xf20d1422);
        g.centeredText(font, title, width / 2, 16, 0xffeef4ff);
        super.extractRenderState(g, mx, my, dt);
        String message = wlc.error.isEmpty() ? status : wlc.error;
        var session = wlc.sessions.get(tv);
        if (session != null && session.status.startsWith("Launch failed")) message = session.status;
        g.textWithWordWrap(font, Component.literal(message), Math.max(12, width / 2 - 160), height - 42, Math.min(320, width - 24), 0xffb3c8e4);
        if (entries.isEmpty() && type != ConsoleType.SM64COOPDX) {
            g.centeredText(font, "Put games in roms/" + type.id() + "/", width / 2, 91, 0xffa8b7cd);
        }
    }
    @Override public boolean isPauseScreen() { return false; }
}
