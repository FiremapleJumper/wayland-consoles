package dev.evvie.waylandcraft.adventure;

import dev.evvie.waylandcraft.console.Adventures;
import net.minecraft.client.Minecraft;
import net.minecraft.core.Direction;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.*;

/** Shared ledge detection and hanging for Mario and both Links. */
public final class LedgeGrab {
    private static Vec3 anchor,destination,normal;
    private static int climbDuration=14;
    private static float facing;
    private static int hangTicks,climbTicks,releaseCooldown;
    public static boolean hanging(){return anchor!=null&&climbTicks==0;}
    public static boolean climbing(){return climbTicks>0;}
    public static String animation(){return anchor==null?null:climbing()?"climbup":"hang";}
    public static Vec3 renderPosition(float partial,Vec3 fallback){
        if(anchor==null)return fallback;
        double progress=climbTicks==0?0:Math.min(1,(climbTicks-1+partial)/climbDuration);
        double horizontal=Math.max(0,(progress-.7)/.3);
        Vec3 grip=anchor.subtract(normal.scale(.34));
        return new Vec3(grip.x+(destination.x-grip.x)*horizontal,destination.y+(AdventureState.child()?.8:0)*(1-progress),grip.z+(destination.z-grip.z)*horizontal);
    }
    public static float renderYaw(float fallback){return anchor==null?fallback:facing;}
    public static void reset(){anchor=destination=normal=null;hangTicks=climbTicks=releaseCooldown=0;}
    public static boolean tick(Minecraft mc){
        var p=mc.player;if(releaseCooldown>0)releaseCooldown--;
        if(anchor!=null){
            if(!Adventures.active(p)||p.isInWater()){reset();return false;}
            if(mc.options.keyShift.isDown()){anchor=destination=null;climbTicks=0;releaseCooldown=12;p.setDeltaMovement(0,-.15,0);return true;}
            hangTicks++;
            if(climbTicks==0&&(mc.options.keyJump.isDown()||hangTicks>6&&p.input.keyPresses.forward())){climbTicks=1;var clip=dev.evvie.waylandcraft.avatar.Avatars.get(Adventures.mode()).model().clips().get("climbup");climbDuration=(int)Math.ceil(clip.frames().length/clip.fps()*20);Adventures.play("climbup",climbDuration+1);}
            Vec3 next=anchor;
            if(climbTicks>0){
                float progress=Math.min(1,climbTicks/(float)climbDuration);
                double vertical=Math.min(1,progress/.7),horizontal=Math.max(0,(progress-.7)/.3);
                next=new Vec3(anchor.x+(destination.x-anchor.x)*horizontal,anchor.y+(destination.y-anchor.y)*vertical,anchor.z+(destination.z-anchor.z)*horizontal);
                climbTicks++;
                if(progress>=1){p.setPos(destination);p.setDeltaMovement(0,0,0);p.fallDistance=0;anchor=destination=null;climbTicks=0;releaseCooldown=10;return true;}
            }
            if(!mc.level.noCollision(p,p.getBoundingBox().move(next.subtract(p.position())))){anchor=destination=null;climbTicks=0;releaseCooldown=10;return true;}
            p.setPos(next);p.setDeltaMovement(0,0,0);p.fallDistance=0;p.setOnGround(false);return true;
        }
        if(releaseCooldown>0||p.onGround()||p.isInWater()||p.getDeltaMovement().y>0||mc.options.keyShift.isDown()||!p.input.keyPresses.forward())return false;
        Vec3 direction=Adventures.heading(p),start=p.position().add(0,1.15,0);
        var hit=mc.level.clip(new ClipContext(start,start.add(direction.scale(.85)),ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,p));
        if(hit.getType()!=HitResult.Type.BLOCK||hit.getDirection().getAxis()==Direction.Axis.Y)return false;
        var shape=mc.level.getBlockState(hit.getBlockPos()).getCollisionShape(mc.level,hit.getBlockPos());if(shape.isEmpty())return false;
        double top=hit.getBlockPos().getY()+shape.max(Direction.Axis.Y);
        double reach=AdventureState.child()?1.65:1.95;
        if(top<p.getY()+.7||top>p.getY()+reach)return false;
        var outward=hit.getDirection().getUnitVec3();var point=hit.getLocation();
        Vec3 stand=point.subtract(outward.scale(.55));stand=new Vec3(stand.x,top+.015,stand.z);
        Vec3 hang=point.add(outward.scale(.34));hang=new Vec3(hang.x,top-(AdventureState.child()?1.3:1.6),hang.z);
        if(!mc.level.noCollision(p,p.getBoundingBox().move(stand.subtract(p.position())))||!mc.level.noCollision(p,p.getBoundingBox().move(hang.subtract(p.position()))))return false;
        normal=outward;facing=(float)Math.toDegrees(Math.atan2(outward.x,-outward.z));p.setYRot(facing);
        anchor=hang;destination=stand;hangTicks=climbTicks=0;p.setPos(anchor);p.setDeltaMovement(0,0,0);p.fallDistance=0;Adventures.play("hang",1);return true;
    }
}
