package dev.evvie.waylandcraft.console;

import dev.evvie.waylandcraft.WaylandCraft;
import dev.evvie.waylandcraft.avatar.Avatars;
import dev.evvie.waylandcraft.adventure.*;
import net.minecraft.client.*;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;

/** Character actions adapted to Minecraft collision and combat. */
public final class Adventures {
    private static String mode="off", action="", airborne="jump";
    private static CameraType previousCamera;
    private static int ticks,lastJump=-100,jumpChain,groundTicks,cooldown,actionUntil,combo,lastAttack=-100,hoverTicks;
    private static boolean previousCrouch,pound,wasGrounded;
    private static long actionSerial;
    private static double hoverY;
    public static String mode(){return mode;}
    public static long actionSerial(){return actionSerial;}
    public static boolean active(LocalPlayer p) {
        var mc=Minecraft.getInstance();
        return !mode.equals("off")&&mc.hasSingleplayerServer()&&mc.player==p&&!p.isSpectator()&&!p.getAbilities().flying&&!p.isPassenger()&&!p.isFallFlying();
    }
    public static boolean enabled(LocalPlayer p){return active(p)&&!p.isInWater();}
    public static void select(String next) {
        var mc=Minecraft.getInstance();
        if(!java.util.Set.of("off","sm64","oot","oot_child").contains(next))return;
        if(!next.equals("off")&&!mc.hasSingleplayerServer()){WaylandCraft.message("Character demos are available in singleplayer worlds.");return;}
        if(next.equals("off")){Avatars.cancel();activate(next);}else Avatars.prepare(next,()->activate(next));
    }
    private static void activate(String next) {
        var mc=Minecraft.getInstance();
        if(!next.equals("off")&&(mc.player==null||!mc.hasSingleplayerServer()))return;
        if(!next.equals("off")&&mode.equals("off"))previousCamera=mc.options.getCameraType();
        mode=next;ticks=0;lastJump=lastAttack=-100;jumpChain=groundTicks=cooldown=combo=hoverTicks=0;
        pound=previousCrouch=wasGrounded=false;action="";airborne="jump";actionUntil=0;actionSerial++;
        AdventureState.reset();AdventureControls.reset();LedgeGrab.reset();AdventureActions.updateSettings();
        if(next.equals("off")){if(previousCamera!=null)mc.options.setCameraType(previousCamera);previousCamera=null;}
        else {mc.options.setCameraType(CameraType.THIRD_PERSON_BACK);WaylandCraft.message(Avatars.get(next).model().name()+" enabled. I: equipment and controls. /consoles movement off restores your player.");}
    }
    public static void play(String clip,int duration){action=clip;actionUntil=ticks+duration;actionSerial++;}
    public static boolean attacking(){return ticks<actionUntil&&(action.startsWith("attack")||action.equals("spin")||action.equals("thrust")||action.equals("jumpattack"));}
    public static boolean attack() {
        var mc=Minecraft.getInstance();var p=mc.player;
        if(p==null||!active(p)||mc.gui.screen()!=null)return false;
        if(ticks-lastAttack>24)combo=0;
        boolean damage=ticks-lastAttack>=5;
        String clip;
        if(mode.equals("sm64"))clip=!p.onGround()?"airkick":switch(combo%3){case 0->"punch";case 1->"punch2";default->"kick";};
        else {if(AdventureState.gear("sword")==null){WaylandCraft.message("Equip a sword or turn on the unlocked kit in I.");return false;}
            clip=!p.onGround()?"jumpattack":AdventureControls.lockedTarget()!=null&&p.input.keyPresses.forward()?"thrust":switch(combo%3){case 0->"attack";case 1->"attack2";default->"attack3";};}
        if(damage){combo++;play(clip,clip.equals("kick")?15:clip.equals("jumpattack")?21:11);AdventureActions.melee(clip);lastAttack=ticks;}
        return true;
    }
    public static boolean jump(LocalPlayer p) {
        if(!enabled(p))return false;
        Vec3 v=p.getDeltaMovement(),dir=heading(p);var mc=Minecraft.getInstance();boolean crouch=mc.options.keyShift.isDown();
        if(mode.equals("sm64")) {
            if(crouch&&v.horizontalDistance()>.06&&p.input.keyPresses.forward()) {p.setDeltaMovement(dir.scale(.8).add(0,.38,0));jumpChain=0;airborne="longjump";}
            else if(crouch){p.setDeltaMovement(dir.scale(-.16).add(0,.72,0));jumpChain=0;airborne="backflip";}
            else {jumpChain=ticks-lastJump<24&&groundTicks<8?jumpChain%3+1:1;p.setDeltaMovement(v.x,switch(jumpChain){case 2->.64;case 3->.84;default->.5;},v.z);airborne="jump";}
        }else {
            var input=p.input.keyPresses;boolean target=AdventureControls.lockedTarget()!=null;
            if((crouch||target)&&input.backward()){p.setDeltaMovement(dir.scale(-.48).add(0,.55,0));airborne="backflip";}
            else if((crouch||target)&&(input.left()||input.right())){p.setDeltaMovement(new Vec3(-dir.z,0,dir.x).scale(input.left()?-.42:.42).add(0,.38,0));airborne="sidehop";}
            else {p.setDeltaMovement(v.x,.42,v.z);airborne="jump";}
        }
        lastJump=ticks;pound=false;action="";actionUntil=0;p.setOnGround(false);actionSerial++;return true;
    }
    public static boolean ledgeJumpEligible(boolean groundedBefore,boolean groundedNow,boolean forward,boolean crouch,double speed,double vertical,int sinceJump,boolean deepGap){
        return groundedBefore&&!groundedNow&&forward&&!crouch&&speed>.025&&vertical<=0&&vertical>-.35&&sinceJump>4&&deepGap;
    }
    public static void tick(Minecraft mc) {
        if(mc.player==null)return;
        AdventureControls.tick(mc);AdventureActions.updateSettings();
        if(!active(mc.player)||mc.gui.screen()!=null)return;
        var p=mc.player;ticks++;
        if(LedgeGrab.tick(mc))return;if(cooldown>0)cooldown--;
        groundTicks=p.onGround()?groundTicks+1:0;boolean crouch=mc.options.keyShift.isDown();
        if(mode.equals("sm64")) {
            if(!p.onGround()&&crouch&&!previousCrouch&&ticks-lastJump>4){pound=true;play("pound",30);}
            if(pound&&!p.onGround())p.setDeltaMovement(0,-1,0);
            if(p.onGround()){if(pound)AdventureActions.melee("pound");pound=false;}
            if(!p.onGround()&&p.horizontalCollision&&mc.options.keyJump.isDown()&&ticks-lastJump>5){p.setDeltaMovement(heading(p).scale(-.48).add(0,.6,0));lastJump=ticks;airborne="wallkick";actionSerial++;}
        } else {
            if(crouch&&!previousCrouch&&p.onGround()&&cooldown==0&&p.input.keyPresses.forward()&&!AdventureState.shield){p.setDeltaMovement(heading(p).scale(.6).add(0,.12,0));cooldown=14;play("roll",14);}
            var v=p.getDeltaMovement();boolean gap=mc.level.noCollision(p,p.getBoundingBox().move(0,-.65,0));
            if(ledgeJumpEligible(wasGrounded,p.onGround(),p.input.keyPresses.forward(),crouch,v.horizontalDistance(),v.y,ticks-lastJump,gap)&&!p.isInWater()&&AdventureState.gear("boots")!=ZeldaGear.HOVER_BOOTS){
                double speed=Math.max(.24,v.horizontalDistance());var dir=new Vec3(v.x,0,v.z).normalize();p.setDeltaMovement(dir.scale(speed).add(0,.42,0));lastJump=ticks;airborne="jump";actionSerial++;
            }
            if(AdventureState.gear("boots")==ZeldaGear.HOVER_BOOTS&&wasGrounded&&!p.onGround()&&v.y<=0&&ticks-lastJump>4){hoverTicks=10;hoverY=p.getY();}
            if(p.onGround())hoverTicks=0;
            if(hoverTicks>0){hoverTicks--;if(mc.level.noCollision(p,p.getBoundingBox().move(0,hoverY-p.getY(),0)))p.setPos(p.getX(),hoverY,p.getZ());p.setDeltaMovement(p.getDeltaMovement().multiply(1,0,1));p.fallDistance=0;}
            if(AdventureState.gear("boots")==ZeldaGear.IRON_BOOTS){v=p.getDeltaMovement();p.setDeltaMovement(v.x*.65,p.isInWater()?Math.min(v.y,-.18):v.y,v.z*.65);}
            if(p.isInWater()&&crouch&&AdventureState.gear("boots")!=ZeldaGear.IRON_BOOTS)p.setDeltaMovement(p.getDeltaMovement().add(0,-.06,0));
            if(!p.onGround()&&p.horizontalCollision&&v.y<=0&&p.input.keyPresses.forward()&&!p.isInWater()){
                var offset=heading(p).scale(.55);
                if(mc.level.noCollision(p,p.getBoundingBox().move(offset).move(0,1.05,0))&&!mc.level.noCollision(p,p.getBoundingBox().move(offset))){p.setDeltaMovement(offset.scale(.15).add(0,.3,0));p.fallDistance=0;play("climbup",10);}
            }
        }
        previousCrouch=crouch;wasGrounded=p.onGround();
    }
    public static Vec3 heading(LocalPlayer p){double angle=Math.toRadians(p.getYRot());return new Vec3(-Math.sin(angle),0,Math.cos(angle));}
    public static String animation(LocalPlayer p) {
        String clip;
        if(LedgeGrab.animation()!=null)clip=LedgeGrab.animation();
        else if(pound)clip="pound";
        else if(ticks<actionUntil)clip=action;
        else if(p.isInWater())clip="swim";
        else if(p.onClimbable()&&p.getDeltaMovement().lengthSqr()>.001)clip="climb";
        else if(AdventureState.link()&&AdventureState.shield)clip=AdventureState.gear("shield")==ZeldaGear.MIRROR?"shield_mirror":"shield";
        else if(!p.onGround())clip=airborne.equals("jump")&&p.getDeltaMovement().y<-.1?"fall":airborne;
        else if(Minecraft.getInstance().options.keyShift.isDown())clip="crouch";
        else {double speed=p.getDeltaMovement().horizontalDistance();clip=speed>.15?"run":speed>.015?"walk":"idle";}
        if(AdventureState.link()&&AdventureState.gear("sword")==ZeldaGear.BIGGORON&&java.util.Set.of("idle","walk","run","attack","attack2","attack3","thrust","spin","jumpattack").contains(clip))clip+="_big";
        return clip;
    }
}
