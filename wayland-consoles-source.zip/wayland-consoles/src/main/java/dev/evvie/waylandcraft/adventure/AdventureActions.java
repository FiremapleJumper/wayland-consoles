package dev.evvie.waylandcraft.adventure;

import dev.evvie.waylandcraft.WaylandCraft;
import dev.evvie.waylandcraft.console.Adventures;
import net.minecraft.client.Minecraft;
import net.minecraft.core.*;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.*;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.item.*;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraft.world.phys.*;
import java.util.*;
import java.util.function.Consumer;

/** All health, item consumption, projectile impacts and world changes run on the integrated server. */
public final class AdventureActions {
    public record Settings(UUID player,boolean link,boolean child,boolean sandbox,boolean terrain,ZeldaGear sword,ZeldaGear shield,ZeldaGear tunic,ZeldaGear boots,ZeldaGear strength,ZeldaGear scale,boolean fairy) {}
    private static volatile Settings settings;
    public record Visual(Vec3 pos,Vec3 direction,String kind,int age) {}
    public static volatile List<Visual> visuals=List.of();
    private static final List<Shot> shots=new ArrayList<>();
    private static final Map<String,String> returnPoints=new HashMap<>();
    private static final Map<UUID,BlockPos> heldBlocks=new HashMap<>();
    private static final Map<UUID,String> caught=new HashMap<>();
    private static int serverTicks;
    public static void updateSettings() {
        var mc=Minecraft.getInstance();var p=mc.player;var wlc=WaylandCraft.instance;
        if(p==null||wlc==null||wlc.config==null||Adventures.mode().equals("off")){settings=null;return;}
        boolean fairy=false;for(int i=0;i<3;i++)if(AdventureState.slot(i)==ZeldaGear.FAIRY)fairy=true;
        settings=new Settings(p.getUUID(),AdventureState.link(),AdventureState.child(),AdventureState.sandbox(),wlc.config.adventureTerrainDamage,
                AdventureState.gear("sword"),AdventureState.gear("shield"),AdventureState.gear("tunic"),AdventureState.gear("boots"),AdventureState.gear("strength"),AdventureState.gear("scale"),fairy);
    }
    private static void request(Consumer<ServerPlayer> operation) {
        var mc=Minecraft.getInstance();var server=mc.getSingleplayerServer();var current=settings;
        if(server==null||current==null)return;
        server.execute(()->{
            var p=server.getPlayerList().getPlayer(current.player());
            if(p!=null&&p.isAlive()&&settings!=null&&settings.player().equals(p.getUUID()))operation.accept(p);
        });
    }
    private static void message(String text){Minecraft.getInstance().execute(()->WaylandCraft.message(text));}
    private static boolean take(ServerPlayer p,Item item,int count,boolean sandbox) {
        if(sandbox||item==null)return true;
        if(ZeldaGear.count(p,item)<count)return false;
        for(int i=0;i<p.getInventory().getContainerSize()&&count>0;i++){
            var stack=p.getInventory().getItem(i);if(stack.is(item)){int n=Math.min(count,stack.getCount());stack.shrink(n);count-=n;}
        }
        p.getInventory().setChanged();return true;
    }
    private static boolean pay(ServerPlayer p,ZeldaGear gear) {
        var s=settings;if(s==null||!gear.available(p,s.sandbox(),s.child())){message("Equipment required: "+gear.requirement.getDefaultInstance().getItemName().getString());return false;}
        if(!s.sandbox()&&AdventureState.magic<gear.magicCost()){message("Not enough magic. A green potion restores it.");return false;}
        if(gear.group.equals("bottles")&&!s.sandbox()&&gear!=ZeldaGear.MILK&&gear!=ZeldaGear.FISH&&ZeldaGear.count(p,Items.GLASS_BOTTLE)==0){message("Requires an empty glass bottle.");return false;}
        if(!take(p,gear.ammo(),1,s.sandbox())){message("Out of ammo for "+gear.label+".");return false;}
        if(!s.sandbox())AdventureState.magic-=gear.magicCost();
        return true;
    }
    private static ServerLevel level(ServerPlayer p){return (ServerLevel)p.level();}
    private static void particles(ServerLevel level,Vec3 pos,boolean fire,int count){level.sendParticles(fire?ParticleTypes.FLAME:ParticleTypes.ENCHANT,pos.x,pos.y,pos.z,count,.3,.3,.3,.03);}
    private static void hit(ServerPlayer p,LivingEntity target,float damage,Vec3 direction){
        target.hurtServer(level(p),p.damageSources().playerAttack(p),damage);
        target.setDeltaMovement(target.getDeltaMovement().add(direction.scale(.25)).add(0,.12,0));
    }
    private static List<LivingEntity> targets(ServerPlayer p,double radius){return level(p).getEntitiesOfClass(LivingEntity.class,p.getBoundingBox().inflate(radius),e->e!=p&&e.isAlive()&&!(e instanceof net.minecraft.world.entity.player.Player)&&p.hasLineOfSight(e));}
    public static void melee(String action) {
        request(p->{
            var s=settings;if(s==null)return;
            float damage=!s.link()?3:s.sword()==ZeldaGear.BIGGORON?9:s.child()?4:6;
            double reach=s.sword()==ZeldaGear.BIGGORON?4:3;
            boolean area=action.equals("spin")||action.equals("pound")||action.equals("hammer");
            if(action.equals("spin")){if(!s.sandbox()&&AdventureState.magic<4)return;if(!s.sandbox())AdventureState.magic-=4;damage*=1.5f;}
            if(action.equals("jumpattack"))damage*=1.5f;
            if(action.equals("hammer")){damage=10;reach=3.5;}
            var eye=p.getEyePosition();var direction=p.getViewVector(1);
            LivingEntity nearest=null;double best=reach+1;
            for(var enemy:targets(p,reach)){
                var delta=enemy.getBoundingBox().getCenter().subtract(eye);
                var intercept=enemy.getBoundingBox().inflate(.35).clip(eye,eye.add(direction.scale(reach)));
                if(area&&enemy.distanceToSqr(p)<=reach*reach)hit(p,enemy,damage,delta.normalize());
                else if(intercept.isPresent()&&delta.length()<best){nearest=enemy;best=delta.length();}
            }
            if(!area&&nearest!=null)hit(p,nearest,damage,direction);
            if(area)particles(level(p),p.position().add(0,.8,0),false,35);
        });
    }
    public static void use(ZeldaGear gear) {
        request(p->{
            if(!pay(p,gear))return;
            var world=level(p);var pos=p.position();var aim=p.getViewVector(1);
            switch(gear){
                case BOW,FIRE_ARROW,ICE_ARROW,LIGHT_ARROW,SLINGSHOT,BOMB,BOMBCHU,BOOMERANG -> {
                    var speed=gear==ZeldaGear.BOOMERANG?.8:gear==ZeldaGear.BOMB?.45:gear==ZeldaGear.BOMBCHU?.25:1.35;
                    Vec3 velocity=aim.scale(speed);if(gear==ZeldaGear.BOMB)velocity=velocity.add(0,.18,0);
                    if(gear==ZeldaGear.BOMBCHU)velocity=new Vec3(aim.x,0,aim.z).normalize().scale(speed);
                    shots.add(new Shot(p.getUUID(),world,gear,p.getEyePosition().add(aim.scale(.4)),velocity));
                }
                case HOOKSHOT,LONGSHOT -> {
                    var result=p.pick(gear==ZeldaGear.LONGSHOT?24:12,1,false);
                    if(result instanceof BlockHitResult b&&result.getType()==HitResult.Type.BLOCK){
                        var goal=b.getLocation().add(b.getDirection().getUnitVec3().scale(.8)).add(0,-.5,0);
                        if(world.noCollision(p,p.getBoundingBox().move(goal.subtract(p.position()))))Minecraft.getInstance().execute(()->AdventureControls.grapple(goal));
                        else message("There is no room to land at that hook point.");
                    }else message("Aim at a solid surface.");
                }
                case NUT -> {for(var enemy:targets(p,5)){enemy.addEffect(new MobEffectInstance(MobEffects.SLOWNESS,80,5));enemy.addEffect(new MobEffectInstance(MobEffects.WEAKNESS,80,2));}world.sendParticles(net.minecraft.core.particles.ColorParticleOption.create(ParticleTypes.FLASH,0xffffffff),pos.x,pos.y+1,pos.z,1,0,0,0,0);}
                case STICK -> {for(var enemy:targets(p,3)){hit(p,enemy,6,enemy.position().subtract(pos).normalize());break;}}
                case HAMMER -> melee("hammer");
                case DINS_FIRE -> {for(var enemy:targets(p,6)){hit(p,enemy,8,enemy.position().subtract(pos).normalize());enemy.setRemainingFireTicks(160);}particles(world,pos.add(0,1,0),true,100);}
                case FARORES_WIND -> {
                    String key=worldKey(p)+".farore";
                    if(!returnPoints.containsKey(key)){returnPoints.put(key,point(p));message("Farore's Wind: return point set. Use again to return.");}
                    else if(warp(p,returnPoints.get(key)))returnPoints.remove(key);
                }
                case NAYRUS_LOVE -> {AdventureState.barrierTicks=600;particles(world,pos.add(0,1,0),false,80);}
                case LENS -> {AdventureState.lens=!AdventureState.lens;message("Lens of Truth "+(AdventureState.lens?"on":"off"));}
                case BEAN -> growBean(p);
                case BOTTLE -> bottle(p);
                case RED_POTION -> p.setHealth(p.getMaxHealth());
                case GREEN_POTION -> AdventureState.magic=96;
                case BLUE_POTION -> {p.setHealth(p.getMaxHealth());AdventureState.magic=96;}
                case FAIRY -> p.setHealth(Math.min(p.getMaxHealth(),p.getHealth()+16));
                case MILK -> {p.setHealth(Math.min(p.getMaxHealth(),p.getHealth()+10));p.removeEffect(MobEffects.POISON);p.removeEffect(MobEffects.WITHER);}
                case FISH -> EntityTypes.COD.spawn(world,p.blockPosition().relative(p.getDirection()),EntitySpawnReason.EVENT);
                case BUGS -> EntityTypes.SILVERFISH.spawn(world,p.blockPosition().relative(p.getDirection()),EntitySpawnReason.EVENT);
                case BLUE_FIRE -> {for(var b:BlockPos.betweenClosed(p.blockPosition().offset(-2,-1,-2),p.blockPosition().offset(2,2,2)))if(world.getBlockState(b).is(Blocks.ICE)||world.getBlockState(b).is(Blocks.PACKED_ICE)||world.getBlockState(b).is(Blocks.BLUE_ICE))world.setBlock(b,Blocks.WATER.defaultBlockState(),3);particles(world,pos.add(0,1,0),false,40);}
                case POE -> p.setHealth(Math.min(p.getMaxHealth(),p.getHealth()+2+world.getRandom().nextInt(9)));
                default -> {}
            }
        });
    }
    private static void growBean(ServerPlayer p){
        var result=p.pick(5,1,false);if(!(result instanceof BlockHitResult b)||result.getType()!=HitResult.Type.BLOCK){message("Aim at soil to plant a bean.");return;}
        var w=level(p);var soil=w.getBlockState(b.getBlockPos());
        if(!soil.is(Blocks.DIRT)&&!soil.is(Blocks.GRASS_BLOCK)&&!soil.is(Blocks.FARMLAND)){message("Beans need soil.");return;}
        var base=b.getBlockPos().above();
        for(int y=0;y<4;y++)if(!w.isEmptyBlock(base.above(y))){message("The bean needs clear space above it.");return;}
        for(int y=0;y<4;y++){
            var at=base.above(y);w.setBlock(at,Blocks.OAK_LOG.defaultBlockState(),3);
            var vine=at.north();if(w.isEmptyBlock(vine))w.setBlock(vine,Blocks.VINE.defaultBlockState().setValue(VineBlock.SOUTH,true),3);
        }
        for(int x=-2;x<=2;x++)for(int z=-2;z<=2;z++){var at=base.offset(x,4,z);if(w.isEmptyBlock(at))w.setBlock(at,Blocks.OAK_LEAVES.defaultBlockState().setValue(LeavesBlock.PERSISTENT,true),3);}
        particles(w,Vec3.atCenterOf(base),false,40);
    }
    private static void bottle(ServerPlayer p){
        for(var mob:targets(p,3))if(mob.getType()==EntityTypes.COD||mob.getType()==EntityTypes.SALMON||mob.getType()==EntityTypes.SILVERFISH){
            boolean bug=mob.getType()==EntityTypes.SILVERFISH;
            var stack=new ItemStack(bug?Items.SPIDER_EYE:Items.COD_BUCKET);
            if(!take(p,Items.GLASS_BOTTLE,1,settings.sandbox()))return;
            if(!p.getInventory().add(stack))level(p).addFreshEntity(new ItemEntity(level(p),p.getX(),p.getY()+.5,p.getZ(),stack));
            mob.discard();message("Captured "+(bug?"bug":"fish")+". Select Bottled "+(bug?"Bugs":"Fish")+" to release it.");return;
        }
        message("Bring the empty bottle close to a fish or silverfish.");
    }
    public static void context(){request(p->{
        var w=level(p);var held=heldBlocks.remove(p.getUUID());
        if(held!=null){
            if(p.distanceToSqr(Vec3.atCenterOf(held))>36){message("Move closer to the lifted block.");return;}
            var state=w.getBlockState(held);
            if(!liftable(state,settings.strength())||w.getBlockEntity(held)!=null)return;
            var thrown=FallingBlockEntity.fall(w,held,state);thrown.setPos(p.position().add(0,1.4,0).add(p.getViewVector(1)));
            thrown.setDeltaMovement(p.getViewVector(1).scale(.85).add(0,.3,0));thrown.setHurtsEntities(3,12);message("Block thrown.");return;
        }
        var result=p.pick(4,1,false);
        if(result instanceof BlockHitResult b&&result.getType()==HitResult.Type.BLOCK&&liftable(w.getBlockState(b.getBlockPos()),settings.strength())&&w.getBlockEntity(b.getBlockPos())==null){heldBlocks.put(p.getUUID(),b.getBlockPos());message("Block readied. Press context again to throw; its source stays intact until then.");}
        else message("Aim at a loose soil or stone block. Equip a strength upgrade to lift heavier blocks.");
    });}
    private static boolean liftable(BlockState b,ZeldaGear strength){
        if(strength==null)return false;
        return b.is(Blocks.DIRT)||b.is(Blocks.GRAVEL)||b.is(Blocks.SAND)||b.is(Blocks.COBBLESTONE)||b.is(Blocks.STONE)||
                (strength!=ZeldaGear.BRACELET&&(b.is(Blocks.IRON_BLOCK)||b.is(Blocks.GOLD_BLOCK)))||strength==ZeldaGear.GOLDEN_GAUNTLETS&&b.is(Blocks.OBSIDIAN);
    }
    private static String worldKey(ServerPlayer p){return Integer.toHexString(p.level().getServer().getWorldPath(LevelResource.ROOT).toAbsolutePath().normalize().toString().hashCode());}
    private static String point(ServerPlayer p){var v=p.position();return p.level().dimension().identifier()+"|"+v.x+"|"+v.y+"|"+v.z+"|"+p.getYRot()+"|"+p.getXRot();}
    public static void setWarp(String song){request(p->{String key=worldKey(p)+"."+song,value=point(p);Minecraft.getInstance().execute(()->{WaylandCraft.instance.config.adventureWarps.put(key,value);AdventureState.save();WaylandCraft.message("Warp destination saved for "+song+".");});});}
    private static boolean warp(ServerPlayer p,String encoded){
        try{
            String[] a=encoded.split("\\|");if(a.length!=6)return false;
            var destination=p.level().getServer().getLevel(ResourceKey.create(Registries.DIMENSION,Identifier.parse(a[0])));
            var target=new Vec3(Double.parseDouble(a[1]),Double.parseDouble(a[2]),Double.parseDouble(a[3]));
            if(destination==null||!Double.isFinite(target.lengthSqr())||Math.abs(target.x)>29_999_000||Math.abs(target.z)>29_999_000||target.y<destination.getMinY()||target.y>destination.getMaxY()||!destination.noCollision(p,p.getBoundingBox().move(target.subtract(p.position())))){message("The return point is obstructed.");return false;}
            p.teleportTo(destination,target.x,target.y,target.z,Set.of(),Float.parseFloat(a[4]),Float.parseFloat(a[5]),false);return true;
        }catch(Exception ex){message("That warp destination is unavailable.");return false;}
    }
    public static void song(String song){request(p->{
        var w=level(p);var server=w.getServer();
        switch(song){
            case "Sun's Song" -> command(server,w.getOverworldClockTime()%24000<12000?"time set night":"time set day");
            case "Song of Storms" -> command(server,w.isRaining()?"weather clear":"weather rain");
            case "Song of Time" -> command(server,"time add 6000");
            case "Epona's Song" -> {for(var e:w.getEntitiesOfClass(net.minecraft.world.entity.animal.equine.AbstractHorse.class,p.getBoundingBox().inflate(24)))if(e.isAlive()){var pos=p.position().add(p.getViewVector(1).multiply(1,0,1).normalize().scale(3));if(w.noCollision(e,e.getBoundingBox().move(pos.subtract(e.position())))){e.teleportTo(pos.x,pos.y,pos.z);break;}}}
            case "Saria's Song" -> {for(var e:targets(p,16))e.addEffect(new MobEffectInstance(MobEffects.GLOWING,160));message("Saria's Song reveals nearby creatures.");}
            case "Zelda's Lullaby" -> {for(var at:BlockPos.betweenClosed(p.blockPosition().offset(-4,-1,-4),p.blockPosition().offset(4,2,4))){var state=w.getBlockState(at);if(state.getBlock() instanceof DoorBlock&&state.hasProperty(DoorBlock.OPEN)&&!state.is(Blocks.IRON_DOOR))w.setBlock(at,state.setValue(DoorBlock.OPEN,true),3);}}
            default -> {var destination=WaylandCraft.instance.config.adventureWarps.get(worldKey(p)+"."+song);if(destination==null)message("Set a destination for this warp song in the ocarina screen first.");else warp(p,destination);}
        }
        particles(w,p.position().add(0,1,0),false,30);
    });}
    private static void command(MinecraftServer server,String text){server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withSuppressedOutput(),text);}

    public static boolean allowDamage(LivingEntity entity,DamageSource source,float amount){
        var s=settings;if(s==null||!s.link()||!entity.getUUID().equals(s.player())||!(entity instanceof ServerPlayer p))return true;
        if(source.is(DamageTypeTags.BYPASSES_INVULNERABILITY))return true;
        if(AdventureState.barrierTicks>0)return false;
        if(s.tunic()==ZeldaGear.GORON_TUNIC&&source.is(DamageTypeTags.IS_FIRE))return false;
        var origin=source.getSourcePosition();
        if(AdventureState.shield&&s.shield()!=null&&s.sword()!=ZeldaGear.BIGGORON&&origin!=null){
            var to=origin.subtract(p.position()).multiply(1,0,1).normalize();
            if(to.dot(p.getViewVector(1).multiply(1,0,1).normalize())>.15){particles(level(p),p.getEyePosition(),false,8);return false;}
        }
        if(amount>=p.getHealth()&&s.fairy()&&(s.sandbox()||ZeldaGear.count(p,Items.GLASS_BOTTLE)>0)&&take(p,Items.GLOW_BERRIES,1,s.sandbox())){
            p.setHealth(Math.min(p.getMaxHealth(),16));particles(level(p),p.position().add(0,1,0),false,40);message("Your bottled fairy revived you.");return false;
        }
        return true;
    }
    public static void tick(MinecraftServer server){
        serverTicks++;var s=settings;
        var p=s==null?null:server.getPlayerList().getPlayer(s.player());
        if(p==null){shots.clear();visuals=List.of();heldBlocks.clear();caught.clear();return;}
        if(s.link()&&p.isAlive()){
            if(AdventureState.barrierTicks>0){AdventureState.barrierTicks--;if(serverTicks%8==0)particles(level(p),p.position().add(0,1,0),false,8);}
            if(s.tunic()==ZeldaGear.ZORA_TUNIC&&p.isInWater())p.setAirSupply(300);
            else if(p.isInWater()&&s.scale()!=null&&serverTicks%(s.scale()==ZeldaGear.GOLDEN_SCALE?5:3)!=0)p.setAirSupply(Math.min(300,p.getAirSupply()+1));
            if(AdventureState.lens){
                if(!s.sandbox())AdventureState.magic=Math.max(0,AdventureState.magic-.08f);
                if(AdventureState.magic<=0)AdventureState.lens=false;
                else if(serverTicks%10==0)for(var e:level(p).getEntitiesOfClass(LivingEntity.class,p.getBoundingBox().inflate(24),e->e!=p&&e.isAlive()))e.addEffect(new MobEffectInstance(MobEffects.GLOWING,15));
            }
            if(AdventureState.shield&&s.shield()==ZeldaGear.MIRROR&&s.sword()!=ZeldaGear.BIGGORON){
                for(var projectile:level(p).getEntitiesOfClass(Projectile.class,p.getBoundingBox().inflate(2))){
                    if(projectile.getOwner()==p)continue;
                    var delta=projectile.position().subtract(p.getEyePosition());
                    if(delta.normalize().dot(p.getViewVector(1))>.1&&projectile.getDeltaMovement().dot(delta)<0){projectile.setOwner(p);projectile.setDeltaMovement(projectile.getDeltaMovement().scale(-1.15));particles(level(p),projectile.position(),false,8);}
                }
            }
        }
        List<Visual> rendered=new ArrayList<>();
        for(var it=shots.iterator();it.hasNext();){var shot=it.next();var owner=server.getPlayerList().getPlayer(shot.owner);if(owner==null||owner.level()!=shot.level||!owner.isAlive()||!advance(shot,owner)){it.remove();continue;}rendered.add(new Visual(shot.pos,shot.velocity,shot.kind.name(),shot.age));}
        visuals=List.copyOf(rendered);
    }
    private static final class Shot {
        final UUID owner;final ServerLevel level;final ZeldaGear kind;Vec3 pos,velocity;int age;boolean returning;final Set<UUID> hit=new HashSet<>();
        Shot(UUID owner,ServerLevel level,ZeldaGear kind,Vec3 pos,Vec3 velocity){this.owner=owner;this.level=level;this.kind=kind;this.pos=pos;this.velocity=velocity;}
    }
    private static boolean advance(Shot s,ServerPlayer p){
        s.age++;boolean bomb=s.kind==ZeldaGear.BOMB||s.kind==ZeldaGear.BOMBCHU,boomerang=s.kind==ZeldaGear.BOOMERANG;
        if(s.age>120)return false;
        if(boomerang&&(s.age>14||s.returning)){s.returning=true;s.velocity=p.getEyePosition().subtract(s.pos).normalize().scale(.85);if(s.pos.distanceTo(p.getEyePosition())<1)return false;}
        Vec3 next=s.pos.add(s.velocity);
        boolean stopped=false;
        var block=s.level.clip(new ClipContext(s.pos,next,ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,p));
        if(block.getType()==HitResult.Type.BLOCK){
            next=block.getLocation().add(block.getDirection().getUnitVec3().scale(.05));
            if(bomb){if(s.kind==ZeldaGear.BOMBCHU){s.velocity=new Vec3(s.velocity.x,.05,s.velocity.z);}else s.velocity=s.velocity.multiply(.6,-.25,.6);}
            else if(boomerang)s.returning=true;
            else stopped=true;
        }
        var box=new AABB(s.pos,next).inflate(.3);
        for(var enemy:s.level.getEntitiesOfClass(LivingEntity.class,box,e->e!=p&&e.isAlive()&&!(e instanceof net.minecraft.world.entity.player.Player))){
            if(bomb||enemy.getBoundingBox().inflate(.25).clip(s.pos,next).isEmpty()||!s.hit.add(enemy.getUUID()))continue;
            hit(p,enemy,s.kind==ZeldaGear.LIGHT_ARROW?10:s.kind==ZeldaGear.SLINGSHOT||boomerang?2:5,s.velocity.normalize());
            if(s.kind==ZeldaGear.FIRE_ARROW)enemy.setRemainingFireTicks(120);
            if(s.kind==ZeldaGear.ICE_ARROW||boomerang){enemy.addEffect(new MobEffectInstance(MobEffects.SLOWNESS,boomerang?60:100,4));if(s.kind==ZeldaGear.ICE_ARROW)enemy.setTicksFrozen(180);}
            if(s.kind==ZeldaGear.LIGHT_ARROW)enemy.addEffect(new MobEffectInstance(MobEffects.GLOWING,200));
            if(boomerang)s.returning=true;else return false;
        }
        if(stopped){particles(s.level,next,s.kind==ZeldaGear.FIRE_ARROW,8);return false;}
        if(boomerang)for(var item:s.level.getEntitiesOfClass(ItemEntity.class,box.inflate(.5)))item.teleportTo(p.getX(),p.getY()+.5,p.getZ());
        s.pos=next;
        if(bomb){
            if(s.age>=50){s.level.explode(p,s.pos.x,s.pos.y,s.pos.z,2.5f,false,settings!=null&&settings.terrain()?Level.ExplosionInteraction.TNT:Level.ExplosionInteraction.NONE);return false;}
            if(s.kind==ZeldaGear.BOMB)s.velocity=s.velocity.add(0,-.035,0);
            else {
                var floor=s.level.clip(new ClipContext(s.pos,s.pos.add(0,-2,0),ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,p));
                if(floor.getType()==HitResult.Type.BLOCK)s.pos=new Vec3(s.pos.x,floor.getLocation().y+.1,s.pos.z);else s.velocity=s.velocity.add(0,-.04,0);
            }
            s.level.sendParticles(ParticleTypes.SMOKE,s.pos.x,s.pos.y+.2,s.pos.z,1,0,0,0,0);
        }else if(!boomerang)s.velocity=s.velocity.add(0,-.015,0);
        return true;
    }
}
