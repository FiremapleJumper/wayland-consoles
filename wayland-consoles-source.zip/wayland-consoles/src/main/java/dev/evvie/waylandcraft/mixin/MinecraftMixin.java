package dev.evvie.waylandcraft.mixin;

import dev.evvie.waylandcraft.WaylandCraft;
import dev.evvie.waylandcraft.console.Adventures;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public class MinecraftMixin {
    @Inject(method="startAttack",at=@At("HEAD"),cancellable=true)
    private void consoles$attack(CallbackInfoReturnable<Boolean> ci) {
        var mc=Minecraft.getInstance();
        if(Adventures.attack() && (mc.hitResult==null || mc.hitResult.getType()!=net.minecraft.world.phys.HitResult.Type.BLOCK)) ci.setReturnValue(true);
    }

    @Inject(method = "renderFrame", at = @At("HEAD"))
    private void consoles$frame(boolean advanceGameTime, CallbackInfo ci) {
        if (WaylandCraft.instance != null) WaylandCraft.instance.frame();
    }
}
