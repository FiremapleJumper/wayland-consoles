#!/usr/bin/env python3
"""Import private avatar caches from local N64 ROMs. No game assets are downloaded."""
import argparse, array, ctypes as C, gzip, hashlib, io, json, math, os
from pathlib import Path
import struct, sys, zipfile, zlib

VERSION = 3
HERE = Path(__file__).resolve().parent

def png(width, height, rgba):
    def chunk(kind, data):
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)
    rows = b''.join(b'\0' + rgba[y*width*4:(y+1)*width*4] for y in range(height))
    return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', width, height, 8, 6, 0, 0, 0)) + chunk(b'IDAT', zlib.compress(rows)) + chunk(b'IEND', b'')

def read_rom(path):
    if not 8*1024*1024 <= Path(path).stat().st_size <= 128*1024*1024:
        raise ValueError('ROM size is outside the supported range')
    data = Path(path).read_bytes()
    if data[:4] == b'\x37\x80\x40\x12':
        b = bytearray(data); b[0::2], b[1::2] = data[1::2], data[0::2]; data = bytes(b)
    elif data[:4] == b'\x40\x12\x37\x80':
        b = bytearray(len(data))
        for i in range(4): b[i::4] = data[3-i::4]
        data = bytes(b)
    if data[:4] != b'\x80\x37\x12\x40': raise ValueError('Not an N64 ROM')
    return data

def save_avatar(path, name, clips, atlas, source, height=1.8, head_triangle=None):
    idle = clips['idle'][0]
    ys = idle[1::11]; minimum, maximum = min(ys), max(ys)
    if not 1 < maximum-minimum < 20000: raise ValueError('Invalid imported model dimensions')
    scale = height / (maximum-minimum)
    manifest = {'version':VERSION, 'name':name, 'sourceSha256':hashlib.sha256(source).hexdigest(), 'clips':[]}
    if head_triangle is not None:manifest['headTriangle']=head_triangle
    binary = io.BytesIO()
    for clip, frames in clips.items():
        manifest['clips'].append({'name':clip,'frames':len(frames),'fps':30*45/89 if clip.startswith('idle') and name.endswith('Link') else 30})
        for frame in frames:
            if len(frame) % 33: raise ValueError('Incomplete triangle data')
            data = array.array('f', frame)
            for i in range(0,len(data),11):
                data[i] *= scale; data[i+1] = (data[i+1]-minimum)*scale; data[i+2] *= scale
            if sys.byteorder != 'little': data.byteswap()
            binary.write(struct.pack('<I',len(data)//11)); binary.write(data.tobytes())
    path.parent.mkdir(parents=True,exist_ok=True)
    temp = path.with_suffix('.tmp')
    with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        z.writestr('manifest.json',json.dumps(manifest)); z.writestr('atlas.png',atlas); z.writestr('frames.bin',binary.getvalue())
    temp.replace(path)
    print(json.dumps({'avatar':name,'path':str(path),'clips':{k:len(v) for k,v in clips.items()},'height':height}),flush=True)

class Surface(C.Structure):
    _fields_ = [('type',C.c_int16),('force',C.c_int16),('terrain',C.c_uint16),('vertices',(C.c_int32*3)*3)]
class Inputs(C.Structure):
    _fields_ = [('camX',C.c_float),('camZ',C.c_float),('stickX',C.c_float),('stickY',C.c_float),('a',C.c_uint8),('b',C.c_uint8),('z',C.c_uint8)]
class Geometry(C.Structure):
    _fields_ = [('position',C.POINTER(C.c_float)),('normal',C.POINTER(C.c_float)),('color',C.POINTER(C.c_float)),('uv',C.POINTER(C.c_float)),('triangles',C.c_uint16)]

def import_mario(rom, output):
    if b'SUPER MARIO 64' not in rom[0x20:0x34] or rom[0x3e] != ord('E'):
        raise ValueError('Mario import needs the original Super Mario 64 USA ROM')
    lib = C.CDLL(str(HERE/'libsm64-avatar.so'))
    texture = (C.c_uint8 * (704*64*4))(); raw = (C.c_uint8 * len(rom)).from_buffer_copy(rom)
    lib.sm64_global_init.argtypes=[C.POINTER(C.c_uint8),C.POINTER(C.c_uint8)];lib.sm64_global_init(raw,texture)
    floor = (Surface*2)()
    for i, points in enumerate([[(-20000,0,-20000),(-20000,0,20000),(20000,0,20000)], [(-20000,0,-20000),(20000,0,20000),(20000,0,-20000)]]):
        for j, point in enumerate(points): floor[i].vertices[j][:]=point
    lib.sm64_static_surfaces_load.argtypes=[C.POINTER(Surface),C.c_uint32];lib.sm64_static_surfaces_load(floor,2)
    lib.sm64_mario_create.argtypes=[C.c_float]*3;lib.sm64_mario_create.restype=C.c_int32
    mario=lib.sm64_mario_create(0,0,0)
    if mario < 0: raise ValueError('Mario model could not initialize')
    buffers=[(C.c_float*(1024*3*n))() for n in [3,3,3,2]];geo=Geometry(*buffers,0)
    lib.sm64_mario_tick.argtypes=[C.c_int32,C.POINTER(Inputs),C.c_void_p,C.POINTER(Geometry)]
    state=C.create_string_buffer(256); controls=Inputs(0,1,0,0,0,0,0)
    for _ in range(90):lib.sm64_mario_tick(mario,C.byref(controls),state,C.byref(geo))
    lib.sm64_avatar_sample.argtypes=[C.c_int32,C.c_int32,C.c_int32,C.POINTER(Geometry)];lib.sm64_avatar_sample.restype=C.c_int
    ids={'idle':0xc5,'walk':0x48,'run':0x72,'jump':0x4d,'longjump':0x13,'pound':0x3d,'crouch':0x98,'fall':0x56,'backflip':0x04,'punch':0x67,'punch2':0x68,'kick':0x66,'airkick':0x4f,'dive':0x88,'swim':0xaa,'wallkick':0xcb,'hang':0x33,'climbup':0x34}
    clips={}
    for name,anim in ids.items():
        count=lib.sm64_avatar_sample(mario,anim,0,C.byref(geo));count=min(max(count,1),100)
        frames=[]
        for f in range(count):
            lib.sm64_avatar_sample(mario,anim,f,C.byref(geo))
            if not 0 < geo.triangles <= 1024: raise ValueError('Mario produced invalid triangles')
            verts=[]
            for i in range(geo.triangles*3):
                verts.extend(geo.position[i*3:i*3+3]);verts.extend(geo.normal[i*3:i*3+3]);verts.extend(geo.color[i*3:i*3+3])
                verts.extend(geo.uv[i*2:i*2+2])
            frames.append(verts)
        clips[name]=frames
    # libsm64 blends texture alpha over the material colour. Bake that blend into
    # material variants so Minecraft's ordinary textured pipeline reproduces it.
    colours={}
    for frames in clips.values():
        for frame in frames:
            for i in range(0,len(frame),11):
                if frame[i+9]!=1 or frame[i+10]!=1:
                    key=tuple(round(v*255) for v in frame[i+6:i+9]);colours.setdefault(key,len(colours))
    original=bytes(texture);atlas=bytearray()
    for colour in colours:
        for y in range(64):
            for x in range(704):
                off=(y*704+x)*4;alpha=original[off+3]
                atlas.extend((original[off+c]*alpha+colour[c]*(255-alpha))//255 for c in range(3));atlas.append(255)
            atlas.extend(b'\xff'*(16*4))
    for frames in clips.values():
        for frame in frames:
            for i in range(0,len(frame),11):
                u,v=frame[i+9:i+11]
                if u==1 and v==1:frame[i+9:i+11]=[712/720,.5/len(colours)]
                else:
                    index=colours[tuple(round(v*255) for v in frame[i+6:i+9])]
                    frame[i+6:i+9]=[1.,1.,1.];frame[i+9:i+11]=[u*704/720,(index+v)/len(colours)]
    save_avatar(output/'sm64.avz','Mario',clips,png(720,64*len(colours),bytes(atlas)),rom)
    lib.sm64_mario_delete(mario);lib.sm64_global_terminate()

def yaz0(data, expected):
    if data[:4] != b'Yaz0': return data[:expected]
    size=struct.unpack_from('>I',data,4)[0]
    if size != expected or size > 64*1024*1024: raise ValueError('Invalid Yaz0 size')
    out=bytearray();pos=16;bits=0;code=0
    while len(out)<size:
        if bits==0:code=data[pos];pos+=1;bits=8
        if code&128:out.append(data[pos]);pos+=1
        else:
            a,b=data[pos:pos+2];pos+=2;distance=((a&15)<<8|b)+1;length=a>>4
            if length==0:length=data[pos]+18;pos+=1
            else:length+=2
            if distance>len(out):raise ValueError('Invalid Yaz0 back reference')
            for _ in range(min(length,size-len(out))):out.append(out[-distance])
        code=(code<<1)&255;bits-=1
    return bytes(out)

def rom_file(rom,index,table):
    start,end,physical,physical_end=struct.unpack_from('>IIII',rom,table+index*16)
    if not start<end or physical==0xffffffff or physical>=len(rom):raise ValueError('Unsupported Ocarina of Time file table')
    return yaz0(rom[physical:physical_end if physical_end else physical+end-start],end-start)

def identity():return (1.,0.,0.,0.,0.,1.,0.,0.,0.,0.,1.,0.,0.,0.,0.,1.)
def multiply(a,b):return tuple(sum(a[r*4+k]*b[k*4+c] for k in range(4)) for r in range(4) for c in range(4))
def transform(m,p,normal=False):
    x,y,z=p;w=0 if normal else 1
    return tuple(m[r*4]*x+m[r*4+1]*y+m[r*4+2]*z+m[r*4+3]*w for r in range(3))
def bone_matrix(pos,rot):
    x,y,z=[v*math.pi/32768 for v in rot];sx,cx=math.sin(x),math.cos(x);sy,cy=math.sin(y),math.cos(y);sz,cz=math.sin(z),math.cos(z)
    return (cz*cy,cz*sy*sx-sz*cx,cz*sy*cx+sz*sx,pos[0],sz*cy,sz*sy*sx+cz*cx,sz*sy*cx-cz*sx,pos[1],-sy,cy*sx,cy*cx,pos[2],0,0,0,1)

def rgba16(value):return ((value>>11&31)*255//31,(value>>6&31)*255//31,(value>>1&31)*255//31,255 if value&1 else 0)

class LinkModel:
    def __init__(self,data,definition,shared,shared_definition):
        self.data=data;self.definition=definition;self.texture_info={int(t['Offset'],0):t for t in definition['textures']}
        self.common_base=len(data);self.data+=shared
        for t in shared_definition['sharedTextures']:
            t=t.copy()
            if 'TlutOffset' in t:t['TlutOffset']=str(int(t['TlutOffset'],0)+self.common_base)
            self.texture_info[self.common_base+int(t['Offset'],0)]=t
        self.atlas=bytearray(b'\xff'*(1024*1024*4));self.slots={};self.cursor_x=2;self.cursor_y=2;self.row=0
        self.white=(0,0,1,1);self.slots[None]=self.white
        skeleton=definition['skeleton'];table=struct.unpack_from('>I',data,skeleton)[0]&0xffffff
        count=data[skeleton+4]
        if count!=21:raise ValueError('Unsupported Link skeleton')
        self.head_triangle=None
        self.limbs=[]
        for i in range(count):
            offset=struct.unpack_from('>I',data,table+4*i)[0]&0xffffff
            x,y,z,child,sibling,dl=struct.unpack_from('>hhhBBI',data,offset)
            self.limbs.append(((x,y,z),child,sibling,dl))
        self.eyes=next((int(t['Offset'],0) for t in definition['textures'] if 'EyesOpen' in t['Name']),0)
        self.mouth=next((int(t['Offset'],0) for t in definition['textures'] if 'MouthClosed' in t['Name']),0)

    def texture(self,offset):
        if offset in self.slots:return self.slots[offset]
        info=self.texture_info.get(offset)
        if info is None:return self.white
        width,height=int(info['Width']),int(info['Height']);fmt=info['Format'];palette=int(info.get('TlutOffset','0'),0)
        if width>512 or height>512:raise ValueError('Invalid Link texture')
        if self.cursor_x+width+2>1024:self.cursor_x=2;self.cursor_y+=self.row+2;self.row=0
        if self.cursor_y+height+2>1024:raise ValueError('Link texture atlas exceeded limit')
        x0,y0=self.cursor_x,self.cursor_y;self.cursor_x+=width+2;self.row=max(self.row,height)
        for i in range(width*height):
            if fmt=='rgba16':pixel=rgba16(struct.unpack_from('>H',self.data,offset+i*2)[0])
            elif fmt=='rgba32':pixel=tuple(self.data[offset+i*4:offset+i*4+4])
            elif fmt=='ci8':pixel=rgba16(struct.unpack_from('>H',self.data,palette+self.data[offset+i]*2)[0])
            elif fmt=='ci4':
                v=self.data[offset+i//2];index=(v>>4 if i%2==0 else v&15);pixel=rgba16(struct.unpack_from('>H',self.data,palette+index*2)[0])
            elif fmt=='ia16':v=self.data[offset+i*2];pixel=(v,v,v,self.data[offset+i*2+1])
            elif fmt=='ia8':v=self.data[offset+i];pixel=((v>>4)*17,)*3+((v&15)*17,)
            elif fmt=='i8':v=self.data[offset+i];pixel=(v,v,v,255)
            elif fmt in ('i4','ia4'):
                v=self.data[offset+i//2];v=(v>>4 if i%2==0 else v&15)
                pixel=(v*17,)*3+(255,) if fmt=='i4' else ((v>>1)*255//7,)*3+(255 if v&1 else 0,)
            else:pixel=(255,255,255,255)
            x,y=x0+i%width,y0+i//width;self.atlas[(y*1024+x)*4:(y*1024+x)*4+4]=bytes(pixel)
        self.slots[offset]=(x0,y0,width,height);return self.slots[offset]

    def bake(self,joints,equipment="sword"):
        gear=self.definition.get("equipment",{})
        matrices={};draw=[];matrix_table=[]
        def visit(i,parent):
            if i==255:return
            if i in matrices:raise ValueError('Cyclic Link skeleton')
            pos,child,sibling,dl=self.limbs[i]
            if i==15:dl=gear.get(equipment if equipment in ('hammer','boomerang','biggoron') else 'sword',dl) if equipment not in ('bow','ocarina','hookshot','climb','swim','drink','hang','climbup') else dl
            if i==18:dl=gear.get(equipment,dl) if equipment in ('bow','ocarina','hookshot') else gear.get('mirror' if equipment=='mirror' else 'shield',dl) if equipment not in ('climb','swim','drink','hang','climbup') else dl
            if i==19 and equipment not in ('bow','ocarina','hookshot','climb','swim','drink','hang','climbup'):dl=gear.get('back',dl)
            if i==0:pos=(0,joints[0][1],0)
            matrix=multiply(parent,bone_matrix(pos,joints[i+1]));matrices[i]=matrix
            if dl:matrix_table.append(matrix);draw.append((dl,matrix,i))
            visit(child,matrix);visit(sibling,parent)
        visit(0,identity())
        vertices=[];cache=[None]*64;texture=[None];primitive=[(1.,1.,1.)];environment=[(.18,.55,.12)];active=[identity()];clamp=[True,True];tile_origin=[0,0]
        def address(value):
            segment=value>>24;offset=value&0xffffff
            if segment==6:return offset
            if segment==4:return self.common_base+offset
            if segment==8:return self.eyes+offset
            if segment==9:return self.mouth+offset
            return None
        def triangle(a,b,c):
            for index in (a,b,c):
                if index>=len(cache) or cache[index] is None:return
            slot=self.texture(texture[0]);x0,y0,w,h=slot;info=self.texture_info.get(texture[0],{})
            tint=environment[0] if info.get('Format','').startswith(('i','ia')) else primitive[0]
            for index in (a,b,c):
                p,n,uv=cache[index]
                u,v=(uv[0]/32-tile_origin[0])/w,(uv[1]/32-tile_origin[1])/h
                u=max(0,min(1,u)) if clamp[0] else (u%1 if u<0 or u>1 else u)
                v=max(0,min(1,v)) if clamp[1] else (v%1 if v<0 or v>1 else v)
                vertices.extend((*p,*n,*tint,(x0+u*(w-1)+.5)/1024,(y0+v*(h-1)+.5)/1024))
        def display(pointer,depth=0):
            if depth>24:return
            offset=address(pointer)
            if offset is None:return
            for _ in range(8000):
                if offset+8>len(self.data):return
                w0,w1=struct.unpack_from('>II',self.data,offset);offset+=8;op=w0>>24
                if op==0xdf:return
                if op==0xde:
                    display(w1,depth+1)
                    if w0>>16&255:return
                elif op==0xda:
                    if w1>>24==13:
                        index=(w1&0xffffff)//64
                        if index<len(matrix_table):active[0]=matrix_table[index]
                elif op==0x01:
                    count=w0>>12&255;start=(w0>>1&127)-count;pos=address(w1)
                    if pos is None:continue
                    for i in range(count):
                        if not 0<=start+i<64 or pos+i*16+16>len(self.data):continue
                        x,y,z,_,s,t,nx,ny,nz,alpha=struct.unpack_from('>hhhHhhbbbB',self.data,pos+i*16)
                        norm=transform(active[0],(nx/127,ny/127,nz/127),True)
                        cache[start+i]=(transform(active[0],(x,y,z)),norm,(s,t))
                elif op==0x05:triangle((w0>>16&255)//2,(w0>>8&255)//2,(w0&255)//2)
                elif op==0x06:
                    triangle((w0>>16&255)//2,(w0>>8&255)//2,(w0&255)//2);triangle((w1>>16&255)//2,(w1>>8&255)//2,(w1&255)//2)
                elif op==0xfd:
                    target=address(w1)
                    if 'TLUT' not in self.texture_info.get(target,{}).get('Name','').upper():texture[0]=target
                elif op==0xf5 and (w1>>24&7)==0:clamp[:]=[bool(w1>>8&2),bool(w1>>18&2)]
                elif op==0xf2 and (w1>>24&7)==0:tile_origin[:]=[(w0>>12&4095)/4,(w0&4095)/4]
                elif op==0xfa:primitive[0]=((w1>>24&255)/255,(w1>>16&255)/255,(w1>>8&255)/255)
                elif op==0xfb:environment[0]=((w1>>24&255)/255,(w1>>16&255)/255,(w1>>8&255)/255)
        if equipment.startswith('mask_'):draw=[(gear[equipment],matrices[10],10)]
        for pointer,matrix,limb in draw:
            active[0]=matrix;start=len(vertices)//11;display(pointer)
            if limb==10 and self.head_triangle is None:
                for i in range(start,len(vertices)//11,3):
                    a,b,c=[vertices[j*11:j*11+3] for j in range(i,i+3)]
                    ab=[b[k]-a[k] for k in range(3)];ac=[c[k]-a[k] for k in range(3)]
                    cross=[ab[1]*ac[2]-ab[2]*ac[1],ab[2]*ac[0]-ab[0]*ac[2],ab[0]*ac[1]-ab[1]*ac[0]]
                    if sum(v*v for v in cross)>1:
                        self.head_triangle=[i,i+1,i+2];break
        return vertices

def animation_offset(anim,frame):
    for part in anim.get('parts',[anim]):
        if frame<part['frames']:return part['offset']+frame*134
        frame-=part['frames']
    raise ValueError('Invalid animation frame')

def import_link(rom,output):
    if b'ZELDA' not in rom[0x20:0x34] or rom[0x3e]!=ord('E') or rom[0x3f]!=2:
        raise ValueError('Link import currently supports Ocarina of Time USA Rev 2 (1.2)')
    defs=json.loads((HERE/'oot-layout.json').read_text());animation=rom_file(rom,defs['animationFileIndex'],defs['dmadata'])
    shared_definition=json.loads((HERE/'oot-shared-layout.json').read_text());shared=rom_file(rom,shared_definition['sharedFileIndex'],defs['dmadata'])
    for name,definition in defs['models'].items():
        obj=rom_file(rom,definition['fileIndex'],defs['dmadata']);model=LinkModel(obj,definition,shared,shared_definition);clips={}
        for clip,anim in defs['animations'].items():
            frames=[]
            # Preserve native timing while limiting the longer idle loop's cache size.
            sample_count=min(45,anim['frames']) if clip=='idle' else anim['frames']
            for f in range(sample_count):
                actual=int(f*anim['frames']/sample_count);offset=animation_offset(anim,actual)
                joints=[struct.unpack_from('>hhh',animation,offset+j*6) for j in range(22)]
                vertices=model.bake(joints,clip if clip in ('bow','ocarina','hookshot','hammer','boomerang','climb','swim','drink','hang','climbup') else 'sword')
                if not 300<len(vertices)//11<20000:raise ValueError('Link produced invalid geometry')
                frames.append(vertices)
            clips[clip]=frames
        if name=='oot':
            for variant in ['idle','walk','run','attack','attack2','attack3','thrust','spin','jumpattack']:
                anim=defs['animations'][variant];frames=[];sample_count=min(45,anim['frames'])
                for f in range(sample_count):
                    actual=int(f*anim['frames']/sample_count);offset=animation_offset(anim,actual)
                    frames.append(model.bake([struct.unpack_from('>hhh',animation,offset+j*6) for j in range(22)],'biggoron'))
                clips[variant+'_big']=frames
            anim=defs['animations']['shield'];frames=[]
            for f in range(anim['frames']):
                offset=animation_offset(anim,f)
                frames.append(model.bake([struct.unpack_from('>hhh',animation,offset+j*6) for j in range(22)],'mirror'))
            clips['shield_mirror']=frames
        if name=='oot_child':
            offset=animation_offset(defs['animations']['idle'],0)
            joints=[struct.unpack_from('>hhh',animation,offset+j*6) for j in range(22)]
            for key in definition['equipment']:
                if key.startswith('mask_'):clips[key]=[model.bake(joints,key)]
        save_avatar(output/(name+'.avz'),'Adult Link' if name=='oot' else 'Young Link',clips,png(1024,1024,bytes(model.atlas)),rom,1.8 if name=='oot' else 1.45,model.head_triangle)
    import_interface(rom,output,defs['dmadata'])

def import_interface(rom,output,table):
    metadata=json.loads((HERE/'oot-interface-layout.json').read_text())
    model=LinkModel.__new__(LinkModel)
    model.atlas=bytearray(b'\xff'*(1024*1024*4));model.slots={None:(0,0,1,1)}
    model.white=(0,0,1,1);model.cursor_x=2;model.cursor_y=2;model.row=0
    model.data=b'';model.texture_info={};sprites={}
    for file,definition in metadata.items():
        base=len(model.data);model.data+=rom_file(rom,definition['index'],table)
        for info in definition['textures']:
            if not info.get('Offset','').startswith('0x'):continue
            offset=base+int(info['Offset'],0);model.texture_info[offset]=info
            sprites[info['Name']]=model.texture(offset)
    output.mkdir(parents=True,exist_ok=True)
    temp=output/'oot-ui.tmp'
    with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('manifest.json',json.dumps({'version':1,'sprites':sprites}))
        z.writestr('atlas.png',png(1024,1024,bytes(model.atlas)))
    temp.replace(output/'oot-ui.zip')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--game',choices=['sm64','oot'],required=True);parser.add_argument('--rom',required=True);parser.add_argument('--output',required=True)
    args=parser.parse_args();rom=read_rom(args.rom);out=Path(args.output)
    (import_mario if args.game=='sm64' else import_link)(rom,out)

if __name__=='__main__':
    try:main()
    except Exception as ex:print('Avatar import failed: '+str(ex),file=sys.stderr);sys.exit(1)
