package dev.evvie.waylandcraft.console;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MovementRulesTest {
    private boolean can(boolean before,boolean now,boolean forward,boolean crouch,double speed,double vertical,int sinceJump,boolean gap){return Adventures.ledgeJumpEligible(before,now,forward,crouch,speed,vertical,sinceJump,gap);}
    @Test void runningOffDeepEdgeAutoJumps(){assertTrue(can(true,false,true,false,.12,-.08,30,true));}
    @Test void ordinaryStepsAndFallsDoNotTrigger(){
        assertFalse(can(true,false,true,false,.12,-.08,30,false));
        assertFalse(can(false,false,true,false,.12,-.08,30,true));
        assertFalse(can(true,false,false,false,.12,-.08,30,true));
        assertFalse(can(true,false,true,true,.12,-.08,30,true));
    }
    @Test void manualJumpOrEstablishedFallDoesNotTrigger(){
        assertFalse(can(true,false,true,false,.12,.42,30,true));
        assertFalse(can(true,false,true,false,.12,-.08,2,true));
        assertFalse(can(true,false,true,false,.12,-.6,30,true));
        assertFalse(can(true,false,true,false,.001,-.08,30,true));
    }
}
