package dev.evvie.waylandcraft.console;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;
import java.nio.file.*;
import java.util.*;

class LibraryTest {
    @TempDir Path temp;
    @Test void discoversNestedMixedCaseAndSearchesLocally() throws Exception {
        var library = new RomLibrary(temp.resolve("roms"));
        Files.createDirectories(library.folder(ConsoleType.N64).resolve("Zelda"));
        Files.writeString(library.folder(ConsoleType.N64).resolve("Zelda/Ocarina of Time.Z64"), "test fixture");
        Files.writeString(library.folder(ConsoleType.N64).resolve("notes.txt"), "not a game");
        var found = library.scan(ConsoleType.N64, "ocarina");
        assertEquals(1, found.size()); assertEquals(ConsoleType.N64, found.getFirst().console());
        assertTrue(library.scan(ConsoleType.N64, "missing game").isEmpty());
    }
    @Test void rejectsSymlinkEscapeAndOutsideLaunches() throws Exception {
        var library = new RomLibrary(temp.resolve("roms"));
        Files.createDirectories(library.folder(ConsoleType.NES));
        Path outside = Files.writeString(temp.resolve("private.nes"), "test fixture");
        Files.createSymbolicLink(library.folder(ConsoleType.NES).resolve("escape.nes"), outside);
        assertTrue(library.scan(ConsoleType.NES, "").isEmpty());
        assertThrows(java.io.IOException.class, () -> library.validate(ConsoleType.NES, outside));
        assertThrows(java.io.IOException.class, () -> library.validate(ConsoleType.NES, library.folder(ConsoleType.NES).resolve("escape.nes")));
    }
    @Test void importsDiscCompanionsWithoutListingThemAsSeparateGamesOrOverwriting() throws Exception {
        var library = new RomLibrary(temp.resolve("roms"));
        Files.createDirectories(library.folder(ConsoleType.PS1));
        Path cue = Files.writeString(temp.resolve("disc.cue"), "FILE \"disc.bin\" BINARY");
        Path bin = Files.writeString(temp.resolve("disc.bin"), "test fixture");
        library.importFile(ConsoleType.PS1, cue); library.importFile(ConsoleType.PS1, bin);
        assertEquals(1, library.scan(ConsoleType.PS1, "").size());
        assertThrows(FileAlreadyExistsException.class, () -> library.importFile(ConsoleType.PS1, cue));
        Path exe = Files.writeString(temp.resolve("game.sh"), "test fixture");
        assertThrows(java.io.IOException.class, () -> library.importFile(ConsoleType.PS1, exe));
    }
    @Test void commandArgumentsPreserveSpacesAndShellMetacharacters() throws Exception {
        var config = ConsoleConfig.load(temp.resolve("config"));
        Path rom = temp.resolve("spaces $(touch nope); `echo nope`.z64");
        var args = config.command(ConsoleType.N64, rom);
        assertEquals(4, args.size()); assertEquals(rom.toAbsolutePath().toString(), args.getLast());
        assertEquals("retroarch", args.getFirst());
        assertEquals(List.of("sm64coopdx"), config.command(ConsoleType.SM64COOPDX, null));
        assertThrows(IllegalArgumentException.class, () -> config.command(ConsoleType.N64, null));
    }
    @Test void loadsUserCommandsWithoutReplacingTheirConfig() throws Exception {
        Path root = temp.resolve("settings");
        ConsoleConfig.load(root);
        String custom = "{\"commands\":{\"sm64coopdx\":[\"/games/Coop DX/sm64coopdx\"]},\"maxSessions\":100}";
        Files.writeString(root.resolve("config.json"), custom);
        var loaded = ConsoleConfig.load(root);
        assertEquals(8, loaded.maxSessions);
        assertEquals("/games/Coop DX/sm64coopdx", loaded.command(ConsoleType.SM64COOPDX, null).getFirst());
        assertEquals(custom, Files.readString(root.resolve("config.json")));
        assertEquals(ConsoleType.values().length, loaded.commands.size());
    }
    @Test void mapsSDLToLinuxIncludingDifferentMouseButtonOrders() {
        assertEquals(38, LinuxKeymap.toXkb(org.lwjgl.sdl.SDLScancode.SDL_SCANCODE_A));
        assertEquals(9, LinuxKeymap.toXkb(org.lwjgl.sdl.SDLScancode.SDL_SCANCODE_ESCAPE));
        assertEquals(-1, LinuxKeymap.toXkb(0));
        assertEquals(0x111, LinuxKeymap.mouseButton(com.mojang.blaze3d.platform.InputConstants.MOUSE_BUTTON_RIGHT));
        assertEquals(0x112, LinuxKeymap.mouseButton(com.mojang.blaze3d.platform.InputConstants.MOUSE_BUTTON_MIDDLE));
    }
}
