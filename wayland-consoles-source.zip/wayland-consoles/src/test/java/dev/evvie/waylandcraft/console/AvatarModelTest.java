package dev.evvie.waylandcraft.console;

import dev.evvie.waylandcraft.avatar.AvatarModel;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;
import java.nio.*;
import java.nio.file.*;
import java.util.zip.*;
import java.io.*;

class AvatarModelTest {
    @TempDir Path temp;
    private Path cache(int count, float value) throws IOException {
        Path file = temp.resolve("model.avz");
        var buffer = ByteBuffer.allocate(4+33*4).order(ByteOrder.LITTLE_ENDIAN).putInt(count);
        for (int i=0;i<33;i++) buffer.putFloat(value);
        try (var zip = new ZipOutputStream(Files.newOutputStream(file))) {
            for (var name : new String[]{"manifest.json", "frames.bin", "atlas.png"}) {
                zip.putNextEntry(new ZipEntry(name));
                zip.write(switch (name) {
                    case "manifest.json" -> "{\"version\":3,\"name\":\"Test\",\"clips\":[{\"name\":\"idle\",\"frames\":1,\"fps\":30}]}".getBytes(java.nio.charset.StandardCharsets.UTF_8);
                    case "frames.bin" -> buffer.array();
                    default -> new byte[]{1,2,3};
                }); zip.closeEntry();
            }
        }
        return file;
    }
    @Test void decodesLittleEndianTrianglesAndAnimationTiming() throws Exception {
        var model = AvatarModel.load(cache(3,.25f));
        assertEquals("Test",model.name());
        assertEquals(30,model.clips().get("idle").fps());
        assertEquals(.25f,model.clips().get("idle").frames()[0][32]);
    }
    @Test void rejectsInvalidTriangleCountsBeforeAllocation() throws Exception {
        assertThrows(IOException.class,()->AvatarModel.load(cache(Integer.MAX_VALUE,0)));
        assertThrows(IOException.class,()->AvatarModel.load(cache(4,0)));
    }
    @Test void rejectsNonfiniteVertexData() throws Exception {
        assertThrows(IOException.class,()->AvatarModel.load(cache(3,Float.NaN)));
    }
}
