package dev.evvie.waylandcraft;

import dev.evvie.waylandcraft.avatar.*;
import dev.evvie.waylandcraft.console.Adventures;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.minecraft.client.CameraType;
import java.util.Arrays;

/** Opt-in integration check using the owner's local ROMs, never bundled fixtures. */
public final class AvatarClientTest implements FabricClientGameTest {
    private static void require(boolean value, String message) { if (!value) throw new AssertionError(message); }
    @Override public void runTest(ClientGameTestContext ctx) {
        if (!"1".equals(System.getenv("CONSOLE_AVATAR_TESTS"))) return;
        try (var world = ctx.worldBuilder().create()) {
        if (System.getenv("CONSOLE_AVATAR_CACHE") != null) ctx.runOnClient(mc -> {
            var target=WaylandCraft.instance.root.resolve("avatars");java.nio.file.Files.createDirectories(target);
            try(var files=java.nio.file.Files.list(java.nio.file.Path.of(System.getenv("CONSOLE_AVATAR_CACHE")))) {
                for(var file:files.filter(f->f.toString().endsWith(".avz")||f.getFileName().toString().equals("oot-ui.zip")).toList())java.nio.file.Files.copy(file,target.resolve(file.getFileName()),java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
        });

            var server = world.getServer();
            server.runCommand("gamemode survival @a");
            server.runCommand("fill -12 64 -12 12 64 12 minecraft:stone");
            server.runCommand("time set noon"); server.runCommand("weather clear");
            server.runCommand("tp @a 0.5 65 0.5 0 0");
            ctx.waitTicks(20);
            for (String mode : new String[]{"sm64", "oot", "oot_child"}) {
                ctx.runOnClient(mc -> { mc.options.setCameraType(CameraType.FIRST_PERSON); Adventures.select(mode); });
                ctx.waitFor(mc -> Adventures.mode().equals(mode), 3000);
                ctx.runOnClient(mc -> {
                    require(AvatarRenderer.replacesPlayer(), "Vanilla model was not replaced");
                    var model = Avatars.get(mode).model();
                    var idle = model.clips().get("idle").frames();
                    require(idle[0].length > 2000 * 11, "Missing original model mesh");
                    require(!Arrays.equals(idle[0], idle[idle.length/2]), "Animation frames are static");
                    require(mc.options.getCameraType() == CameraType.THIRD_PERSON_BACK, "Character camera did not activate");
                    mc.options.setCameraType(CameraType.THIRD_PERSON_FRONT);
                    if (!mc.gui.hud.isHidden()) mc.gui.hud.toggle();
                });
                ctx.waitTicks(15);
                ctx.runOnClient(mc -> require(AvatarRenderer.submittedVertices > 2000, "Imported model was not submitted to the renderer"));
                ctx.takeScreenshot("avatar-" + mode);
                ctx.runOnClient(mc -> { if (mc.gui.hud.isHidden()) mc.gui.hud.toggle(); });
                if (mode.equals("sm64")) ctx.runOnClient(mc -> {
                    mc.player.setDeltaMovement(0,0,0); mc.player.setOnGround(true);
                    require(Adventures.jump(mc.player), "SM64 jump did not activate");
                    require(mc.player.getDeltaMovement().y >= .49, "SM64 jump height missing");
                });
                ctx.runOnClient(mc -> Adventures.select("off"));
                ctx.waitTicks(10);
                ctx.runOnClient(mc -> {
                    require(!AvatarRenderer.replacesPlayer(), "Vanilla model was not restored");
                    require(mc.options.getCameraType() == CameraType.FIRST_PERSON, "Previous camera was not restored");
                });
            }
        } catch (Exception ex) { throw new RuntimeException(ex); }
    }
}
