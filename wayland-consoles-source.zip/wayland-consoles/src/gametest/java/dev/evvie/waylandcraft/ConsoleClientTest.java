package dev.evvie.waylandcraft;

import com.mojang.blaze3d.platform.InputConstants;
import dev.evvie.waylandcraft.console.*;
import dev.evvie.waylandcraft.gui.*;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import java.nio.file.*;
import java.util.*;

/** Uses an original Wayland test pattern; no commercial ROM is used by these tests. */
public final class ConsoleClientTest implements FabricClientGameTest {
    private static void require(boolean condition, String reason) { if (!condition) throw new AssertionError(reason); }
    @Override public void runTest(ClientGameTestContext ctx) {
        ctx.waitFor(mc -> WaylandCraft.instance != null && WaylandCraft.instance.bridge != null, 300);
        Path probe = Path.of(System.getenv("CONSOLE_PROBE"));
        require(Files.isExecutable(probe), "Build the probe using tools/build-probe.sh first");
        try (var world = ctx.worldBuilder().create()) {
            var server = world.getServer();
            server.runCommand("gamemode creative @a");
            server.runCommand("fill -6 64 -6 9 64 8 minecraft:stone");
            server.runCommand("setblock 0 65 2 waylandconsoles:tv[facing=north]");
            server.runCommand("setblock 1 65 2 waylandconsoles:nes_console[facing=north]");
            server.runCommand("tp @a 0.5 65 -1.5 0 10");
            int index = 0;
            for (var type : ConsoleType.values()) {
                if (type == ConsoleType.NES) continue;
                int x = index % 6 - 3, z = 4 + index / 6;
                server.runCommand("setblock " + x + " 65 " + z + " waylandconsoles:" + type.id() + "_console");
                index++;
            }
            server.runOnServer(s -> {
                var recipes = s.getRecipeManager();
                for (var type : ConsoleType.values()) require(recipes.byKey(ResourceKey.create(Registries.RECIPE,
                        WaylandCraftCommon.id(type.id() + "_console"))).isPresent(), "Missing recipe: " + type);
                require(recipes.byKey(ResourceKey.create(Registries.RECIPE, WaylandCraftCommon.id("tv"))).isPresent(), "Missing TV recipe");
                require(recipes.byKey(ResourceKey.create(Registries.RECIPE, WaylandCraftCommon.id("controller"))).isPresent(), "Missing controller recipe");
            });
            BlockPos tv = new BlockPos(0,65,2), console = new BlockPos(1,65,2);
            ctx.waitFor(mc -> mc.level != null && mc.level.getBlockState(tv).is(WaylandCraftCommon.TV));
            ctx.runOnClient(mc -> {
                var wlc = WaylandCraft.instance;
                Path fixture = wlc.library.folder(ConsoleType.NES).resolve("probe.nes");
                Files.writeString(fixture, "Original non-ROM test fixture; only used by the Wayland probe");
                wlc.config.commands.put("nes", List.of(probe.toAbsolutePath().toString()));
                wlc.launch(tv, console, ConsoleType.NES, fixture, () -> {});
            });
            ctx.waitFor(mc -> {
                var s = WaylandCraft.instance.sessions.get(tv);
                return s != null && s.window != null && s.window.getFramebuffer() != null && s.window.getFramebuffer().isValid();
            }, 300);
            ctx.runOnClient(mc -> {
                var s = WaylandCraft.instance.sessions.get(tv);
                require(s.window.clientPid == s.process.pid(), "Wayland client PID was not matched");
                var b = s.window.getRootSurface().getBuffer();
                require(b.width == 320 && b.height == 240, "Probe buffer dimensions changed");
                require(b.pixels.getPixel(10,10) == 0xffff4040, "SHM red pixel changed");
                require(b.pixels.getPixel(200,200) == 0xffffd050, "SHM yellow pixel changed");
            });
            ctx.waitTicks(15);
            ctx.takeScreenshot("tv-in-world");
            ctx.setScreen(() -> new TVControlScreen(WaylandCraft.instance, WaylandCraft.instance.sessions.get(tv)));
            ctx.waitTicks(10);
            ctx.takeScreenshot("tv-control-screen");
            ctx.getInput().pressKey(InputConstants.KEY_A);
            ctx.getInput().setCursorPos(180,100);
            ctx.getInput().pressMouse(InputConstants.MOUSE_BUTTON_LEFT);
            ctx.waitTicks(10);
            ctx.runOnClient(mc -> {
                String log = Files.readString(WaylandCraft.instance.root.resolve("logs/nes-" + tv.asLong() + ".log"));
                require(log.contains("key 30 1") && log.contains("key 30 0"), "Keyboard events not delivered: " + log);
                require(log.contains("button 272 1") && log.contains("button 272 0"), "Pointer events not delivered: " + log);
            });
            ctx.getInput().pressKey(InputConstants.KEY_ESCAPE);
            ctx.runOnClient(mc -> require(mc.gui.screen() == null, "Escape failed to release TV"));
            ctx.setScreen(() -> new RomLibraryScreen(WaylandCraft.instance, tv, console, ConsoleType.N64));
            ctx.waitTicks(10); ctx.takeScreenshot("rom-library"); ctx.setScreen(() -> null);
            server.runCommand("setblock 0 65 2 minecraft:air");
            ctx.waitFor(mc -> !WaylandCraft.instance.sessions.containsKey(tv), 100);
            ctx.runOnClient(mc -> WaylandCraft.instance.config.commands.put("nes", ConsoleType.NES.defaultCommand()));
        } catch (Exception ex) { throw new RuntimeException(ex); }
    }
}
