package dev.evvie.waylandcraft;

import com.mojang.blaze3d.platform.InputConstants;
import dev.evvie.waylandcraft.adventure.*;
import dev.evvie.waylandcraft.avatar.*;
import dev.evvie.waylandcraft.console.Adventures;
import dev.evvie.waylandcraft.gui.*;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.minecraft.client.CameraType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;

/** Opt-in action regression tests using the owner's ROMs in a disposable world. */
public final class AdventureClientTest implements FabricClientGameTest {
    private static void require(boolean value,String message){if(!value)throw new AssertionError(message);}
    @Override public void runTest(ClientGameTestContext ctx){
        if(!"1".equals(System.getenv("CONSOLE_AVATAR_TESTS")))return;
        try(var world=ctx.worldBuilder().create()){
            var server=world.getServer();server.runCommand("fill -12 64 -12 12 64 12 minecraft:stone");server.runCommand("gamemode survival @a");
            server.runCommand("tp @a 0.5 65 0.5 0 0");ctx.waitTicks(20);
            for(String mode:new String[]{"sm64","oot","oot_child"}){
                ctx.runOnClient(mc->{WaylandCraft.instance.config.adventureSandbox=true;Adventures.select(mode);});
                ctx.waitFor(mc->Adventures.mode().equals(mode),4000);
                server.runCommand("tp @a 0.5 65 0.5 0 0");server.runCommand("summon minecraft:husk 0.5 65 2.5 {NoAI:1b,Silent:1b,Tags:[\"action_target\"]}");ctx.waitTicks(5);
                ctx.runOnClient(mc->mc.options.setCameraType(CameraType.THIRD_PERSON_BACK));
                ctx.getInput().pressMouse(InputConstants.MOUSE_BUTTON_LEFT);
                ctx.waitFor(mc->AvatarRenderer.renderedClip.equals(mode.equals("sm64")?"punch":"attack"),20);
                ctx.runOnClient(mc->{mc.gui.hud.getChat().clearMessages(true);mc.gui.toastManager().clear();});
                ctx.takeScreenshot("action-"+mode);
                ctx.waitTicks(4);
                server.runOnServer(s->{var target=s.overworld().getEntitiesOfClass(LivingEntity.class,new AABB(-10,60,-10,10,80,10),e->e.getType()==net.minecraft.world.entity.EntityTypes.HUSK);require(target.size()==1&&target.getFirst().getHealth()<target.getFirst().getMaxHealth(),"Attack did not cause server-side damage: "+mode);});
                server.runCommand("kill @e[tag=action_target]");
                ctx.runOnClient(mc->mc.options.setCameraType(CameraType.THIRD_PERSON_FRONT));
                for(String combo:mode.equals("sm64")?new String[]{"punch2","kick"}:new String[]{"attack2","attack3"}){
                    ctx.waitTicks(6);ctx.getInput().pressMouse(InputConstants.MOUSE_BUTTON_LEFT);ctx.waitFor(mc->AvatarRenderer.renderedClip.equals(combo),20);
                }
                ctx.runOnClient(mc->{mc.gui.hud.getChat().clearMessages(true);mc.gui.toastManager().clear();});ctx.takeScreenshot("combo-finisher-"+mode);
                if(mode.equals("sm64")){
                    ctx.runOnClient(mc->{mc.options.keyShift.setDown(true);mc.player.setDeltaMovement(0,0,0);mc.player.setOnGround(true);require(Adventures.jump(mc.player),"Backflip jump was not handled");require(mc.player.getDeltaMovement().y>.7,"Stationary crouch jump did not backflip");require(Adventures.animation(mc.player).equals("backflip"),"Backflip clip missing");mc.options.keyShift.setDown(false);});ctx.waitTicks(12);
                }
                if(mode.equals("oot_child"))ctx.runOnClient(mc->AdventureState.equip(ZeldaGear.TRUTH));
                // Catch a floating platform, remain hanging, then climb onto it.
                server.runCommand("fill 0 65 1 2 66 3 minecraft:stone");server.runCommand("tp @a 0.5 65.4 0.6 0 0");ctx.waitTicks(3);
                ctx.runOnClient(mc->{mc.player.setPos(.5,65.4,.6);mc.player.setDeltaMovement(0,-.05,0);mc.player.setOnGround(false);mc.options.keyUp.setDown(true);});
                ctx.waitFor(mc->LedgeGrab.hanging(),25);
                ctx.runOnClient(mc->mc.options.keyUp.setDown(false));ctx.waitTicks(4);
                ctx.runOnClient(mc->{require(LedgeGrab.hanging(),"Ledge grab did not hold: "+mode);mc.player.setYRot(45);mc.options.setCameraType(CameraType.THIRD_PERSON_BACK);});
                ctx.runOnClient(mc->{if(!mc.gui.hud.isHidden())mc.gui.hud.toggle();});
                ctx.takeScreenshot("ledge-"+mode);
                ctx.runOnClient(mc->{if(mc.gui.hud.isHidden())mc.gui.hud.toggle();});
                ctx.runOnClient(mc->mc.options.keyJump.setDown(true));ctx.waitFor(mc->LedgeGrab.climbing(),10);
                ctx.runOnClient(mc->mc.options.keyJump.setDown(false));ctx.waitFor(mc->!LedgeGrab.climbing()&&!LedgeGrab.hanging()&&mc.player.getY()>66.9,30);
                ctx.waitTicks(12);
                server.runCommand("tp @a 0.5 65.4 0.6 0 0");ctx.waitTicks(2);
                ctx.runOnClient(mc->{mc.player.setPos(.5,65.4,.6);mc.player.setDeltaMovement(0,-.05,0);mc.player.setOnGround(false);mc.options.keyUp.setDown(true);});
                ctx.waitFor(mc->LedgeGrab.hanging(),25);
                ctx.runOnClient(mc->{mc.options.keyUp.setDown(false);mc.options.keyShift.setDown(true);});ctx.waitTicks(2);
                ctx.runOnClient(mc->{require(!LedgeGrab.hanging()&&!LedgeGrab.climbing(),"Crouch did not release ledge: "+mode);mc.options.keyShift.setDown(false);});
                server.runCommand("fill 0 65 1 2 66 3 minecraft:air");
            }
            // Check Link's automatic jump with actual forward movement over an edge.
            for(String mode:new String[]{"oot","oot_child"}){
                ctx.runOnClient(mc->Adventures.select(mode));ctx.waitFor(mc->Adventures.mode().equals(mode));
                server.runCommand("fill -3 64 2 3 64 8 minecraft:air");server.runCommand("tp @a 0.5 65 1.2 0 0");ctx.waitTicks(5);
                ctx.runOnClient(mc->mc.options.keyUp.setDown(true));ctx.waitFor(mc->mc.player.getY()>65.1&&mc.player.getDeltaMovement().y>0,45);
                ctx.runOnClient(mc->mc.options.keyUp.setDown(false));
                server.runCommand("fill -3 64 2 3 64 8 minecraft:stone");ctx.waitTicks(15);
            }
            server.runCommand("tp @a 0.5 65 0.5 0 0");ctx.waitTicks(5);
            ctx.runOnClient(mc->{Adventures.select("oot");AdventureState.equip(ZeldaGear.MIRROR);});ctx.waitTicks(2);
            ctx.runOnClient(mc->{Adventures.select("oot_child");AdventureState.equip(ZeldaGear.TRUTH);mc.options.setCameraType(CameraType.THIRD_PERSON_FRONT);mc.gui.hud.getChat().clearMessages(true);mc.gui.toastManager().clear();});ctx.waitTicks(4);ctx.takeScreenshot("zelda-mask");
            ctx.runOnClient(mc->Adventures.select("oot"));ctx.waitTicks(2);
            ctx.setScreen(ZeldaEquipmentScreen::new);ctx.waitTicks(3);ctx.takeScreenshot("zelda-equipment");ctx.setScreen(()->null);
            ctx.setScreen(OcarinaScreen::new);ctx.waitTicks(3);ctx.takeScreenshot("zelda-ocarina");ctx.setScreen(()->null);
            ctx.runOnClient(mc->{AdventureState.toggleSandbox();require(!AdventureState.sandbox(),"Kit did not toggle off");require(!AdventureState.available(ZeldaGear.BOW),"Equipment-required mode incorrectly unlocked a bow");AdventureState.toggleSandbox();require(AdventureState.available(ZeldaGear.BOW),"Kit did not unlock the bow");});
            // A projectile must inflict damage through the server simulation.
            server.runCommand("summon minecraft:husk 0.5 65 5 {NoAI:1b,Silent:1b,Tags:[\"arrow_target\"]}");ctx.waitTicks(3);
            ctx.runOnClient(mc->{mc.player.setYRot(0);mc.player.setXRot(0);AdventureControls.use(ZeldaGear.ICE_ARROW);});ctx.waitTicks(9);
            server.runOnServer(s->{var target=s.overworld().getEntitiesOfClass(LivingEntity.class,new AABB(-10,60,-10,10,80,10),e->e.getType()==net.minecraft.world.entity.EntityTypes.HUSK);require(target.size()==1&&target.getFirst().getHealth()<target.getFirst().getMaxHealth(),"Ice arrow failed to hit");require(target.getFirst().getTicksFrozen()>0,"Ice arrow failed to freeze");});
            ctx.runOnClient(mc->{AdventureControls.use(ZeldaGear.NAYRUS_LOVE);});ctx.waitTicks(10);
            server.runOnServer(s->{var p=s.getPlayerList().getPlayers().getFirst();float health=p.getHealth();p.hurtServer(s.overworld(),p.damageSources().generic(),4);require(p.getHealth()==health,"Nayru's Love failed to block damage");});
            ctx.runOnClient(mc->{AdventureState.reset();AdventureControls.guard.setDown(true);AdventureState.shield=true;AdventureState.equip(ZeldaGear.HYLIAN);AdventureActions.updateSettings();});ctx.waitTicks(2);
            server.runOnServer(s->{var p=s.getPlayerList().getPlayers().getFirst();var enemy=s.overworld().getEntitiesOfClass(LivingEntity.class,new AABB(-10,60,-10,10,80,10),e->e.getType()==net.minecraft.world.entity.EntityTypes.HUSK).getFirst();float health=p.getHealth();p.hurtServer(s.overworld(),p.damageSources().mobAttack(enemy),4);require(p.getHealth()==health,"Shield did not block a frontal attack");});
            ctx.runOnClient(mc->{AdventureControls.guard.setDown(false);AdventureState.shield=false;AdventureActions.use(ZeldaGear.FARORES_WIND);});ctx.waitTicks(3);
            server.runCommand("tp @a 3.5 65 0.5 0 0");ctx.waitTicks(3);
            ctx.runOnClient(mc->AdventureActions.use(ZeldaGear.FARORES_WIND));ctx.waitFor(mc->mc.player.getX()<1,20);
            ctx.runOnClient(mc->Adventures.select("off"));
        }catch(Exception ex){throw new RuntimeException(ex);}
    }
}
