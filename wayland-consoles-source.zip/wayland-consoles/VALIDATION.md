# Validation — October 31, 2026, version 0.3.0

The release build, twelve unit tests and all three Fabric client game tests passed on
Minecraft 26.3, Fabric Loader 0.20.1, Fabric API 0.165.0+26.3, JDK 25 and Gradle 9.8.
The tests use disposable Minecraft worlds, SDL offscreen video and Mesa llvmpipe.

Verified through Minecraft's client/server simulation:

- All 22 console blocks and all 24 crafting recipes load. The Wayland probe starts, matches
  its process to a TV, preserves pixel colors/dimensions, accepts keyboard/pointer input,
  renders in the TV/control screen, and stops when the TV is removed.
- Mario, adult Link and young Link load original meshes/textures and animated poses. The
  owner’s local ROMs were imported successfully; later regression runs reused those private
  caches. Selecting a character and disabling it restore the appropriate model/camera.
- Actual mouse attack input selects punch/sword clips and causes server-side damage.
  Second punches/slashes and kick/combo finishers select their respective original clips.
- Mario's stationary crouch jump produces a backflip, with the corresponding pose.
- Both Links automatically jump over a genuine edge during ordinary forward movement.
- All three characters catch a platform, remain hanging, climb onto it with jump, and release
  with crouch. Screenshots were inspected; native hanging poses are aligned to the ledge,
  and the climb duration follows each character's imported animation timing.
- The equipment and ocarina screens render original imported icons. The unlocked-kit toggle
  disables/enables equipment without a matching Minecraft inventory item. The child Mask of
  Truth renders on the character; its attachment follows the animated head.
- Ice arrows cause server-side damage and freeze their target. Nayru's Love prevents ordinary
  damage. A held shield blocks a frontal attack. Farore's Wind sets a point and returns to it.

The twelve unit tests cover local library/config/input behavior, bounded avatar decoding,
invalid triangle/vertex rejection, and ledge-jump eligibility including steps, manual jumps,
crouching and established falls.

The ordinary TV test uses an original Wayland test pattern. The avatar/action tests are
opt-in (`CONSOLE_AVATAR_TESTS=1`) and use the owner's Super Mario 64 USA and Ocarina of Time
USA Rev 2 ROMs. `CONSOLE_AVATAR_CACHE` optionally points to previously imported private
caches for faster regression checks. No ROM, extracted avatar cache or imported UI atlas is
included in the JAR/source archive. The Mario helper uses libsm64 geometry with local ROM
textures/animations; Link geometry and UI textures are read from the local OoT ROM.

Earlier runtime checks booted SM64 in RetroArch on the nested display and confirmed a
960×720 viewport and SDL2 autoconfiguration of the user's 8BitDo Pro 2 in Switch mode.

Not comprehensively verified: every item/spell/song interaction, all equipment combinations,
every ledge shape, every emulator/core/game, original-game accuracy, custom CoopDX/DynOS
models, networking, hardware DMA-BUF, Xwayland, ARM64, Windows/macOS, or the profile's Sodium
renderer. Representative combat, magic and movement paths were exercised; this is not a
claim that an entire OoT engine or quest system has been ported.

The character systems are singleplayer adaptations to Minecraft. Player hitboxes remain
Minecraft's. See docs/ADVENTURE-CONTROLS.md for controls, item requirements and mappings.
